_G.tiendaComplementosVentanasAbiertas = _G.tiendaComplementosVentanasAbiertas or {}
function cerrarTodosLosDialogosAbiertos()
for _, ventanaAnterior in ipairs(_G.tiendaComplementosVentanasAbiertas) do
pcall(function()
if ventanaAnterior and ventanaAnterior.isShowing and ventanaAnterior.isShowing() then
ventanaAnterior.dismiss()
end
end)
end
_G.tiendaComplementosVentanasAbiertas = {}
end
cerrarTodosLosDialogosAbiertos()
function registrarVentana(ventana)
table.insert(_G.tiendaComplementosVentanasAbiertas, ventana)
return ventana
end
require "import"
import "android.widget.*"
import "android.provider.Settings"
import "android.view.*"
import "android.content.ClipData"
import "cjson"
import "android.content.Intent"
import "android.net.Uri"
import "android.os.Build"
import "android.os.Handler"
import "android.os.VibrationEffect"
import "android.media.MediaPlayer"
import "android.media.RingtoneManager"
import "android.content.SharedPreferences"
import "android.content.Context"
import "android.preference.PreferenceManager"
import "com.androlua.LuaDialog"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.io.OutputStreamWriter"
import "java.io.DataOutputStream"
import "java.io.BufferedInputStream"
import "java.io.BufferedOutputStream"
import "java.lang.System"
import "java.io.ByteArrayOutputStream"
import "java.util.zip.ZipOutputStream"
import "java.util.zip.ZipInputStream"
import "java.util.zip.ZipEntry"
import "android.util.Base64"
import "java.net.URL"
import "javax.net.ssl.HttpsURLConnection"
import "java.lang.Thread"
import "java.lang.Runnable"
import "java.lang.reflect.Array"
import "java.lang.StringBuilder"
import "org.json.JSONObject"
import "org.json.JSONArray"
import "java.net.URLEncoder"
import "android.view.inputmethod.InputMethodManager"
import "android.view.inputmethod.EditorInfo"
import "android.view.Gravity"
import "android.view.KeyEvent"
import "java.util.Locale"
import "java.nio.charset.StandardCharsets"
import "java.util.LinkedHashSet"
import "java.security.MessageDigest"
service = service
pcall(function() math.randomseed(os.time() + (System.currentTimeMillis() % 100000)) end)
PREFERENCIAS = "tiendadecomplementos30"
CLAVE_PRIMERA_EJECUCION = "primera_ejecucion_v3.0"
prefsInicio = service.getSharedPreferences(PREFERENCIAS, 0)
primeraEjecucion = prefsInicio.getBoolean(CLAVE_PRIMERA_EJECUCION, true)
mostrarCreditosFlag = false
node = service.getEditText()
vibrator = service.getSystemService(Context.VIBRATOR_SERVICE)
prefs = PreferenceManager.getDefaultSharedPreferences(service)
handler = Handler()
redBloqueada = true
verificacionSeguridadEnCurso = true
accesoRedHabilitado = false
vibrationEnabled = prefs.getBoolean("vibrationEnabled", true)
vibrationIntensity = prefs.getInt("vibrationIntensity", 50)
pedirConfirmacion = prefs.getBoolean("pedirConfirmacion", true)
modoCompacto = prefs.getBoolean("modoCompacto", true)
CLAVE_INTERFAZ_TIENDA = "interfazTienda"
interfazTienda = prefs.getString(CLAVE_INTERFAZ_TIENDA, "paginas")
if interfazTienda ~= "botones" then interfazTienda = "paginas" end
function textoBotonInterfazTienda()
if interfazTienda == "botones" then
return "Interfaz de la tienda: actualmente usas botones. El Top 5 y el Top 10 son botones. Toca para cambiar a páginas"
end
return "Interfaz de la tienda: actualmente usas páginas. El Top 5 y el Top 10 son páginas; con el celular en vertical frente a ti, se cambia entre ellas deslizando con dos dedos hacia la izquierda o hacia la derecha. Toca para cambiar a botones"
end
CLAVE_MOSTRAR_TODOS_LOCALES = "mostrarTodosLocalesAlModificar"
mostrarTodosLocalesAlModificar = prefs.getBoolean(CLAVE_MOSTRAR_TODOS_LOCALES, true)
function textoBotonModificarLocales()
if mostrarTodosLocalesAlModificar then
return "Al modificar una publicación: actualmente activado. Se muestran todos tus complementos locales para elegir uno. Toca para desactivar y que se seleccione solo el que tenga el mismo nombre"
end
return "Al modificar una publicación: actualmente desactivado. Se selecciona automáticamente el complemento con el mismo nombre. Toca para activar y ver todos tus complementos locales"
end
function doVibrate(duration)
if vibrationEnabled then
local intensityMultiplier = vibrationIntensity / 100
local finalDuration = math.max(10, duration * (0.5 + intensityMultiplier * 2.5))
if Build.VERSION.SDK_INT >= 26 then
local amplitude = math.max(50, math.floor(255 * intensityMultiplier))
if intensityMultiplier == 0 then amplitude = 50 end
local effect = VibrationEffect.createOneShot(math.floor(finalDuration), amplitude)
vibrator.vibrate(effect)
else
vibrator.vibrate(math.floor(finalDuration))
end
end
end
LengthFilter = luajava.bindClass("android.text.InputFilter$LengthFilter")
function limitarCaracteres(editText, maximo)
editText.setFilters({LengthFilter(maximo)})
end
dlgPrincipal, dlgUsuarios, dlgConfig, dlgCreditos, dlgIns, dlgErrorConexion = nil
dlgConfirmacionActiva = nil
btnNotifPrincipalRef = nil
creditosText = [[
La Tienda de complementos reúne plugins oficiales de distintos desarrolladores de la comunidad.
Aquí puedes consultar, instalar y actualizar complementos, y ver sus calificaciones y reseñas.
Las publicaciones y sus actualizaciones se administran desde la tienda y las calificaciones se guardan por complemento.
Creado por:
• Rudy, el impaciente
• Chuy Bautista
• Emmanuel Cruz
• Carlos Cázares
]]
instruccionesText = [[
CÓMO USAR LA TIENDA
• Todo se activa con doble clic: complementos, perfiles, botones y opciones.
• Al darle doble clic a un complemento se abre su menú: Ver calificaciones, Instalar, Ver Tutorial (si lo tiene) y, en los tuyos, Editar publicación y Eliminar.
• Mantén pulsado un perfil ajeno para fijarlo u ocultarlo.
PANTALLA PRINCIPAL
La tienda tiene dos interfaces. Cámbiala en Configuraciones con el botón «Interfaz de la tienda», que te indica cuál usas ahora; tu elección se guarda.
• Entre páginas (predeterminada): hay tres páginas y se cambia entre ellas deslizando con dos dedos hacia la izquierda o derecha: Creadores, Top 10 de complementos más descargados y Top 5 de desarrolladores con más descargas.
• Entre botones: una sola lista donde los botones del Top 5 y del Top 10 aparecen junto a los creadores.
Además:
• Buscar: escribe en el cuadro para filtrar perfiles y complementos.
• Notificaciones: historial de mensajes de la tienda. El botón muestra cuántas tienes sin leer.
• Top 10: solo lectura; puedes instalar, ver calificaciones o abrir el tutorial.
CONFIGURACIONES
• Usuario: cambia tu nombre público (una vez cada 12 horas).
• Vibración e intensidad: activa o desactiva la vibración y ajusta su fuerza.
• Fijar perfiles: permite fijar hasta 5 perfiles arriba de la lista. Para quitarlos, elige «Quitar de fijados».
• Ocultar usuarios: oculta un perfil de la lista, búsquedas y tops. «Ver usuarios ocultos» los vuelve a mostrar.
• Pedir confirmación antes de instalar: pregunta antes de instalar; si lo desactivas, instala directo.
• Interfaz de la tienda: el botón te dice cuál usas actualmente (páginas o botones) y al tocarlo cambia a la otra. Con páginas, el celular en vertical frente a ti, se cambia de página deslizando con dos dedos hacia la izquierda o hacia la derecha.
• Al modificar una publicación: activado (predeterminado), «Modificar complemento» muestra todos tus complementos locales para que elijas uno, útil si cambiaste el nombre. Desactivado, se selecciona solo el complemento que se llame igual que la publicación; si no existe, se muestra la lista.
• Instrucciones de uso, Créditos y Términos y Condiciones.
• Cerrar sesión: elimina tu perfil y todos tus complementos publicados.
CALIFICACIONES Y RESEÑAS
• En «Ver calificaciones» verás el promedio y las reseñas.
• Elige «Calificar» y luego «Calificar con estrellas» (1 a 5) o «Reseñar complemento». Después puedes editar o eliminar tu calificación o reseña.
• No puedes calificar tus propios complementos.
NOTIFICACIONES GLOBALES
• En «Notificaciones», elige «Publicar notificación global»: máximo 200 caracteres, sin enlaces de grupos ni canales.
• Solo hay una activa: la nueva reemplaza a la anterior. Puedes publicar una cada 6 horas; si un administrador elimina la tuya, puedes publicar de inmediato.
• Solo para novedades de complementos; no se permite spam ni chistes.
REGISTRO Y REGLAS
• Si no tienes perfil, usa «Crear tu perfil», escribe un nombre público que no esté en uso y acepta los Términos y Condiciones.
• Al crear el perfil, la tienda lo guarda en GitHub. Normalmente tarda unos segundos, pero si mucha gente se registra a la vez puede tardar más. Espera a que termine «Creando perfil» y no lo crees dos veces: si ya existe, la tienda te lo avisa.
• Ten listo un repertorio considerable de complementos funcionales y de tu autoría. No se permiten perfiles con uno o dos complementos, perfiles hechos solo para figurar como creador, ni complementos que solo promocionen redes, canales, grupos o servicios. Se espera trabajo real y constante.
• No publiques complementos que estén en otras tiendas públicas ni en el servidor oficial de Jieshuo.
• Los perfiles que incumplan las reglas serán retirados. Lee el texto completo en «Términos y Condiciones».
SUBIR UN COMPLEMENTO
• En «Mis complementos», elige «Subir Complemento».
• Escribe la descripción y elige el complemento instalado en tu teléfono; el nombre publicado es el de su carpeta.
• Acepta; indica si hay tutorial y su enlace. Si no está encriptado, podrás encriptarlo y subirlo, subirlo sin encriptar o cancelar.
• Si subes uno con el mismo nombre de uno tuyo, se actualiza en lugar de duplicarse.
MODIFICAR O ELIMINAR
• Abre tu complemento y elige «Editar publicación» para cambiar la descripción y el tutorial.
• «Modificar complemento» reemplaza el archivo. Si eliges uno con otro nombre, la publicación se renombra y conserva descargas, calificaciones y reseñas.
• «Eliminar» lo quita de la tienda, con confirmación.
• «Editar anuncio» (en «Mis complementos») muestra un texto arriba de tu lista; déjalo vacío para borrarlo.
AVISOS
• Servidor de respaldo: solo puedes consultar e instalar; no subir, editar ni eliminar.
• Actualizaciones: si hay una versión nueva, elige «Actualizar» y reabre el complemento.
• Términos: si cambian de forma importante, los creadores con perfil verán un aviso: marca la casilla de lectura y elige «Entendido» para continuar. Los pioneros de la tienda, que no crearon un perfil, no lo ven.
TIEMPOS DE ESPERA
• Tus cambios (editar, modificar, eliminar, descargas) se guardan en GitHub al momento y los ves enseguida en tu teléfono.
• Otros dispositivos los ven en cuanto abren o recargan la tienda; normalmente en segundos. Si GitHub está lento o muy ocupado, puede tardar un poco más: espera y vuelve a abrir la tienda en lugar de repetir la acción.
• Las notificaciones globales se muestran al instante.
]]
function mostrarCreditos()
doVibrate(50)
local creditosParagraphs = {}
for paragraph in creditosText:gmatch("[^\n]+") do
if paragraph:match("%S") then
table.insert(creditosParagraphs, paragraph)
end
end
local creditosLayout = {
LinearLayout,
orientation = "vertical",
layout_width = "fill",
layout_height = "fill",
padding = "20dp",
backgroundColor = 0xFF000000,
{
TextView,
text = "BIENVENIDOS A LA TIENDA DE COMPLEMENTOS",
layout_width = "wrap_content",
layout_height = "wrap_content",
textSize = "20sp",
textColor = 0xFF00FF00,
gravity = "center",
layout_marginBottom = "20dp",
layout_gravity = "center_horizontal"
},
{
ScrollView,
layout_width = "match_parent",
layout_height = "300dp",
layout_marginBottom = "20dp",
{
LinearLayout,
id = "creditosContainer",
orientation = "vertical",
layout_width = "match_parent",
layout_height = "wrap_content",
padding = "8dp"
}
},
{
Button,
id = "creditosOkButton",
text = "Entendido",
layout_width = "200dp",
layout_height = "wrap_content",
backgroundColor = 0xFF4CAF50,
textColor = 0xFFFFFFFF,
layout_gravity = "center_horizontal"
}
}
dlgCreditos = registrarVentana(LuaDialog(service))
dlgCreditos.setTitle("Créditos")
local views = {}
local dialogView = loadlayout(creditosLayout, views)
for i, paragraph in ipairs(creditosParagraphs) do
local paragraphView = TextView(service)
paragraphView.setText(paragraph)
paragraphView.setTextColor(0xFFFFFFFF)
paragraphView.setTextSize(14)
paragraphView.setPadding(12, 8, 12, 8)
paragraphView.setBackgroundColor(0xFF333333)
local layoutParams = LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
)
layoutParams.setMargins(0, 0, 0, 2)
paragraphView.setLayoutParams(layoutParams)
views.creditosContainer.addView(paragraphView)
end
dlgCreditos.setView(dialogView)
dlgCreditos.setCancelable(true)
dlgCreditos.setOnCancelListener({onCancel = function() doVibrate(50) dlgCreditos.dismiss() end})
views.creditosOkButton.onClick = function()
doVibrate(50)
service.asyncSpeak("Cerrado")
dlgCreditos.dismiss()
end
dlgCreditos.show()
service.asyncSpeak("Mostrando créditos")
end
if primeraEjecucion then
mostrarCreditosFlag = true
local editor = prefsInicio.edit()
editor.putBoolean(CLAVE_PRIMERA_EJECUCION, false)
editor.apply()
end
OPCION_ORDEN = "opcion_orden"
ORDEN_ALFABETICO_AZ = "alfabetico_az"
ORDEN_ALFABETICO_ZA = "alfabetico_za"
ORDEN_FECHA_NUEVO = "fecha_nuevo"
ORDEN_FECHA_VIEJO = "fecha_viejo"
ORDEN_POPULARIDAD = "popularidad"
ordenActual = prefs.getString(OPCION_ORDEN, ORDEN_FECHA_NUEVO)
CLAVE_FIJAR_ACTIVO = "fijarPerfilesActivo"
CLAVE_OCULTAR_ACTIVO = "ocultarUsuariosActivo"
CLAVE_PERFILES_FIJADOS = "perfilesFijados"
CLAVE_USUARIOS_OCULTOS = "usuariosOcultos"
CLAVE_TERMINOS_SELLO = "terminosCriticosSelloAceptado"
MAX_PERFILES_FIJADOS = 5
ESPERA_NOTIFICACION_SEGUNDOS = 21600
function cargarListaPrefs(clave)
local lista = {}
local ok, arr = pcall(JSONArray, prefs.getString(clave, "[]"))
if ok and arr then
for i = 0, arr.length() - 1 do
local v = arr.optString(i, "")
if v ~= "" then table.insert(lista, v) end
end
end
return lista
end
function guardarListaPrefs(clave, lista)
local arr = JSONArray()
for _, v in ipairs(lista) do arr.put(v) end
prefs.edit().putString(clave, arr.toString()).apply()
end
fijarPerfilesActivo = prefs.getBoolean(CLAVE_FIJAR_ACTIVO, true)
ocultarUsuariosActivo = prefs.getBoolean(CLAVE_OCULTAR_ACTIVO, true)
perfilesFijados = cargarListaPrefs(CLAVE_PERFILES_FIJADOS)
usuariosOcultos = cargarListaPrefs(CLAVE_USUARIOS_OCULTOS)
function posicionEnLista(lista, valor)
for i, v in ipairs(lista) do
if v == valor then return i end
end
return nil
end
function estaFijado(u)
return posicionEnLista(perfilesFijados, u) ~= nil
end
function estaOculto(u)
return posicionEnLista(usuariosOcultos, u) ~= nil
end
function usuarioVisible(u)
if u == userName then return true end
if ocultarUsuariosActivo and estaOculto(u) then return false end
return true
end
function autorOculto(pub)
if not ocultarUsuariosActivo then return false end
local u = obtenerUsernameDesdePublico(pub)
if u == userName then return false end
return estaOculto(u)
end
function fijarPerfil(u)
if u == userName then return false, "propio" end
if estaFijado(u) then return true end
if #perfilesFijados >= MAX_PERFILES_FIJADOS then return false, "lleno" end
table.insert(perfilesFijados, u)
guardarListaPrefs(CLAVE_PERFILES_FIJADOS, perfilesFijados)
return true
end
function quitarFijado(u)
local i = posicionEnLista(perfilesFijados, u)
if i then
table.remove(perfilesFijados, i)
guardarListaPrefs(CLAVE_PERFILES_FIJADOS, perfilesFijados)
end
end
function ocultarPerfil(u)
if u == userName then return false end
if not estaOculto(u) then
table.insert(usuariosOcultos, u)
guardarListaPrefs(CLAVE_USUARIOS_OCULTOS, usuariosOcultos)
end
quitarFijado(u)
return true
end
function mostrarPerfilOculto(u)
local i = posicionEnLista(usuariosOcultos, u)
if i then
table.remove(usuariosOcultos, i)
guardarListaPrefs(CLAVE_USUARIOS_OCULTOS, usuariosOcultos)
end
end
function textoBotonFijar()
return fijarPerfilesActivo and "Fijar perfiles: Activado" or "Fijar perfiles: Desactivado"
end
function textoBotonOcultar()
return ocultarUsuariosActivo and "Ocultar usuarios: Activado" or "Ocultar usuarios: Desactivado"
end
GITHUB_TOKEN = "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"
GITHUB_OWNER = "Elimpaciente"
GITHUB_REPO = "Tienda-de-complementos-"
GITHUB_API = "https://api.github.com/repos/" .. GITHUB_OWNER .. "/" .. GITHUB_REPO
USUARIOS_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/usuarios.json"
UPDATES_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/Updates.Txt"
MSG_API_URL = "https://api.github.com/repos/Elimpaciente/Tienda-de-complementos-/contents/msg.txt"
CALIFICACIONES_GITHUB_TOKEN = "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"
CALIFICACIONES_GITHUB_API = "https://api.github.com/repos/Elimpaciente/calificaciones-/contents/"
ANDROID_ID_CALIFICACIONES = tostring(Settings.Secure.getString(service.getContentResolver(), Settings.Secure.ANDROID_ID) or "")
RAW_REPO_BASE = "https://raw.githubusercontent.com/Elimpaciente/Tienda-de-complementos-/main/"
HUELLA_DISPOSITIVO_CACHE = nil
function huellaDispositivo()
if HUELLA_DISPOSITIVO_CACHE then return HUELLA_DISPOSITIVO_CACHE end
local ok, resultado = pcall(function()
local md = MessageDigest.getInstance("SHA-256")
local digest = md.digest(bytesDeTexto("tienda-complementos:" .. ANDROID_ID_CALIFICACIONES))
local partes = {}
for i = 0, #digest - 1 do
partes[#partes + 1] = string.format("%02x", digest[i] % 256)
end
return table.concat(partes)
end)
if ok and resultado and resultado ~= "" then
HUELLA_DISPOSITIVO_CACHE = resultado
return resultado
end
return ANDROID_ID_CALIFICACIONES
end
VERSION_CODIGO = "4.0"
mensajeGlobal = ""
NOTIFICACIONES_PREFS = "notificaciones_prefs"
notificacionesLeidas = {}
complementos = {}
filtrados = {}
archivosUsuarios = {}
usuariosData = {}
usuariosActivos = {}
usuarioSeleccionado = nil
vinoDesdeTop5Desarrolladores = false
anunciosUsuario = {}
userName = prefs.getString("user_name", "")
autorizado = false
puedeNotificar = false
usandoCacheLocal = false
usandoEnlacesPublicos = false
misComplementosDisponibles = true
ARCHIVO_RESPALDO = service.getFilesDir().getAbsolutePath() .. "/tienda_cache.dat"
descargasPendientesTabla = {}
TOP_USUARIO = "__top10_descargas__"
NOMBRE_TOP = "Top 10 complementos más descargados"
function esVistaTop()
return usuarioSeleccionado == TOP_USUARIO
end
function obtenerTop10()
local copia = {}
for _, c in ipairs(complementos) do
if not autorOculto(c.autor) then table.insert(copia, c) end
end
table.sort(copia, function(a, b)
local da, db = a.descargas or 0, b.descargas or 0
if da ~= db then return da > db end
local fa, fb = a.fecha_actualizacion or 0, b.fecha_actualizacion or 0
if fa ~= fb then return fa > fb end
return (a.nombre or ""):lower() < (b.nombre or ""):lower()
end)
local top = {}
for i = 1, math.min(10, #copia) do top[i] = copia[i] end
return top
end
function obtenerIdiomaDispositivo()
local locale = Locale.getDefault()
return { codigo_idioma = locale.getLanguage(), codigo_pais = locale.getCountry() }
end
infoIdioma = obtenerIdiomaDispositivo()
function esEspanolEspana()
return infoIdioma.codigo_idioma == "es" and infoIdioma.codigo_pais == "ES"
end
function obtenerCarpetaComplementos()
if esEspanolEspana() then
return "/storage/emulated/0/解说/Complementos"
else
return "/storage/emulated/0/解说/Plugins"
end
end
function obtenerCarpetasComplementosLocales()
local candidatas = {"/storage/emulated/0/解说/Complementos", "/storage/emulated/0/解说/Plugins"}
local validas = {}
for _, c in ipairs(candidatas) do
if File(c).exists() then table.insert(validas, c) end
end
if #validas == 0 then validas = {candidatas[1]} end
return validas
end
BASE_DIRS_LOCALES = obtenerCarpetasComplementosLocales()
function jsonEscape(s)
s = s or ""
s = s:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n"):gsub("\r", "")
return s
end
function nombreArchivoSeguro(texto)
return (texto or "sin_nombre"):gsub("[^%w%-%_%. ]", "_")
end
function githubHeaders()
return {Authorization = "Bearer " .. GITHUB_TOKEN, ["X-GitHub-Api-Version"] = "2022-11-28"}
end
function obtenerNombreVisible(username)
if not username then return "" end
for _, u in ipairs(usuariosData) do
if u.username == username then return (u.public_name and u.public_name ~= "") and u.public_name or username end
end return username
end
function obtenerNombrePublicoParaGuardar(username)
if not username then return nil end
for _, u in ipairs(usuariosData) do
if u.username == username then return (u.public_name and u.public_name ~= "") and u.public_name or nil end
end return nil
end
function obtenerDescripcionPerfil(username)
if not username then return "" end
for _, u in ipairs(usuariosData) do
if u.username == username then
local d = tostring(u.descripcion_perfil or ""):match("^%s*(.-)%s*$") or ""
return d
end
end
return ""
end
function contarComplementosPorUsuario(usuario)
if not usuario then return 0 end
local pub = obtenerNombrePublicoParaGuardar(usuario) or usuario
local count = 0
for _, c in ipairs(complementos) do if c.autor == pub then count = count + 1 end end
return count
end
function serializarComplementos(lista)
local arr = JSONArray()
for _, c in ipairs(lista) do
local obj = JSONObject()
obj.put("id", c.id or "")
obj.put("nombre", c.nombre or "")
obj.put("descripcion", c.descripcion or "")
obj.put("autor", c.autor or "")
obj.put("url_github", c.url_github or "")
obj.put("release_id", c.release_id or "")
obj.put("fecha_actualizacion", c.fecha_actualizacion or 0)
obj.put("descargas", c.descargas or 0)
obj.put("url_tutorial", c.url_tutorial or "")
arr.put(obj)
end
return arr.toString()
end
function deserializarComplementos(json)
local lista = {}
local ok, arr = pcall(JSONArray, json)
if not ok then return lista end
for i = 0, arr.length() - 1 do
local obj = arr.getJSONObject(i)
table.insert(lista, {
id = obj.optString("id", ""),
nombre = obj.optString("nombre", ""),
descripcion = obj.optString("descripcion", ""),
autor = obj.optString("autor", ""),
url_github = obj.optString("url_github", ""),
release_id = obj.optString("release_id", ""),
fecha_actualizacion = obj.optLong("fecha_actualizacion", 0),
descargas = obj.optInt("descargas", 0),
url_tutorial = obj.optString("url_tutorial", "")
})
end
return lista
end
function serializarUsuarios(lista)
local root = JSONObject()
local arr = JSONArray()
for _, u in ipairs(lista) do
local obj = JSONObject()
obj.put("username", u.username or "")
obj.put("public_name", u.public_name or "")
obj.put("can_notify", u.can_notify or false)
obj.put("device_id", u.device_id or "")
obj.put("descripcion_perfil", u.descripcion_perfil or "")
arr.put(obj)
end
root.put("usuarios", arr)
return root.toString()
end
function deserializarUsuarios(json)
local lista = {}
local ok, root = pcall(JSONObject, json)
local arr = nil
if ok and root.has("usuarios") then
arr = root.getJSONArray("usuarios")
else
local ok2, arr2 = pcall(JSONArray, json)
if ok2 then arr = arr2 end
end
if not arr then return lista end
for i = 0, arr.length() - 1 do
local obj = arr.getJSONObject(i)
table.insert(lista, {
username = obj.optString("username", ""),
public_name = obj.optString("public_name", ""),
can_notify = obj.optBoolean("can_notify", false),
device_id = obj.optString("device_id", ""),
descripcion_perfil = obj.optString("descripcion_perfil", "")
})
end
return lista
end
function serializarAnuncios(tabla)
local obj = JSONObject()
for k, v in pairs(tabla) do obj.put(k, v) end
return obj.toString()
end
function deserializarAnuncios(json)
local tabla = {}
local ok, obj = pcall(JSONObject, json)
if not ok then return tabla end
local it = obj.keys()
while it.hasNext() do
local k = it.next()
tabla[k] = obj.getString(k)
end
return tabla
end
function serializarDescargasPendientes(tabla)
local obj = JSONObject()
for k, v in pairs(tabla) do obj.put(k, v) end
return obj.toString()
end
function deserializarDescargasPendientes(json)
local tabla = {}
local ok, obj = pcall(JSONObject, json)
if not ok then return tabla end
local it = obj.keys()
while it.hasNext() do
local k = it.next()
tabla[k] = obj.optInt(k, 0)
end
return tabla
end
function bytesDeTexto(texto)
texto = texto or ""
local n = #texto
local buffer = byte[n]
for i = 1, n do buffer[i-1] = string.byte(texto, i) end
return buffer
end
function textoDeBytes(bytes)
local n = #bytes
local partes = {}
for i = 0, n - 1 do partes[i+1] = string.char(bytes[i] % 256) end
return table.concat(partes)
end
function guardarArchivoRespaldoSeguro(compJson, usrJson, anunJson, descPendJson)
local root = JSONObject()
root.put("complementos_json", compJson)
root.put("usuarios_json", usrJson)
root.put("anuncios_json", anunJson)
root.put("descargas_pendientes_json", descPendJson or "{}")
local jsonString = root.toString()
local b64 = Base64.encodeToString(bytesDeTexto(jsonString), Base64.NO_WRAP)
local fos = FileOutputStream(ARCHIVO_RESPALDO)
local writer = OutputStreamWriter(fos)
writer.write(b64)
writer.flush()
writer.close()
fos.close()
end
function cargarArchivoRespaldoSeguro()
local file = File(ARCHIVO_RESPALDO)
if not file.exists() then return nil end
local fis = FileInputStream(file)
local reader = BufferedReader(InputStreamReader(fis))
local sb = StringBuilder()
local line = reader.readLine()
while line ~= nil do
sb.append(line)
line = reader.readLine()
end
reader.close()
fis.close()
local b64 = sb.toString()
if b64 == "" then return nil end
local jsonString = textoDeBytes(Base64.decode(b64, Base64.NO_WRAP))
local ok, root = pcall(JSONObject, jsonString)
if not ok then return nil end
return {
complementos = deserializarComplementos(root.optString("complementos_json", "[]")),
usuarios = deserializarUsuarios(root.optString("usuarios_json", "[]")),
anuncios = deserializarAnuncios(root.optString("anuncios_json", "{}")),
descargas_pendientes = root.optString("descargas_pendientes_json", "{}")
}
end
function guardarTodoElRespaldo()
guardarArchivoRespaldoSeguro(serializarComplementos(complementos), serializarUsuarios(usuariosData), serializarAnuncios(anunciosUsuario), serializarDescargasPendientes(descargasPendientesTabla))
end
function en_hilo(funcion) Thread(Runnable {run = funcion}).start() end
function leerRespuestaConn(conn)
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream)) local sb = StringBuilder() local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close() return code, sb.toString()
end
function http_get(url, headers)
if redBloqueada and not verificacionSeguridadEnCurso then return -1, "Red bloqueada por verificación de seguridad" end
local conn = URL(url).openConnection()
conn.setRequestMethod("GET") conn.setConnectTimeout(10000) conn.setReadTimeout(15000)
pcall(function() conn.setUseCaches(false) end)
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
return leerRespuestaConn(conn)
end
function urlSinCache(url)
local sep = tostring(url):find("?", 1, true) and "&" or "?"
return url .. sep .. "nc=" .. tostring(System.currentTimeMillis()) .. tostring(math.random(1000, 9999))
end
function urlCodificarRuta(nombre)
local cod = tostring(URLEncoder.encode(nombre, "UTF-8")):gsub("%+", "%%20")
return cod
end
function http_get_bytes(url, headers)
if redBloqueada and not verificacionSeguridadEnCurso then return -1, nil end
local conn = URL(url).openConnection()
conn.setRequestMethod("GET") conn.setConnectTimeout(10000) conn.setReadTimeout(20000)
pcall(function() conn.setUseCaches(false) end)
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local code = conn.getResponseCode()
if code ~= 200 then return code, nil end
local entrada = conn.getInputStream()
local baos = ByteArrayOutputStream()
local buffer = byte[8192]
local n = entrada.read(buffer)
while n ~= -1 do
if n > 0 then baos.write(buffer, 0, n) end
n = entrada.read(buffer)
end
entrada.close()
return code, baos.toByteArray()
end
function shaBlobGit(bytes)
local md = MessageDigest.getInstance("SHA-1")
md.update(bytesDeTexto("blob " .. tostring(#bytes)))
local cero = byte[1]
cero[0] = 0
md.update(cero)
md.update(bytes)
local digest = md.digest()
local partes = {}
for i = 0, #digest - 1 do
partes[#partes + 1] = string.format("%02x", digest[i] % 256)
end
return table.concat(partes)
end
function http_send(method, url, body, headers)
if redBloqueada and not verificacionSeguridadEnCurso then return -1, "Red bloqueada por verificación de seguridad" end
local conn = URL(url).openConnection() conn.setRequestMethod(method) conn.setDoOutput(true)
conn.setRequestProperty("Content-Type", "application/json")
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local writer = OutputStreamWriter(conn.getOutputStream()) writer.write(body) writer.flush() writer.close()
return leerRespuestaConn(conn)
end
function http_upload(method, url, filePath, headers)
if redBloqueada and not verificacionSeguridadEnCurso then return -1, "Red bloqueada por verificación de seguridad" end
local file = File(filePath)
if not file.exists() then return -1, "Archivo no encontrado" end
local fileLen = file.length()
local conn = URL(url).openConnection()
conn.setRequestMethod(method)
conn.setDoOutput(true)
conn.setDoInput(true)
conn.setUseCaches(false)
conn.setConnectTimeout(30000)
conn.setReadTimeout(300000)
conn.setRequestProperty("Content-Type", "application/octet-stream")
conn.setRequestProperty("Content-Length", tostring(fileLen))
pcall(function() conn.setFixedLengthStreamingMode(fileLen) end)
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local fis = BufferedInputStream(FileInputStream(filePath))
local os = conn.getOutputStream()
local buffer = byte[65536]
local escritos = 0
local count = fis.read(buffer, 0, 65536)
while count ~= -1 do
if count > 0 then
os.write(buffer, 0, count)
escritos = escritos + count
end
count = fis.read(buffer, 0, 65536)
end
os.flush()
fis.close()
os.close()
if escritos ~= fileLen then
return -1, "Bytes incompletos: escritos=" .. tostring(escritos) .. " esperados=" .. tostring(fileLen)
end
return leerRespuestaConn(conn)
end
function verificarConexionSeguraGoogle(callback)
en_hilo(function()
local ok, resultado = pcall(function()
local conexion = URL("https://www.google.com").openConnection()
conexion.setConnectTimeout(10000)
conexion.setReadTimeout(10000)
conexion.connect()
local certificados = conexion.getServerCertificates()
local cantidad = Array.getLength(certificados)
local seguro = false
for i = 0, cantidad - 1 do
local certificado = Array.get(certificados, i)
local sujeto = tostring(certificado.getSubjectDN().getName() or "")
local emisor = tostring(certificado.getIssuerDN().getName() or "")
if sujeto:find("Google Trust Services", 1, true) or emisor:find("Google Trust Services", 1, true) then seguro = true break end
end
pcall(function() conexion.disconnect() end)
return seguro
end)
service.postExecute(0, "x", nil, function()
local seguro = ok and resultado == true
verificacionSeguridadEnCurso = false
if seguro then
redBloqueada = false
accesoRedHabilitado = true
end
callback(seguro)
end)
end)
end
function hayConexionInternet()
local cm = service.getSystemService(Context.CONNECTIVITY_SERVICE)
if not cm then return false end
local activeNetwork = cm.getActiveNetworkInfo()
return activeNetwork ~= nil and activeNetwork.isConnected()
end
function obtenerRutaDesdePackagePath()
if package.path then for path in package.path:gmatch("[^;]+") do
local dirPath = path:match("(.*)/[^/]*$") if dirPath and dirPath ~= "" then return dirPath end
end end return "/storage/emulated/0"
end
function versionATupla(str)
str = str or ""
local mayor, menor = str:match("[vV]?(%d+)%.(%d+)")
if mayor and menor then
return tonumber(mayor), tonumber(menor)
end
return 0, 0
end
function esVersionNueva(versionServidor, versionLocal)
local mS, nS = versionATupla(versionServidor)
local mL, nL = versionATupla(versionLocal)
if mS ~= mL then return mS > mL end
return nS > nL
end
function parsearActualizacion(contenido)
local lineas = {} for linea in contenido:gmatch("[^\r\n]+") do table.insert(lineas, linea) end
if #lineas < 2 then return nil end
local version = lineas[1]:match("^%s*(.-)%s*$") local cambios = {} local enlaceZip = nil
for i = 2, #lineas do
local linea = lineas[i]:match("^%s*(.-)%s*$")
if linea:match("https?://") then enlaceZip = linea
elseif linea ~= "" then local cambio = linea:gsub("^%-+%s*", ""):gsub("^•%s*", "")
if cambio ~= "" and #cambio > 3 then table.insert(cambios, cambio) end end
end return { version=version, cambios=cambios, enlaceZip=enlaceZip }
end
function descargarYAplicarActualizacion(enlaceZip, callback)
if not accesoRedHabilitado then
callback(false, "La red está bloqueada por la verificación de seguridad")
return
end
en_hilo(function()
local rutaComplemento = obtenerRutaDesdePackagePath()
local zipPath = "/storage/emulated/0/Download/" .. os.time() .. ".zip"
pcall(function()
local conn = URL(enlaceZip).openConnection() conn.setConnectTimeout(15000) conn.setReadTimeout(60000)
local stream = BufferedInputStream(conn.getInputStream()) local fos = BufferedOutputStream(FileOutputStream(zipPath)) local buffer = byte[65536] local count = stream.read(buffer, 0, 65536)
while count ~= -1 do if count > 0 then fos.write(buffer, 0, count) end count = stream.read(buffer, 0, 65536) end fos.flush() fos.close() stream.close()
end)
local okExtract = pcall(function()
File(rutaComplemento).mkdirs() local fis = FileInputStream(zipPath) local zis = ZipInputStream(fis) local entry = zis.getNextEntry()
while entry ~= nil do local destFile = File(rutaComplemento .. "/" .. entry.getName())
if entry.isDirectory() then destFile.mkdirs()
else destFile.getParentFile().mkdirs() local fos = FileOutputStream(destFile) local buffer = byte[4096] local count = zis.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = zis.read(buffer) end fos.close() end
zis.closeEntry() entry = zis.getNextEntry()
end zis.close() fis.close()
end)
pcall(function() File(zipPath).delete() end)
service.postExecute(0, "x", nil, function()
if okExtract then callback(true, "Actualización aplicada correctamente") else callback(false, "Error al descomprimir") end
end)
end)
end
function mostrarDialogoActualizacion(updateInfo, continuar)
local dialog = registrarVentana(LuaDialog(service))
dialog.setTitle("Actualización disponible")
dialog.setCancelable(false)
local layout = {
LinearLayout, orientation="vertical", padding="30dp",
{TextView, text="Cambios en esta versión:", textSize="16sp", paddingBottom="10dp"},
{ScrollView, layout_width="match", layout_height="300",
{LinearLayout, id="contCambios", orientation="vertical", padding="15"}
},
{LinearLayout, orientation="horizontal", paddingTop="20dp",
{Button, text="Actualizar", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50) dialog.dismiss()
local progDlg = registrarVentana(LuaDialog(service)) progDlg.setTitle("Descargando...") progDlg.setCancelable(false)
progDlg.setView(loadlayout({LinearLayout, padding="24dp", gravity="center", {ProgressBar}})) progDlg.show()
descargarYAplicarActualizacion(updateInfo.enlaceZip, function(ok, msg)
progDlg.dismiss()
if ok then
service.asyncSpeak("Actualización completada. Reabre el complemento.")
else service.asyncSpeak(msg) continuar() end
end)
end},
{Button, text="Más tarde", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) dialog.dismiss() continuar() end}
}
}
local views = {}
local dialogView = loadlayout(layout, views)
if #updateInfo.cambios > 0 then
for _, cambio in ipairs(updateInfo.cambios) do
local tv = TextView(service)
tv.setText("• " .. cambio)
tv.setTextColor(0xFFFFFFFF)
tv.setTextSize(14)
tv.setPadding(8, 4, 8, 4)
views.contCambios.addView(tv)
end
else
local tv = TextView(service)
tv.setText("Mejoras generales.")
tv.setTextColor(0xFFFFFFFF)
tv.setTextSize(14)
tv.setPadding(8, 4, 8, 4)
views.contCambios.addView(tv)
end
dialog.setView(dialogView)
dialog.show()
end
function verificarActualizaciones(continuar)
Http.get(UPDATES_URL, function(status, data)
if status ~= 200 or not data then continuar() return end
local okParse, updateInfo = pcall(parsearActualizacion, data)
if okParse and updateInfo and esVersionNueva(updateInfo.version, VERSION_CODIGO) and updateInfo.enlaceZip then
mostrarDialogoActualizacion(updateInfo, continuar)
else
continuar()
end
end)
end
function parsearUsuariosJSON(body)
local lista = {} local ok, root = pcall(JSONObject, body) if not ok then return lista end
if root.has("usuarios") then local arr = root.getJSONArray("usuarios")
for i = 0, arr.length() - 1 do
local okObj, obj = pcall(function() return arr.getJSONObject(i) end)
if okObj and obj then local u = obj.has("username") and obj.getString("username") or "" local p = obj.has("public_name") and obj.getString("public_name") or ""
local c = obj.optBoolean("can_notify", false)
local dv = obj.optString("device_id", "")
local dp = obj.optString("descripcion_perfil", "")
if u ~= "" then table.insert(lista, {username=u, public_name=p, can_notify=c, device_id=dv, descripcion_perfil=dp}) end
else local okStr, str = pcall(function() return arr.getString(i) end)
if okStr and str ~= "" then table.insert(lista, {username=str, public_name="", can_notify=false, device_id="", descripcion_perfil=""}) end end
end end return lista
end
function extraerZip(zipPath, destDir)
File(destDir).mkdirs()
local fis = BufferedInputStream(FileInputStream(zipPath))
local zis = ZipInputStream(fis)
local entry = zis.getNextEntry()
while entry ~= nil do
local destFile = File(destDir .. "/" .. entry.getName())
if entry.isDirectory() then
destFile.mkdirs()
else
if destFile.getParentFile() then destFile.getParentFile().mkdirs() end
local fos = BufferedOutputStream(FileOutputStream(destFile))
local buffer = byte[65536]
local count = zis.read(buffer, 0, 65536)
while count ~= -1 do
if count > 0 then fos.write(buffer, 0, count) end
count = zis.read(buffer, 0, 65536)
end
fos.flush()
fos.close()
end
zis.closeEntry()
entry = zis.getNextEntry()
end
zis.close()
fis.close()
end
function compressFolder(folderPath, zipFilePath)
local fos = FileOutputStream(zipFilePath)
local zos = ZipOutputStream(BufferedOutputStream(fos))
function addToZip(file, basePath)
local filePath = file.getPath()
local relativePath = basePath and filePath:sub(#basePath + 2) or file.getName()
if file.isDirectory() then
local entries = file.listFiles()
if entries then
for i = 0, #entries - 1 do
addToZip(entries[i], basePath or filePath)
end
end
else
zos.putNextEntry(ZipEntry(relativePath))
local fis = BufferedInputStream(FileInputStream(file))
local buffer = byte[65536]
local count = fis.read(buffer, 0, 65536)
while count ~= -1 do
if count > 0 then zos.write(buffer, 0, count) end
count = fis.read(buffer, 0, 65536)
end
fis.close()
zos.closeEntry()
end
end
addToZip(File(folderPath))
zos.close()
fos.close()
end
function copiarCarpetaRecursivo(origen, destino)
local dirDestino = File(destino)
if not dirDestino.exists() then dirDestino.mkdirs() end
local entries = File(origen).listFiles()
if entries then
for i = 0, #entries - 1 do
local f = entries[i]
local destPath = destino .. "/" .. f.getName()
if f.isDirectory() then
copiarCarpetaRecursivo(f.getPath(), destPath)
else
local fis = BufferedInputStream(FileInputStream(f))
local fos = BufferedOutputStream(FileOutputStream(destPath))
local buffer = byte[65536]
local count = fis.read(buffer, 0, 65536)
while count ~= -1 do
if count > 0 then fos.write(buffer, 0, count) end
count = fis.read(buffer, 0, 65536)
end
fos.flush()
fis.close()
fos.close()
end
end
end
end
function borrarCarpetaRecursivo(path)
local dir = File(path)
if dir.exists() then
local entries = dir.listFiles()
if entries then
for i = 0, #entries - 1 do
local f = entries[i]
if f.isDirectory() then borrarCarpetaRecursivo(f.getPath()) else f.delete() end
end
end
dir.delete()
end
end
function docIdDesdeName(name) return name:match("([^/]+)$") end
function estaComplementoEncriptado(rutaArchivo)
local ok, fis = pcall(FileInputStream, rutaArchivo)
if not ok then return false end
local reader = BufferedReader(InputStreamReader(fis))
local encontrado = false
local linea = reader.readLine()
while linea ~= nil do
local lineaTxt = tostring(linea)
local match1 = lineaTxt:match("=%s*[%w+/=]+")
if match1 and #match1 > 15 and (match1:find("%d") or match1:find("%+") or match1:find("/")) then
encontrado = true
break
end
local match2 = lineaTxt:match('loadstring%s*%(%s*"([%w+/=]+)"')
if match2 and #match2 > 10 then
encontrado = true
break
end
for bloqueTxt in lineaTxt:gmatch("[%w+/=]+") do
if #bloqueTxt >= 30 and (bloqueTxt:find("%+") or bloqueTxt:find("=")) then
local sinBase64 = bloqueTxt:gsub("[A-Za-z0-9%+%/=]", "")
if #sinBase64 == 0 and bloqueTxt:find("%u") and bloqueTxt:find("%l") then
encontrado = true
break
end
end
end
if encontrado then break end
linea = reader.readLine()
end
reader.close()
return encontrado
end
function listarArchivosPublicosSync()
local ok, code, body = pcall(http_get, urlSinCache(USUARIOS_URL))
if not (ok and code == 200) then return nil end
local items = {}
local vistos = {}
for _, u in ipairs(parsearUsuariosJSON(body)) do
local pub = (u.public_name and u.public_name ~= "") and u.public_name or u.username
if pub and pub ~= "" then
local nombre = nombreArchivoSeguro(pub) .. ".json"
if not vistos[nombre] then
vistos[nombre] = true
local cod = tostring(URLEncoder.encode(nombre, "UTF-8")):gsub("%+", "%%20")
table.insert(items, {name = nombre, sha = "", download_url = RAW_REPO_BASE .. cod})
end
end
end
if #items == 0 then return nil end
usandoEnlacesPublicos = true
return items
end
function listarArchivosUsuariosSync()
local url = GITHUB_API .. "/contents/"
local ok, code, body = pcall(http_get, url)
if not (ok and code == 200) then
ok, code, body = pcall(http_get, url, githubHeaders())
end
if not ok or code ~= 200 then return listarArchivosPublicosSync() end
local okP, arr = pcall(JSONArray, body)
if not okP then return listarArchivosPublicosSync() end
usandoEnlacesPublicos = false
local items = {}
for i = 0, arr.length() - 1 do
local it = arr.getJSONObject(i)
local tipo = it.optString("type", "")
local nombre = it.optString("name", "")
if tipo == "file" and nombre:match("%.json$") then
table.insert(items, {name = nombre, sha = it.optString("sha", ""), download_url = it.optString("download_url", "")})
end
end
return items
end
function cargarComplementosSync(permitidosArchivo)
local items
if permitidosArchivo and next(permitidosArchivo) ~= nil then
items = {}
usandoEnlacesPublicos = false
for nombreArchivo, _ in pairs(permitidosArchivo) do
table.insert(items, {name = nombreArchivo, sha = "", download_url = RAW_REPO_BASE .. urlCodificarRuta(nombreArchivo), directo = true})
end
table.sort(items, function(a, b) return a.name < b.name end)
else
items = listarArchivosUsuariosSync()
end
if not items then return {}, false end
local lista = {}
local anunciosTemp = {}
local archivosTemp = {}
local todoCargoBien = true
misComplementosDisponibles = true
local miPub = obtenerNombrePublicoParaGuardar(userName) or userName
local miArchivo = nombreArchivoSeguro(miPub) .. ".json"
for _, item in ipairs(items) do
if permitidosArchivo and next(permitidosArchivo) ~= nil and not permitidosArchivo[item.name] then
else
local ok, code, body
local sinArchivo = false
if item.name == miArchivo then
ok, code, body = pcall(http_get, urlSinCache(item.download_url))
if ok and code == 200 then
misComplementosDisponibles = true
elseif ok and code == 404 and item.directo then
misComplementosDisponibles = true
sinArchivo = true
else
ok, code, body = pcall(http_get, GITHUB_API .. "/contents/" .. urlCodificarRuta(item.name), githubHeaders())
if ok and code == 200 then
local okW, wrap = pcall(JSONObject, body)
if okW and wrap and wrap.has("content") then
local contentBase64 = wrap.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
body = tostring(String(bytes, StandardCharsets.UTF_8))
else
ok = false
end
end
if ok and code == 200 then
misComplementosDisponibles = true
else
ok, code, body = pcall(http_get, urlSinCache(item.download_url))
if ok and code == 200 then
misComplementosDisponibles = true
else
misComplementosDisponibles = false
end
end
end
else
ok, code, body = pcall(http_get, urlSinCache(item.download_url))
if ok and code == 404 and item.directo then sinArchivo = true end
end
if ok and code == 200 then
local okP, root = pcall(JSONObject, body)
if okP then
local pub = root.optString("usuario_publico", (item.name:gsub("%.json$", "")))
archivosTemp[pub] = {sha = item.sha, filename = item.name}
local anuncio = root.optString("anuncio", "")
if anuncio ~= "" then anunciosTemp[pub] = anuncio end
if root.has("complementos") then
local arrComp = root.getJSONArray("complementos")
for i = 0, arrComp.length() - 1 do
local c = arrComp.getJSONObject(i)
table.insert(lista, {
id = pub .. "::" .. c.optString("nombre", ""),
nombre = c.optString("nombre", ""),
descripcion = c.optString("descripcion", ""),
autor = pub,
url_github = c.optString("url_github", ""),
release_id = c.optString("release_id", ""),
fecha_actualizacion = c.optLong("fecha_actualizacion", 0),
descargas = c.optInt("descargas", 0),
url_tutorial = c.optString("url_tutorial", "")
})
end
end
else
if not usandoEnlacesPublicos then todoCargoBien = false end
end
elseif not sinArchivo then
if not usandoEnlacesPublicos then todoCargoBien = false end
end
end
end
if usandoEnlacesPublicos and next(archivosTemp) == nil then return {}, false end
archivosUsuarios = archivosTemp
for k, _ in pairs(anunciosUsuario) do anunciosUsuario[k] = nil end
for k, v in pairs(anunciosTemp) do anunciosUsuario[k] = v end
return lista, todoCargoBien
end
function listaDelAutorEnMemoria(pub)
local lista = {}
for _, c in ipairs(complementos) do
if c.autor == pub then table.insert(lista, c) end
end
return lista
end
function leerArchivoFrescoConShaSync(filename)
local ruta = urlCodificarRuta(filename)
local okR, codeR, bytes = pcall(http_get_bytes, urlSinCache(RAW_REPO_BASE .. ruta))
if okR and codeR == 200 and bytes then
local okS, sha = pcall(shaBlobGit, bytes)
if okS and sha then
return 200, tostring(String(bytes, StandardCharsets.UTF_8)), sha
end
end
if okR and codeR == 404 then return 404, nil, nil end
local okA, codeA, bodyA = pcall(http_get, GITHUB_API .. "/contents/" .. ruta, githubHeaders())
if okA and codeA == 200 then
local okW, wrap = pcall(JSONObject, bodyA)
if okW and wrap and wrap.has("content") and wrap.has("sha") then
local b64 = wrap.getString("content"):gsub("\n", "")
local bytesA = Base64.decode(b64, Base64.NO_WRAP)
return 200, tostring(String(bytesA, StandardCharsets.UTF_8)), wrap.getString("sha")
end
elseif okA and codeA == 404 then
return 404, nil, nil
end
return -1, nil, nil
end
function ponerArchivoRepoSync(filename, contenido, sha, mensaje)
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(contenido) writer.flush() writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local body = "{\"message\":\"" .. jsonEscape(mensaje or ("Actualizar " .. filename)) .. "\",\"content\":\"" .. b64 .. "\""
if sha and sha ~= "" then body = body .. ",\"sha\":\"" .. sha .. "\"" end
body = body .. "}"
local ok, code, respBody = pcall(http_send, "PUT", GITHUB_API .. "/contents/" .. urlCodificarRuta(filename), body, githubHeaders())
if ok and (code == 200 or code == 201) then
local okP, rj = pcall(JSONObject, respBody)
local nuevoSha = nil
if okP and rj.has("content") then
local okC, cObj = pcall(function() return rj.getJSONObject("content") end)
if okC and cObj.has("sha") then nuevoSha = cObj.getString("sha") end
end
return true, code, nuevoSha
end
if not ok then return false, -1, nil end
return false, code, nil
end
function esperarReintentoGitHub(intento)
pcall(function() Thread.sleep(math.random(150, 450) * intento) end)
end
function guardarArchivoUsuarioSync(pub)
local filename = nombreArchivoSeguro(pub) .. ".json"
local maxIntentos = 6
for intento = 1, maxIntentos do
local codeL, textoSrv, shaSrv = leerArchivoFrescoConShaSync(filename)
if codeL == 200 and textoSrv then
local okS, rootS = pcall(JSONObject, textoSrv)
if okS and rootS and rootS.has("complementos") then
local okA, arrS = pcall(function() return rootS.getJSONArray("complementos") end)
if okA and arrS then
local mayor = {}
for i = 0, arrS.length() - 1 do
local o = arrS.getJSONObject(i)
mayor[o.optString("nombre", "")] = o.optInt("descargas", 0)
end
for _, c in ipairs(listaDelAutorEnMemoria(pub)) do
local d = mayor[c.nombre or ""]
if d and d > (c.descargas or 0) then c.descargas = d end
end
end
end
elseif codeL ~= 404 then
local existente = archivosUsuarios[pub]
shaSrv = (existente and existente.sha and existente.sha ~= "") and existente.sha or nil
end
local raiz = JSONObject()
raiz.put("usuario_publico", pub)
raiz.put("anuncio", anunciosUsuario[pub] or "")
local arr = JSONArray()
for _, c in ipairs(listaDelAutorEnMemoria(pub)) do
local obj = JSONObject()
obj.put("nombre", c.nombre or "")
obj.put("descripcion", c.descripcion or "")
obj.put("url_github", c.url_github or "")
obj.put("release_id", c.release_id or "")
obj.put("fecha_actualizacion", c.fecha_actualizacion or 0)
obj.put("descargas", c.descargas or 0)
obj.put("url_tutorial", c.url_tutorial or "")
arr.put(obj)
end
raiz.put("complementos", arr)
local okPut, code, nuevoSha = ponerArchivoRepoSync(filename, raiz.toString(), shaSrv, "Actualizar " .. filename)
if okPut then
archivosUsuarios[pub] = {sha = nuevoSha, filename = filename}
return true
end
if code == 409 or code == 422 then
archivosUsuarios[pub] = nil
esperarReintentoGitHub(intento)
else
return false
end
end
return false
end
function incrementarDescargasAtomicoSync(pub, nombreItem, delta)
local filename = nombreArchivoSeguro(pub) .. ".json"
for intento = 1, 6 do
local codeL, textoSrv, shaSrv = leerArchivoFrescoConShaSync(filename)
if codeL == 404 then return true, nil end
if codeL == 200 and textoSrv and shaSrv then
local okS, rootS = pcall(JSONObject, textoSrv)
if not okS or not rootS or not rootS.has("complementos") then return false, nil end
local arrS = rootS.getJSONArray("complementos")
local nuevoValor = nil
for i = 0, arrS.length() - 1 do
local o = arrS.getJSONObject(i)
if o.optString("nombre", "") == nombreItem then
nuevoValor = o.optInt("descargas", 0) + delta
o.put("descargas", nuevoValor)
break
end
end
if nuevoValor == nil then return true, nil end
local okPut, code, nuevoSha = ponerArchivoRepoSync(filename, rootS.toString(), shaSrv, "Actualizar " .. filename)
if okPut then
archivosUsuarios[pub] = {sha = nuevoSha, filename = filename}
return true, nuevoValor
end
if code ~= 409 and code ~= 422 then return false, nil end
end
esperarReintentoGitHub(intento)
end
return false, nil
end
CLAVE_PERFIL_PENDIENTE = "perfilPendienteRegistro"
function guardarPerfilPendiente(entrada)
pcall(function()
local o = JSONObject()
o.put("username", tostring(entrada.username or ""))
o.put("public_name", tostring(entrada.public_name or ""))
o.put("device_id", tostring(entrada.device_id or ""))
o.put("descripcion_perfil", tostring(entrada.descripcion_perfil or ""))
o.put("t", os.time())
prefs.edit().putString(CLAVE_PERFIL_PENDIENTE, o.toString()).apply()
end)
end
function olvidarPerfilPendiente()
pcall(function() prefs.edit().remove(CLAVE_PERFIL_PENDIENTE).apply() end)
end
function aplicarPerfilPendiente(lista)
local crudo = prefs.getString(CLAVE_PERFIL_PENDIENTE, "")
if crudo == "" then return lista end
local ok, o = pcall(JSONObject, crudo)
if not ok or not o then olvidarPerfilPendiente() return lista end
local un = o.optString("username", "")
local t = o.optLong("t", 0)
if un == "" or un ~= userName or os.time() - t > 1800 then olvidarPerfilPendiente() return lista end
for _, u in ipairs(lista) do
if u.username == un then
if (u.public_name or "") ~= "" then
olvidarPerfilPendiente()
else
u.public_name = o.optString("public_name", "")
u.can_notify = true
end
return lista
end
end
table.insert(lista, {username = un, public_name = o.optString("public_name", ""), can_notify = true, device_id = o.optString("device_id", ""), descripcion_perfil = o.optString("descripcion_perfil", "")})
return lista
end
function prepararUsuariosYAutorizacionSync()
local ok, code, body = pcall(http_get, urlSinCache(USUARIOS_URL)) local repoUsers = {}
autorizado = false
puedeNotificar = false
if ok and code == 200 then
repoUsers = aplicarPerfilPendiente(parsearUsuariosJSON(body))
usuariosData = repoUsers
if userName ~= "" then
for _, u in ipairs(repoUsers) do if u.username == userName then
autorizado = true
puedeNotificar = u.can_notify or false
break
end end
end
end
local known = {}
local permitidosArchivo = {}
for _, u in ipairs(repoUsers) do
if u.public_name and u.public_name ~= "" then
known[u.public_name] = true
permitidosArchivo[nombreArchivoSeguro(u.public_name) .. ".json"] = true
end
end
local lista = {} for _, u in ipairs(usuariosData) do table.insert(lista, u.username) end
table.sort(lista, function(a, b) if a == userName then return true end if b == userName then return false end return obtenerNombreVisible(a):lower() < obtenerNombreVisible(b):lower() end)
return lista, (ok and code == 200), known, permitidosArchivo
end
function leerArchivoRepoTextoSync(nombre)
local okF, codeF, bytesF = pcall(http_get_bytes, urlSinCache(RAW_REPO_BASE .. urlCodificarRuta(nombre)))
if okF and codeF == 200 and bytesF then return true, tostring(String(bytesF, StandardCharsets.UTF_8)) end
if okF and codeF == 404 then return true, "" end
local ok, code, body = pcall(http_get, GITHUB_API .. "/contents/" .. urlCodificarRuta(nombre), githubHeaders())
if ok and code == 200 then
local okP, rj = pcall(JSONObject, body)
if okP and rj and rj.has("content") then
local b64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(b64, Base64.NO_WRAP)
return true, tostring(String(bytes, StandardCharsets.UTF_8))
end
elseif ok and code == 404 then
return true, ""
end
local ok2, code2, bytes2 = pcall(http_get_bytes, urlSinCache(RAW_REPO_BASE .. urlCodificarRuta(nombre)))
if ok2 and code2 == 200 and bytes2 then return true, tostring(String(bytes2, StandardCharsets.UTF_8)) end
if ok2 and code2 == 404 then return true, "" end
return false, ""
end
function parsearExpulsados(body)
local lista = {}
local legado = {}
for linea in (body or ""):gmatch("[^\r\n]+") do
local limpio = linea:match("^%s*(.-)%s*$")
if limpio ~= "" then
if limpio:find("|", 1, true) then
local usr, dev = limpio:match("^(.-)|(.*)$")
table.insert(lista, {username = (usr or ""):match("^%s*(.-)%s*$"), device_id = (dev or ""):match("^%s*(.-)%s*$")})
else
table.insert(legado, limpio)
end
end
end
local i = 1
while i <= #legado do
table.insert(lista, {username = legado[i], device_id = legado[i + 1] or ""})
i = i + 2
end
return lista
end
function verificarExpulsadoSync(nombreUsuario, idDispositivo)
local ok, texto = leerArchivoRepoTextoSync("expulsados.txt")
if not ok then return false end
local lista = parsearExpulsados(texto)
local huella = huellaDispositivo()
local usuarioActual = (nombreUsuario or ""):match("^%s*(.-)%s*$"):lower()
for _, e in ipairs(lista) do
local usuarioCoincide = e.username ~= "" and e.username:lower() == usuarioActual
local dispositivoCoincide = e.device_id ~= "" and ((idDispositivo ~= "" and e.device_id == idDispositivo) or (huella ~= "" and e.device_id == huella))
if usuarioCoincide or dispositivoCoincide then
return true
end
end
return false
end
function nombrePublicoEnUso(nombre)
local nombreLower = (nombre or ""):lower()
for _, u in ipairs(usuariosData) do
if u.username ~= userName and u.public_name and u.public_name ~= "" and u.public_name:lower() == nombreLower then return true end
end
return false
end
function leerUsuariosDesdeAPISync()
local ok, code, body = pcall(http_get, "https://api.github.com/repos/Elimpaciente/Rudyy1224/contents/usuarios.json?t=" .. os.time(), githubHeaders())
if not (ok and code == 200) then return nil, nil end
local okP, rj = pcall(JSONObject, body)
if not okP or not rj then return nil, nil end
local sha = rj.has("sha") and rj.getString("sha") or nil
local content = ""
if rj.has("content") then
local contentBase64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
content = tostring(String(bytes, StandardCharsets.UTF_8))
end
return parsearUsuariosJSON(content), sha
end
function obtenerSHAUsuariosSync()
local _, sha = leerUsuariosDesdeAPISync()
return sha
end
function intentarGuardarUsuariosJSON(lista, sha, mensaje)
local limpia = {}
for _, u in ipairs(lista or {}) do
local un = tostring(u.username or "")
if un ~= "" then
table.insert(limpia, {
username = un,
public_name = tostring(u.public_name or ""),
can_notify = not not u.can_notify,
device_id = tostring(u.device_id or ""),
descripcion_perfil = tostring(u.descripcion_perfil or "")
})
end
end
local esUpdateDesc = mensaje and tostring(mensaje):find("Actualizar descripción", 1, true)
local listaSrv = nil
local okSrv, codeSrv, bodySrv = pcall(http_get, USUARIOS_URL .. "?t=" .. os.time())
if okSrv and codeSrv == 200 and bodySrv then
listaSrv = parsearUsuariosJSON(bodySrv)
end
if listaSrv then
local descMap = {}
for _, u in ipairs(listaSrv) do
local d = tostring(u.descripcion_perfil or ""):match("^%s*(.-)%s*$") or ""
if u.username and d ~= "" then descMap[u.username] = d end
end
for _, u in ipairs(limpia) do
local d = tostring(u.descripcion_perfil or ""):match("^%s*(.-)%s*$") or ""
if d == "" and descMap[u.username] then
if not (esUpdateDesc and userName and u.username == userName) then
u.descripcion_perfil = descMap[u.username]
end
end
end
end
local contenido = serializarUsuarios(limpia)
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(contenido) writer.flush() writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local body = "{\"message\":\"" .. jsonEscape(mensaje or "Actualizar usuarios") .. "\",\"branch\":\"main\",\"content\":\"" .. b64 .. "\""
if sha and sha ~= "" then body = body .. ",\"sha\":\"" .. sha .. "\"" end
body = body .. "}"
local ok, code = pcall(http_send, "PUT", "https://api.github.com/repos/Elimpaciente/Rudyy1224/contents/usuarios.json", body, githubHeaders())
if not ok then return false, -1 end
return (code == 200 or code == 201), code
end
function guardarUsuariosJSONSync(lista, mensaje)
local _, sha = leerUsuariosDesdeAPISync()
local ok, _ = intentarGuardarUsuariosJSON(lista, sha, mensaje)
return ok
end
function registrarUsuarioSync(nombrePublico, forzar)
local maxIntentos = 10
for intento = 1, maxIntentos do
local lista, sha = leerUsuariosDesdeAPISync()
if not lista then
local okR, codeR, bodyR = pcall(http_get, USUARIOS_URL .. "?t=" .. os.time())
if okR and codeR == 200 then
lista = parsearUsuariosJSON(bodyR)
else
lista = {}
end
sha = obtenerSHAUsuariosSync()
end
local encontrado = false
for _, u in ipairs(lista) do
if u.username ~= userName and u.public_name and u.public_name ~= "" and tostring(u.public_name):lower() == tostring(nombrePublico):lower() then return false, "nombre_en_uso" end
end
for _, u in ipairs(lista) do
if u.username == userName then
if (not forzar) and u.public_name and u.public_name ~= "" then return false, "ya_existe" end
u.public_name = nombrePublico
u.can_notify = true
u.device_id = huellaDispositivo()
if u.descripcion_perfil == nil then u.descripcion_perfil = "" end
encontrado = true
break
end
end
if not encontrado then
table.insert(lista, {username = userName, public_name = nombrePublico, can_notify = true, device_id = huellaDispositivo(), descripcion_perfil = ""})
end
local ok, code = intentarGuardarUsuariosJSON(lista, sha, "Crear/actualizar perfil de " .. nombrePublico)
if ok then
usuariosData = lista
autorizado = true
puedeNotificar = true
guardarPerfilPendiente({username = userName, public_name = nombrePublico, device_id = huellaDispositivo(), descripcion_perfil = ""})
return true
end
if code ~= 409 and code ~= 422 then return false, "error" end
esperarReintentoGitHub(intento)
end
return false, "ocupado"
end
function quitarUsuarioTxtSync()
local maxIntentos = 6
for intento = 1, maxIntentos do
local lista, sha = leerUsuariosDesdeAPISync()
if not lista then
local okR, codeR, bodyR = pcall(http_get, USUARIOS_URL .. "?t=" .. os.time())
if okR and codeR == 200 then
lista = parsearUsuariosJSON(bodyR)
else
lista = {}
end
sha = obtenerSHAUsuariosSync()
end
local nueva = {}
for _, u in ipairs(lista) do
if u.username ~= userName then table.insert(nueva, u) end
end
local ok, code = intentarGuardarUsuariosJSON(nueva, sha, "Eliminar perfil de " .. userName)
if ok then
usuariosData = nueva
autorizado = false
puedeNotificar = false
olvidarPerfilPendiente()
return true
end
if code ~= 409 and code ~= 422 then return false end
pcall(function() Thread.sleep(150 * intento) end)
end
return false
end
function completarDeviceIdPropioSync()
if userName == "" then return end
local conocido = false
for _, u in ipairs(usuariosData) do
if u.username == userName and u.public_name and u.public_name ~= "" then
conocido = true
if (u.device_id or "") ~= "" then return end
end
end
if not conocido then return end
for intento = 1, 4 do
local lista, sha = leerUsuariosDesdeAPISync()
if not lista then return end
local propio = nil
for _, u in ipairs(lista) do
if u.username == userName then propio = u break end
end
if not propio or (propio.public_name or "") == "" or (propio.device_id or "") ~= "" then return end
propio.device_id = huellaDispositivo()
local ok, code = intentarGuardarUsuariosJSON(lista, sha, "Registrar ID de dispositivo de " .. userName)
if ok then
for _, u in ipairs(usuariosData) do
if u.username == userName then u.device_id = propio.device_id end
end
return
end
if code ~= 409 and code ~= 422 then return end
pcall(function() Thread.sleep(150 * intento) end)
end
end
function necesitaCrearPerfil()
if userName == "" then return false end
for _, u in ipairs(usuariosData) do
if u.username == userName and u.public_name and u.public_name ~= "" then return false end
end
return true
end
function mostrarProgreso(mensaje, silencioso)
local progDlg = registrarVentana(LuaDialog(service)) progDlg.setTitle(mensaje) progDlg.setCancelable(false)
progDlg.setView(loadlayout({LinearLayout, padding="24dp", gravity="center", {ProgressBar}})) progDlg.show()
if not silencioso then service.asyncSpeak(mensaje) end
return progDlg
end
function volverAPantallaUsuarios()
doVibrate(50)
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
vinoDesdeTop5Desarrolladores = false
mostrarDialogoUsuarios()
end
function cargarNotificaciones()
for clave in pairs(notificacionesLeidas) do notificacionesLeidas[clave] = nil end
local prefsNotif = service.getSharedPreferences(NOTIFICACIONES_PREFS, Context.MODE_PRIVATE)
local textoGuardado = prefsNotif.getString("leidas", "[]")
local ok, leidas = pcall(JSONArray, textoGuardado)
if ok and leidas then
for i = 0, leidas.length() - 1 do
local clave = leidas.optString(i, "")
if clave ~= "" then notificacionesLeidas[clave] = true end
end
end
end
function marcarNotificacionComoLeida(mensaje)
notificacionesLeidas[mensaje] = true local jsonArray = JSONArray()
for k, _ in pairs(notificacionesLeidas) do jsonArray.put(k) end
service.getSharedPreferences(NOTIFICACIONES_PREFS, 0).edit().putString("leidas", jsonArray.toString()).apply()
end
function obtenerTodasLasNotificaciones()
local todas = {}
if mensajeGlobal ~= "" then
for linea in mensajeGlobal:gmatch(".-%(.- | %d+%)") do
linea = linea:match("^%s*(.-)%s*$")
if linea ~= "" then
local mensaje, autor, ts = linea:match("^(.-) %((.-) | (%d+)%)$")
local lineaFormateada = linea
if mensaje and autor and ts then
local fechaLocal = os.date("%d/%m/%Y %H:%M", tonumber(ts))
if fechaLocal then
lineaFormateada = mensaje .. " (" .. autor .. " | " .. fechaLocal .. ")"
end
end
local leida = notificacionesLeidas[lineaFormateada] or notificacionesLeidas[linea] or false
table.insert(todas, {mensaje=lineaFormateada, leida=leida, autor=autor, linea=linea})
end
end
end
return todas
end
function contarNotificacionesNoLeidas()
local todas = obtenerTodasLasNotificaciones()
local count = 0
for _, n in ipairs(todas) do
if not n.leida then count = count + 1 end
end
return count
end
function textoNotificaciones(cantidad)
if cantidad == 1 then
return "Tienes 1 notificación nueva"
else
return "Tienes " .. cantidad .. " notificaciones nuevas"
end
end
function actualizarBotonNotifPrincipal()
if not btnNotifPrincipalRef then return end
local noLeidas = contarNotificacionesNoLeidas()
btnNotifPrincipalRef.setText(noLeidas > 0 and textoNotificaciones(noLeidas) or "Notificaciones")
btnNotifPrincipalRef.setBackgroundColor(noLeidas > 0 and 0xFFFF5722 or 0xFF4CAF50)
end
ordenarComplementos = nil
recargarTodo = nil
sincronizarDescargasPendientes = nil
function mostrarErrorConexion()
doVibrate(50)
if dlgErrorConexion and dlgErrorConexion.isShowing() then dlgErrorConexion.dismiss() end
dlgErrorConexion = registrarVentana(LuaDialog(service))
dlgErrorConexion.setTitle("Error de conexión")
dlgErrorConexion.setCancelable(false)
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", backgroundColor="0xFF000000", padding="20dp",
{TextView, text="No se pudo conectar a internet ni al servidor de respaldo.\nIntenta más tarde.", textColor="0xFFFF5722", textSize="16sp", gravity="center", padding="16dp"},
{Button, id="btnReintentar", text="Reintentar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCerrarError", text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
local views = {}
dlgErrorConexion.setView(loadlayout(layout, views))
dlgErrorConexion.show()
views.btnReintentar.setOnClickListener({onClick = function()
doVibrate(50)
dlgErrorConexion.dismiss()
recargarTodo()
end})
views.btnCerrarError.setOnClickListener({onClick = function()
doVibrate(50)
dlgErrorConexion.dismiss()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
end})
end
function recargarDatos(alTerminar)
if not accesoRedHabilitado then return end
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
local progDlg = mostrarProgreso("Conectando al servidor...", true)
progDlg.setCancelable(true)
local cargaCancelada = false
progDlg.setOnCancelListener({onCancel = function()
doVibrate(50)
cargaCancelada = true
end})
en_hilo(function()
local usuarios, usuariosOk, knownAutores, permitidosArchivo = prepararUsuariosYAutorizacionSync()
local nuevaLista, githubOk = cargarComplementosSync(permitidosArchivo)
if knownAutores then
local filtrada = {}
for _, c in ipairs(nuevaLista or {}) do
if c.autor and knownAutores[c.autor] then table.insert(filtrada, c) end
end
nuevaLista = filtrada
end
if githubOk and usuariosOk then
service.postExecute(0, "x", nil, function()
if progDlg and progDlg.isShowing() then progDlg.dismiss() end
if cargaCancelada then return end
complementos = nuevaLista
usuariosActivos = usuarios
usandoCacheLocal = usandoEnlacesPublicos
guardarTodoElRespaldo()
if not usandoEnlacesPublicos then
sincronizarDescargasPendientes()
end
alTerminar()
if not usandoEnlacesPublicos then en_hilo(completarDeviceIdPropioSync) end
end)
else
service.postExecute(0, "x", nil, function()
if progDlg and progDlg.isShowing() then
progDlg.setTitle("Cargando servidor de respaldo...")
end
end)
local respaldo = cargarArchivoRespaldoSeguro()
service.postExecute(0, "x", nil, function()
if progDlg and progDlg.isShowing() then progDlg.dismiss() end
if cargaCancelada then return end
if respaldo then
usuariosData = respaldo.usuarios
local permitidos = {}
for _, u in ipairs(usuariosData or {}) do
if u.public_name and u.public_name ~= "" then permitidos[u.public_name] = true end
end
local compsFiltrados = {}
for _, c in ipairs(respaldo.complementos or {}) do
if c.autor and permitidos[c.autor] then table.insert(compsFiltrados, c) end
end
complementos = compsFiltrados
for k in pairs(anunciosUsuario) do anunciosUsuario[k] = nil end
for k, v in pairs(respaldo.anuncios or {}) do
if permitidos[k] then anunciosUsuario[k] = v end
end
descargasPendientesTabla = deserializarDescargasPendientes(respaldo.descargas_pendientes or "{}")
usandoCacheLocal = true
autorizado = false
puedeNotificar = false
if userName ~= "" then
for _, u in ipairs(usuariosData) do
if u.username == userName then
autorizado = true
puedeNotificar = u.can_notify or false
break
end
end
end
local listaNombres = {}
for _, u in ipairs(usuariosData) do table.insert(listaNombres, u.username) end
table.sort(listaNombres, function(a, b) if a == userName then return true end if b == userName then return false end return obtenerNombreVisible(a):lower() < obtenerNombreVisible(b):lower() end)
usuariosActivos = listaNombres
alTerminar()
else
if hayConexionInternet() then
complementos = {}
usuariosActivos = {}
usandoCacheLocal = false
alTerminar()
else
mostrarErrorConexion()
end
end
end)
end
end)
end
recargarTodo = function() recargarDatos(function() mostrarDialogoUsuarios() end) end
function refrescarVistaLocalDelAutor()
if esVistaTop() then filtrados = obtenerTop10() actualizarListaUI() return end
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
filtrados = {} for _, c in ipairs(complementos) do if c.autor == pub then table.insert(filtrados, c) end end
ordenarComplementos(filtrados, ordenActual) actualizarListaUI()
end
function incrementarContadorDescargas(complementoId)
en_hilo(function()
local pub, nombreItem = complementoId:match("^(.-)::(.*)$")
local exito = false
if pub then
for _, c in ipairs(complementos) do
if c.id == complementoId then c.descargas = (c.descargas or 0) + 1 break end
end
if not usandoCacheLocal then
local okInc, valorServidor = incrementarDescargasAtomicoSync(pub, nombreItem, 1)
exito = okInc
if okInc and valorServidor then
for _, c in ipairs(complementos) do
if c.id == complementoId then c.descargas = valorServidor break end
end
end
end
end
if not exito then
descargasPendientesTabla[complementoId] = (descargasPendientesTabla[complementoId] or 0) + 1
guardarTodoElRespaldo()
end
service.postExecute(0, "x", nil, function()
for j, f in ipairs(filtrados) do
if f.id == complementoId then
for _, c in ipairs(complementos) do
if c.id == complementoId then filtrados[j].descargas = c.descargas break end
end
break
end
end
if tvTitulo then
local nombreVisible = obtenerNombreVisible(usuarioSeleccionado) or ""
tvTitulo.setText(nombreVisible .. "\n(" .. contarComplementosPorUsuario(usuarioSeleccionado) .. " complementos)")
end
guardarTodoElRespaldo()
if esVistaTop() and (searchEditText == nil or tostring(searchEditText.getText().toString()) == "") then filtrados = obtenerTop10() end
actualizarListaUI()
end)
end)
end
sincronizarDescargasPendientes = function()
local ids = {}
for id, _ in pairs(descargasPendientesTabla) do table.insert(ids, id) end
if #ids == 0 then return end
en_hilo(function()
local restantes = {}
for k, v in pairs(descargasPendientesTabla) do restantes[k] = v end
for _, id in ipairs(ids) do
local cantidad = descargasPendientesTabla[id]
local pub, nombreItem = id:match("^(.-)::(.*)$")
if pub and cantidad and cantidad > 0 then
local okInc, valorServidor = incrementarDescargasAtomicoSync(pub, nombreItem, cantidad)
if okInc then
restantes[id] = nil
if valorServidor then
for _, c in ipairs(complementos) do
if c.id == id then c.descargas = valorServidor break end
end
end
end
else
restantes[id] = nil
end
end
descargasPendientesTabla = restantes
guardarTodoElRespaldo()
end)
end
function abrirTutorial(url)
if url and url ~= "" then
service.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
end
end
function mostrarDialogoPostInstalacion(nombre, url)
if not url or url == "" then return end
doVibrate(50)
local d = registrarVentana(LuaDialog(service)) d.setTitle("Instalación Exitosa")
d.setMessage("¿Quieres ver el tutorial de " .. nombre .. "?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Sí", layout_weight=1, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
abrirTutorial(url)
end}
}
d.setView(loadlayout(layout))
d.show()
end
function instalarComplemento(complemento)
local progDlg = mostrarProgreso("Descargando complemento...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. complemento.nombre .. ".zip"
local errorEspecifico = nil
local okDownload = pcall(function()
local conn = URL(complemento.url_github).openConnection()
conn.setConnectTimeout(10000)
conn.setReadTimeout(30000)
local respCode = conn.getResponseCode()
if respCode == 404 then
errorEspecifico = "404"
error("404_NOT_FOUND")
elseif respCode ~= 200 then
error("DOWNLOAD_ERROR_" .. respCode)
end
local stream = BufferedInputStream(conn.getInputStream())
local fos = BufferedOutputStream(FileOutputStream(zipPath))
local buffer = byte[65536]
local count = stream.read(buffer, 0, 65536)
while count ~= -1 do
if count > 0 then fos.write(buffer, 0, count) end
count = stream.read(buffer, 0, 65536)
end
fos.flush()
fos.close()
stream.close()
end)
service.postExecute(0, "x", nil, function()
if okDownload then
progDlg.setTitle("Importando...")
if pcall(extraerZip, zipPath, obtenerCarpetaComplementos() .. "/" .. complemento.nombre) then
local esPropietario = autorizado and obtenerNombrePublicoParaGuardar(userName) == complemento.autor
if not esPropietario then
incrementarContadorDescargas(complemento.id)
end
handler.postDelayed(Runnable { run = function()
service.asyncSpeak(complemento.nombre .. " instalado correctamente")
mostrarDialogoPostInstalacion(complemento.nombre, complemento.url_tutorial)
end }, 1000)
else
service.asyncSpeak("Error al instalar " .. complemento.nombre)
end
pcall(function() File(zipPath).delete() end)
else
if errorEspecifico == "404" then
service.asyncSpeak("Este complemento fue actualizado o eliminado recientemente. Conéctate al servidor principal para ver la lista actualizada.")
else
service.asyncSpeak("Error de red al intentar descargar el complemento.")
end
end
progDlg.dismiss()
end)
end)
end
function confirmarDescarga(complemento)
local d = registrarVentana(LuaDialog(service)) d.setTitle("Instalar complemento") d.setMessage("¿Quieres instalar \"" .. complemento.nombre .. "\"?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Cancelar", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Instalar", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() instalarComplemento(complemento) end}
}
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
function eliminarReleaseGitHub(releaseId, releaseTag)
local headers = githubHeaders()
pcall(http_send, "DELETE", GITHUB_API .. "/releases/" .. releaseId, "", headers)
pcall(http_send, "DELETE", GITHUB_API .. "/git/refs/tags/" .. releaseTag, "", headers)
end
function subirAGitHubRelease(zipPath, nombre)
if not File(zipPath).exists() then return nil end
local releaseTag = "complemento-" .. nombre:gsub("[^a-zA-Z0-9_-]", "")
local headers = githubHeaders()
local okGet, codeGet, bodyGet = pcall(http_get, GITHUB_API .. "/releases/tags/" .. releaseTag, headers)
if okGet and codeGet == 200 then
local okP, rj = pcall(JSONObject, bodyGet)
if okP and rj.has("id") then
eliminarReleaseGitHub(tostring(rj.getInt("id")), releaseTag)
pcall(function() Thread.sleep(1500) end)
end
end
local releaseBody = "{\"tag_name\":\"" .. jsonEscape(releaseTag) .. "\",\"name\":\"" .. jsonEscape(nombre) .. "\",\"body\":\"Complemento: " .. jsonEscape(nombre) .. "\"}"
local ok, code, body = pcall(http_send, "POST", GITHUB_API .. "/releases", releaseBody, headers)
if (not ok or code ~= 201) then
pcall(function()
local ok2, code2, body2 = pcall(http_get, GITHUB_API .. "/releases/tags/" .. releaseTag, headers)
if ok2 and code2 == 200 then
local okP2, rj2 = pcall(JSONObject, body2)
if okP2 and rj2.has("id") then
eliminarReleaseGitHub(tostring(rj2.getInt("id")), releaseTag)
Thread.sleep(2000)
end
end
end)
ok, code, body = pcall(http_send, "POST", GITHUB_API .. "/releases", releaseBody, headers)
end
if not ok or code ~= 201 then return nil end
local okP, rj = pcall(JSONObject, body) if not okP or not rj.has("upload_url") or not rj.has("id") then return nil end
local newReleaseId = tostring(rj.getInt("id"))
local nombreZipSeguro = tostring(URLEncoder.encode(tostring(nombre) .. ".zip", "UTF-8")):gsub("%+", "%%20")
local uploadUrl = rj.getString("upload_url"):gsub("{%?name,label}", "") .. "?name=" .. nombreZipSeguro
local uploadHeaders = {Authorization = "Bearer " .. GITHUB_TOKEN, ["Content-Type"] = "application/zip"}
ok, code, body = pcall(http_upload, "POST", uploadUrl, zipPath, uploadHeaders)
if not ok or code ~= 201 then
pcall(function() eliminarReleaseGitHub(newReleaseId, releaseTag) end)
return nil
end
local okA, aj = pcall(JSONObject, body) if not okA or not aj.has("browser_download_url") then
pcall(function() eliminarReleaseGitHub(newReleaseId, releaseTag) end)
return nil
end
return {url = aj.getString("browser_download_url"), release_id = newReleaseId}
end
function confirmarEliminar(complemento, dlgPadre)
if usandoCacheLocal then service.asyncSpeak("Esta acción requiere conexión con el servidor") return end
if not misComplementosDisponibles then service.asyncSpeak("No se puede subir complementos por ahora. Inténtalo más tarde.") return end
local d = registrarVentana(LuaDialog(service)) d.setTitle("Eliminar complemento") d.setMessage("¿Seguro que quieres eliminar \"" .. complemento.nombre .. "\"?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Cancelar", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Eliminar", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50) d.dismiss() if dlgPadre then pcall(function() dlgPadre.dismiss() end) end
local progDlg = mostrarProgreso("Eliminando...")
en_hilo(function()
local pub = complemento.autor
local posQuitado = nil
for i, c in ipairs(complementos) do
if c.id == complemento.id then posQuitado = i table.remove(complementos, i) break end
end
local ok = guardarArchivoUsuarioSync(pub)
if not ok and posQuitado then table.insert(complementos, math.min(posQuitado, #complementos + 1), complemento) end
if ok and complemento.release_id and complemento.release_id ~= "" then
local relId = complemento.release_id
local relTag = "complemento-" .. complemento.nombre:gsub("[^a-zA-Z0-9_-]", "")
en_hilo(function() pcall(eliminarReleaseGitHub, relId, relTag) end)
end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok then
service.asyncSpeak("Complemento eliminado")
guardarTodoElRespaldo()
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al eliminar")
end
end)
end)
end}
}
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
function listarComplementosLocales()
local nombres, rutas = {}, {}
for _, baseDir in ipairs(BASE_DIRS_LOCALES) do
local dir = File(baseDir)
if dir.exists() and dir.isDirectory() then
local lista = dir.listFiles()
if lista then
for i = 0, #lista - 1 do
local f = lista[i]
if f.isDirectory() and File(f.getAbsolutePath() .. "/main.lua").exists() then
table.insert(nombres, f.getName())
table.insert(rutas, f.getAbsolutePath())
end
end
end
end
end
return nombres, rutas
end
function crearCuadroEdicion(titulo, textoInicial, hint, onAceptar)
local editDlg = registrarVentana(LuaDialog(service)) editDlg.setTitle(titulo)
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{EditText, id="etTexto", text=textoInicial, hint=hint, layout_width="match_parent", layout_height="match_parent", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"}
},
{Button, text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) local txt = views.etTexto.getText().toString() editDlg.dismiss() onAceptar(txt)
end},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) editDlg.dismiss()
end}
}
editDlg.setView(loadlayout(layout, views))
editDlg.setOnCancelListener({onCancel = function() doVibrate(50) editDlg.dismiss() end})
editDlg.show()
end
ENCRIPTADOR_API_URL = "https://encrypt-teal.vercel.app/api/encrypt"
function encriptarArchivoMainLuaSync(mainLuaPath)
local boundary = "----LuaBoundary" .. tostring(System.currentTimeMillis())
local resultPath = mainLuaPath .. ".enc_tmp"
local ok, err = pcall(function()
local conn = URL(ENCRIPTADOR_API_URL).openConnection()
conn.setRequestMethod("POST")
conn.setDoOutput(true)
conn.setDoInput(true)
conn.setUseCaches(false)
conn.setConnectTimeout(30000)
conn.setReadTimeout(300000)
conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" .. boundary)
conn.setRequestProperty("Accept", "application/octet-stream")
local out = DataOutputStream(conn.getOutputStream())
out.writeBytes("--" .. boundary .. "\r\n")
out.writeBytes("Content-Disposition: form-data; name=\"archivo\"; filename=\"main.lua\"\r\n")
out.writeBytes("Content-Type: application/octet-stream\r\n\r\n")
local bis = BufferedInputStream(FileInputStream(mainLuaPath))
local buffer = byte[16384]
local count = bis.read(buffer, 0, 16384)
while count ~= -1 do
out.write(buffer, 0, count)
count = bis.read(buffer, 0, 16384)
end
bis.close()
out.writeBytes("\r\n--" .. boundary .. "--\r\n")
out.flush()
out.close()
local responseCode = conn.getResponseCode()
if responseCode == 200 then
local input = BufferedInputStream(conn.getInputStream())
local fos = BufferedOutputStream(FileOutputStream(resultPath))
local responseBuffer = byte[65536]
local responseBytes = input.read(responseBuffer, 0, 65536)
while responseBytes ~= -1 do
if responseBytes > 0 then fos.write(responseBuffer, 0, responseBytes) end
responseBytes = input.read(responseBuffer, 0, 65536)
end
fos.flush()
fos.close()
input.close()
File(mainLuaPath).delete()
File(resultPath).renameTo(File(mainLuaPath))
else
conn.disconnect()
error("codigo_" .. tostring(responseCode))
end
conn.disconnect()
end)
pcall(function() File(resultPath).delete() end)
return ok, err
end
function encriptarCarpetaComoCopiaTemporal(rutaCarpetaOriginal)
local tempDir = rutaCarpetaOriginal .. "_enc_tmp_" .. tostring(System.currentTimeMillis())
local okCopia, errCopia = pcall(function() copiarCarpetaRecursivo(rutaCarpetaOriginal, tempDir) end)
if not okCopia then
pcall(function() borrarCarpetaRecursivo(tempDir) end)
return false, nil, errCopia
end
local okEnc, errEnc = encriptarArchivoMainLuaSync(tempDir .. "/main.lua")
if not okEnc then
pcall(function() borrarCarpetaRecursivo(tempDir) end)
return false, nil, errEnc
end
return true, tempDir, nil
end
function mostrarAdvertenciaSinEncriptar(rutaCarpeta, callbackSubirSinEncriptar, callbackEncriptarYSubir)
doVibrate(50)
local d = registrarVentana(LuaDialog(service))
d.setTitle("Advertencia de Encriptación")
d.setMessage("El código que quieres subir no está encriptado.\n¿Qué deseas hacer?")
d.setCancelable(false)
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, id="btnAdvCancel", text="No, cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnAdvEncriptar", text="Encriptar y subir", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnAdvOk", text="Subir sin encriptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
local views = {}
d.setView(loadlayout(layout, views))
views.btnAdvOk.setOnClickListener({onClick = function()
doVibrate(50)
d.dismiss()
if callbackSubirSinEncriptar then callbackSubirSinEncriptar() end
end})
views.btnAdvEncriptar.setOnClickListener({onClick = function()
doVibrate(50)
d.dismiss()
local progEnc = mostrarProgreso("Encriptando...")
en_hilo(function()
local ok, tempDir, err = encriptarCarpetaComoCopiaTemporal(rutaCarpeta)
service.postExecute(0, "x", nil, function()
progEnc.dismiss()
if ok then
if callbackEncriptarYSubir then callbackEncriptarYSubir(tempDir) end
else
service.asyncSpeak("Error al encriptar: " .. tostring(err))
end
end)
end)
end})
views.btnAdvCancel.setOnClickListener({onClick = function()
doVibrate(50)
d.dismiss()
end})
d.show()
service.asyncSpeak("El código que quieres subir no está encriptado. ¿Qué deseas hacer?")
end
function abrirEditor(complemento)
if usandoCacheLocal then service.asyncSpeak("Esta acción requiere conexión con el servidor") return end
if not misComplementosDisponibles then service.asyncSpeak("No se puede subir complementos por ahora. Inténtalo más tarde.") return end
local rutaEncontrada = nil
local nombreNuevo = complemento.nombre
local editDlg = registrarVentana(LuaDialog(service))
editDlg.setTitle("Editar publicación: " .. complemento.nombre)
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{TextView, text="Editando: " .. complemento.nombre, textColor="0xFF4CAF50", textSize="16sp", padding="8dp"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{LinearLayout, orientation="vertical", layout_width="match", layout_height="wrap",
{TextView, text="Descripción:", textColor="0xFFFFFFFF", padding="8dp"},
{EditText, id="etDescEditar", text=complemento.descripcion or "", hint="Descripción", layout_width="match", layout_height="wrap", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"},
{TextView, text="URL del Tutorial (opcional):", textColor="0xFFFFFFFF", padding="8dp"},
{EditText, id="etUrlTutEditar", text=complemento.url_tutorial or "", hint="https://...", layout_width="match", layout_height="wrap", inputType="textUri", padding="8dp", textColor="0xFFFFFFFF"}
}
},
{Button, id="btnBuscarComplemento", text="Modificar complemento", backgroundColor="0xFFFF9800", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{TextView, id="tvCompSel", text="Ninguno seleccionado", textColor="0xFFAAAAAA", padding="8dp", textSize="14sp"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) editDlg.dismiss() end},
{Button, id="btnAceptarEditor", text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
editDlg.setView(loadlayout(layout, views))
editDlg.setOnCancelListener({onCancel = function() doVibrate(50) editDlg.dismiss() end})
editDlg.show()
views.btnBuscarComplemento.setOnClickListener({onClick = function()
doVibrate(50)
seleccionarComplementoLocalDialog(function(n, r)
rutaEncontrada = r
nombreNuevo = n
if n ~= complemento.nombre then
views.tvCompSel.setText("Seleccionado: " .. n .. ". Reemplazará a «" .. complemento.nombre .. "» y conservará sus descargas.")
else
views.tvCompSel.setText("Seleccionado: " .. n)
end
views.tvCompSel.setTextColor(0xFF4CAF50)
service.asyncSpeak("Complemento seleccionado: " .. n)
end, complemento.nombre)
end})
views.btnAceptarEditor.setOnClickListener({onClick = function()
doVibrate(50)
local nuevaDesc = views.etDescEditar.getText().toString()
local nuevaUrlTut = views.etUrlTutEditar.getText().toString()
local descripcionAnterior = tostring(complemento.descripcion or "")
local tutorialAnterior = tostring(complemento.url_tutorial or "")
local cambioDescripcion = nuevaDesc ~= descripcionAnterior
local cambioTutorial = nuevaUrlTut ~= tutorialAnterior
local mensajeProgresoEdicion
if cambioDescripcion and cambioTutorial then
mensajeProgresoEdicion = "Actualizando descripción y tutorial..."
elseif cambioTutorial then
mensajeProgresoEdicion = "Actualizando tutorial..."
else
mensajeProgresoEdicion = "Actualizando descripción..."
end
if rutaEncontrada and nombreNuevo ~= complemento.nombre then
for _, c in ipairs(complementos) do
if c.autor == complemento.autor and c.id ~= complemento.id and c.nombre == nombreNuevo then
service.asyncSpeak("Ya tienes otro complemento publicado con el nombre " .. nombreNuevo .. ". Elige otro.")
return
end
end
end
editDlg.dismiss()
local pub = complemento.autor
if rutaEncontrada then
function iniciarSubidaComplemento(carpetaOrigen, carpetaTemporalABorrar)
carpetaOrigen = carpetaOrigen or rutaEncontrada
local progDlg = mostrarProgreso(mensajeProgresoEdicion)
en_hilo(function()
local nombreViejo = complemento.nombre
local nombreFinal = nombreNuevo or nombreViejo
local renombrado = nombreFinal ~= nombreViejo
local idViejo = complemento.id
local tagViejo = "complemento-" .. (nombreViejo:gsub("[^a-zA-Z0-9_-]", ""))
local tagNuevo = "complemento-" .. (nombreFinal:gsub("[^a-zA-Z0-9_-]", ""))
local zipPath = "/storage/emulated/0/Download/" .. nombreFinal .. "_upd.zip"
compressFolder(carpetaOrigen, zipPath)
local resultado = subirAGitHubRelease(zipPath, nombreFinal)
local ok
local fallaSubida = not resultado
if resultado then
local copia = {nombre = complemento.nombre, id = complemento.id, descripcion = complemento.descripcion, url_github = complemento.url_github, release_id = complemento.release_id, fecha_actualizacion = complemento.fecha_actualizacion, url_tutorial = complemento.url_tutorial}
complemento.nombre = nombreFinal
complemento.id = complemento.autor .. "::" .. nombreFinal
complemento.descripcion = nuevaDesc
complemento.url_github = resultado.url
complemento.release_id = resultado.release_id
complemento.fecha_actualizacion = os.time()
complemento.url_tutorial = nuevaUrlTut
ok = guardarArchivoUsuarioSync(pub)
if not ok then
for k, v in pairs(copia) do complemento[k] = v end
if renombrado and tagNuevo ~= tagViejo then pcall(eliminarReleaseGitHub, resultado.release_id, tagNuevo) end
elseif renombrado then
if copia.release_id and copia.release_id ~= "" and tagViejo ~= tagNuevo then pcall(eliminarReleaseGitHub, copia.release_id, tagViejo) end
pcall(migrarCalificacionesPorRenombre, nombreViejo, nombreFinal)
if descargasPendientesTabla[idViejo] then
descargasPendientesTabla[complemento.id] = (descargasPendientesTabla[complemento.id] or 0) + descargasPendientesTabla[idViejo]
descargasPendientesTabla[idViejo] = nil
end
end
else ok = false end
service.postExecute(2000, "x", nil, function()
pcall(function() File(zipPath).delete() end)
if carpetaTemporalABorrar then pcall(function() borrarCarpetaRecursivo(carpetaTemporalABorrar) end) end
end)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok then
service.asyncSpeak(renombrado and ("Complemento actualizado y renombrado a " .. nombreFinal .. ". Se conservaron sus descargas.") or "Complemento actualizado correctamente")
guardarTodoElRespaldo()
refrescarVistaLocalDelAutor()
elseif fallaSubida then
service.asyncSpeak("No se puede subir complementos por ahora. Inténtalo más tarde.")
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
end
local progVerifEdicion = mostrarProgreso("Verificando complemento...")
en_hilo(function()
local okVerifEdicion, encriptadoEdicion = pcall(estaComplementoEncriptado, rutaEncontrada .. "/main.lua")
if not okVerifEdicion then encriptadoEdicion = false end
service.postExecute(0, "x", nil, function()
pcall(function() progVerifEdicion.dismiss() end)
if not encriptadoEdicion then
mostrarAdvertenciaSinEncriptar(rutaEncontrada, iniciarSubidaComplemento, function(tempDir) iniciarSubidaComplemento(tempDir, tempDir) end)
else
iniciarSubidaComplemento()
end
end)
end)
else
local progDlg = mostrarProgreso(mensajeProgresoEdicion)
en_hilo(function()
local descPrev, tutPrev = complemento.descripcion, complemento.url_tutorial
complemento.descripcion = nuevaDesc
complemento.url_tutorial = nuevaUrlTut
local ok = guardarArchivoUsuarioSync(pub)
if not ok then complemento.descripcion = descPrev complemento.url_tutorial = tutPrev end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok then
service.asyncSpeak("Descripción actualizada correctamente")
guardarTodoElRespaldo()
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
end
end})
end
function ordenarComplementos(lista, criterio)
if criterio == ORDEN_ALFABETICO_AZ then
table.sort(lista, function(a, b) return (a.nombre or ""):lower() < (b.nombre or ""):lower() end)
elseif criterio == ORDEN_ALFABETICO_ZA then
table.sort(lista, function(a, b) return (a.nombre or ""):lower() > (b.nombre or ""):lower() end)
elseif criterio == ORDEN_FECHA_VIEJO then
table.sort(lista, function(a, b) return a.fecha_actualizacion < b.fecha_actualizacion end)
elseif criterio == ORDEN_POPULARIDAD then
table.sort(lista, function(a, b)
local descA = a.descargas or 0
local descB = b.descargas or 0
return descA > descB
end)
else
table.sort(lista, function(a, b) return a.fecha_actualizacion > b.fecha_actualizacion end)
end
end
function mostrarMenuOrdenar()
if #filtrados == 0 then service.asyncSpeak("No hay elementos para ordenar") return end
local menuDlg = registrarVentana(LuaDialog(service)) menuDlg.setTitle("Ordenar complementos") menuDlg.setCancelable(true)
local opciones = {
{texto="Alfabético (A-Z)", valor=ORDEN_ALFABETICO_AZ},
{texto="Alfabético (Z-A)", valor=ORDEN_ALFABETICO_ZA},
{texto="Más reciente", valor=ORDEN_FECHA_NUEVO},
{texto="Más antiguo", valor=ORDEN_FECHA_VIEJO},
{texto="Más populares (más descargas)", valor=ORDEN_POPULARIDAD}
}
local nombreActual = ""
for _, op in ipairs(opciones) do if op.valor == ordenActual then nombreActual = op.texto break end end
local layout = {LinearLayout, orientation="vertical", padding="16dp", {TextView, text="Orden actual: " .. nombreActual, textSize="14sp", paddingBottom="16dp"}}
for _, op in ipairs(opciones) do
table.insert(layout, {Button, text=op.texto, backgroundColor=op.valor == ordenActual and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) ordenActual = op.valor prefs.edit().putString(OPCION_ORDEN, ordenActual).apply()
menuDlg.dismiss() ordenarComplementos(filtrados, ordenActual) actualizarListaUI() service.asyncSpeak("Ordenado: " .. op.texto)
end})
end
table.insert(layout, {Button, text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) menuDlg.dismiss() end})
menuDlg.setView(loadlayout(layout))
menuDlg.setOnCancelListener({onCancel = function() doVibrate(50) menuDlg.dismiss() end})
menuDlg.show()
end
function buscar(query)
query = query:lower()
if esVistaTop() then
filtrados = {}
for _, c in ipairs(obtenerTop10()) do
if query == "" or c.nombre:lower():find(query, 1, true) then table.insert(filtrados, c) end
end
actualizarListaUI()
else
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
filtrados = {} for _, c in ipairs(complementos) do if c.autor == pub then
if query == "" or c.nombre:lower():find(query, 1, true) then table.insert(filtrados, c) end
end end ordenarComplementos(filtrados, ordenActual) actualizarListaUI()
end
if query ~= "" then if #filtrados == 0 then service.asyncSpeak("No se encontraron coincidencias") else service.asyncSpeak(#filtrados .. " coincidencias encontradas") end end
end
function editarAnuncio()
if usandoCacheLocal then service.asyncSpeak("Esta acción requiere conexión con el servidor") return end
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
if not autorizado or usuarioSeleccionado ~= userName then service.asyncSpeak("Sin permisos") return end
crearCuadroEdicion("Editar anuncio", anunciosUsuario[pub] or "", "Escribe tu anuncio aquí...", function(nuevoAnuncio)
local progDlg = mostrarProgreso("Guardando anuncio...")
en_hilo(function()
if nuevoAnuncio == "" then anunciosUsuario[pub] = nil else anunciosUsuario[pub] = nuevoAnuncio end
local ok = guardarArchivoUsuarioSync(pub)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok then
if nuevoAnuncio == "" then
service.asyncSpeak("Anuncio borrado correctamente")
else
service.asyncSpeak("Anuncio guardado")
end
guardarTodoElRespaldo()
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al guardar")
end
end)
end)
end)
end
mostrarInterfazCalificaciones = nil
function mostrarMenuComplemento(complemento)
local enTop = esVistaTop()
local esPropietario = (not enTop) and autorizado and obtenerNombrePublicoParaGuardar(userName) == complemento.autor and not usandoCacheLocal
local tieneTutorial = complemento.url_tutorial and complemento.url_tutorial ~= ""
local d = registrarVentana(LuaDialog(service))
d.setTitle(complemento.nombre or "Complemento")
d.setCancelable(true)
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000"
}
local desc = tostring(complemento.descripcion or ""):match("^%s*(.-)%s*$") or ""
if desc ~= "" then
table.insert(layout, {TextView, text="Descripción", textSize="13sp", textColor="0xFFFFD700", paddingBottom="4dp"})
table.insert(layout, {
ScrollView, layout_width="match_parent", layout_height="120dp",
{TextView, text=desc, textSize="15sp", textColor="0xFFFFFFFF", padding="8dp", backgroundColor="0xFF202125"}
})
table.insert(layout, {View, layout_width="match_parent", layout_height="10dp"})
else
table.insert(layout, {TextView, text="Sin descripción", textSize="14sp", textColor="0xFF888888", paddingBottom="10dp"})
end
table.insert(layout, {Button, text="Ver calificaciones", backgroundColor="0xFF9C27B0", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() mostrarInterfazCalificaciones(complemento) end})
table.insert(layout, {Button, text="Instalar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() if pedirConfirmacion then confirmarDescarga(complemento) else instalarComplemento(complemento) end end})
if tieneTutorial then
table.insert(layout, {Button, text="Ver Tutorial", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() abrirTutorial(complemento.url_tutorial) end})
end
if esPropietario then
table.insert(layout, {Button, text="Editar publicación", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() abrirEditor(complemento) end})
table.insert(layout, {Button, text="Eliminar", backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() confirmarEliminar(complemento, nil) end})
end
table.insert(layout, {Button, text="Volver", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end})
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
function mostrarDialogoOpcionesPropietario(complemento)
mostrarMenuComplemento(complemento)
end
function nombreArchivoCalificaciones(nombre)
local archivo = tostring(nombre or "sin_nombre"):gsub(" ", "_"):gsub("[/\\:*?\"<>|]", "")
return archivo .. ".json"
end
function headersCalificaciones()
return {Authorization = "Bearer " .. CALIFICACIONES_GITHUB_TOKEN, ["X-GitHub-Api-Version"] = "2022-11-28", ["Content-Type"] = "application/json"}
end
function crearArchivoCalificacionesDirecto(complemento)
local url=CALIFICACIONES_GITHUB_API .. nombreArchivoCalificaciones(complemento.nombre)
local inicial=JSONObject()
inicial.put("promedio",0)
inicial.put("total_calificaciones",0)
inicial.put("calificaciones",JSONObject())
inicial.put("resenas",JSONArray())
local contenido=inicial.toString()
local b64=Base64.encodeToString(bytesDeTexto(contenido),Base64.NO_WRAP)
local cuerpo='{"message":"Crear archivo de calificaciones","branch":"main","content":"'..b64..'"}'
local okPut,codePut,bodyPut=pcall(http_send,"PUT",url,cuerpo,headersCalificaciones())
return okPut and (codePut==200 or codePut==201 or codePut==422)
end
function migrarCalificacionesPorRenombre(nombreViejo, nombreNuevo)
local urlViejo = CALIFICACIONES_GITHUB_API .. nombreArchivoCalificaciones(nombreViejo)
local urlNuevo = CALIFICACIONES_GITHUB_API .. nombreArchivoCalificaciones(nombreNuevo)
if urlViejo == urlNuevo then return end
local okN, codeN = pcall(http_get, urlNuevo, headersCalificaciones())
if okN and codeN == 200 then return end
local okV, codeV, bodyV = pcall(http_get, urlViejo, headersCalificaciones())
if okV and codeV == 200 and bodyV then
local okJ, obj = pcall(JSONObject, bodyV)
if okJ and obj and obj.has("content") then
local b64 = obj.getString("content"):gsub("\n", "")
local cuerpo = '{"message":"Renombrar complemento","branch":"main","content":"' .. b64 .. '"}'
pcall(http_send, "PUT", urlNuevo, cuerpo, headersCalificaciones())
return
end
end
crearArchivoCalificacionesDirecto({nombre = nombreNuevo})
end
function cargarCalificaciones(complemento, callback)
local url = CALIFICACIONES_GITHUB_API .. nombreArchivoCalificaciones(complemento.nombre)
local ok, code, body = pcall(http_get, url, headersCalificaciones())
local datos = {promedio=0, total_calificaciones=0, calificaciones={}, resenas={}}
if ok and code == 200 and body then
local okJson, obj = pcall(JSONObject, body)
if okJson and obj and obj.has("content") then
local contentBase64 = obj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
local contenidoDecodificado = tostring(String(bytes, StandardCharsets.UTF_8))
local okReal, real = pcall(JSONObject, contenidoDecodificado)
if okReal and real then
datos.promedio = real.optDouble("promedio", 0); datos.total_calificaciones = real.optInt("total_calificaciones", 0)
local cal = real.optJSONObject("calificaciones")
if cal then local it=cal.keys(); while it.hasNext() do local id=tostring(it.next()); datos.calificaciones[id]=cal.optInt(id,0) end end
local res=real.optJSONArray("resenas")
if res then for i=0,res.length()-1 do local r=res.optJSONObject(i); if r then table.insert(datos.resenas,{nombre=r.optString("nombre","Anónimo"),estrellas=r.optInt("estrellas",0),comentario=r.optString("comentario",""),fecha=r.optLong("fecha",0),device_id=r.optString("device_id","")}) end end end
end
end
elseif not ok or (code ~= 404 and code ~= 200) then datos.error=true end
callback(datos)
end
guardarCalificacionTienda = nil
eliminarCalificacionTienda = nil
mostrarMenuCalificar = nil
mostrarMenuCalificarTienda = nil
mostrarDialogoResenaTienda = nil
dlgCalificacionesActual = nil
dlgMenuCalificarActual = nil
dlgSelectorEstrellasActual = nil
dlgResenaActual = nil
function eliminarResenaTienda(complemento, datos, callback)
for i = #datos.resenas, 1, -1 do
if datos.resenas[i].device_id == ANDROID_ID_CALIFICACIONES then table.remove(datos.resenas, i) end
end
guardarCalificacionTienda(complemento, datos, nil, callback)
end
mostrarInterfazCalificaciones = function(complemento)
if dlgCalificacionesActual then pcall(function() dlgCalificacionesActual.dismiss() end) end
local progreso=mostrarProgreso("Cargando calificaciones...")
en_hilo(function() cargarCalificaciones(complemento,function(datos) service.postExecute(0,"x",nil,function()
if progreso and progreso.isShowing() then progreso.dismiss() end
local d=registrarVentana(LuaDialog(service)); dlgCalificacionesActual=d; d.setTitle("Calificaciones de " .. tostring(complemento.nombre or "complemento"))
local esPropio=autorizado and obtenerNombrePublicoParaGuardar(userName)==complemento.autor
local personal=datos.calificaciones[ANDROID_ID_CALIFICACIONES]
local resumenPersonal=personal and ("Tu calificación: "..tostring(personal).." estrellas") or ""
local resumenGeneral
if datos.error then resumenGeneral="No se pudieron cargar las calificaciones" elseif datos.total_calificaciones==0 then resumenGeneral="No hay calificaciones" else resumenGeneral=string.format("%.1f estrellas, basado en %d calificaciones",datos.promedio,datos.total_calificaciones) end
local propiaResena=nil
for i,r in ipairs(datos.resenas) do
if r.device_id==ANDROID_ID_CALIFICACIONES then propiaResena=r; table.remove(datos.resenas,i); table.insert(datos.resenas,1,propiaResena); break end
end
local v={}; local layout={LinearLayout,orientation="vertical",padding="16dp",backgroundColor="0xFF000000",{TextView,text=resumenPersonal,textColor="0xFFFFD700",textSize="17sp",padding="8dp"},{TextView,text=resumenGeneral,textColor="0xFFFFFFFF",textSize="16sp",padding="8dp"}}
if not esPropio then
if propiaResena then
table.insert(layout,{Button,text="Editar reseña",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss(); mostrarDialogoResenaTienda(complemento,datos,propiaResena) end})
elseif personal then
table.insert(layout,{Button,text="Editar calificación",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss(); mostrarMenuCalificar(complemento,datos) end})
else
table.insert(layout,{Button,text="Calificar",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss(); mostrarMenuCalificar(complemento,datos) end})
end
end
if personal and not esPropio and not propiaResena then
table.insert(layout,{Button,text="Eliminar calificación",layout_width="match_parent",padding="16dp",onClick=function()
local alerta=registrarVentana(LuaDialog(service))
alerta.setTitle("Atención")
alerta.setCancelable(false)
alerta.setOnKeyListener({onKey=function(_,keyCode,event) if keyCode==KeyEvent.KEYCODE_BACK and event.getAction()==1 then dlgConfirmacionActiva=nil; pcall(function() alerta.dismiss() end); return true end return false end})
local b={}
local confirmLayout={LinearLayout,orientation="vertical",padding="16dp",
{TextView,text="¿Estás seguro que quieres eliminar tu calificación?",textColor="0xFFFFFFFF",padding="8dp"},
{LinearLayout,orientation="horizontal",layout_width="match_parent",layout_height="wrap_content",
{Button,id="no",text="No",layout_width="0dp",layout_weight="1"},
{Button,id="si",text="Sí",layout_width="0dp",layout_weight="1"}}}
alerta.setView(loadlayout(confirmLayout,b))
b.no.setOnClickListener({onClick=function() dlgConfirmacionActiva=nil; alerta.dismiss() end})
b.si.setOnClickListener({onClick=function()
dlgConfirmacionActiva=nil
alerta.dismiss()
local p=mostrarProgreso("Eliminando calificación...")
en_hilo(function()
eliminarCalificacionTienda(complemento,datos,function(ok)
service.postExecute(0,"x",nil,function()
if p and p.isShowing() then p.dismiss() end
if ok then mostrarInterfazCalificaciones(complemento) else service.asyncSpeak("No se pudo eliminar la calificación") end
end)
end)
end)
end})
alerta.show()
end})
end
if propiaResena then
function confirmarEliminacion()
local alerta=registrarVentana(LuaDialog(service))
dlgConfirmacionActiva = alerta
alerta.setTitle("Atención")
alerta.setCancelable(false)
alerta.setOnKeyListener({onKey=function(_,keyCode,event) if keyCode==KeyEvent.KEYCODE_BACK and event.getAction()==1 then dlgConfirmacionActiva=nil; pcall(function() alerta.dismiss() end); return true end return false end})
local b={}
local confirmLayout={LinearLayout,orientation="vertical",padding="16dp",
{TextView,text="¿Está seguro que quieres eliminar tu reseña?",textColor="0xFFFFFFFF",padding="8dp"},
{LinearLayout,orientation="horizontal",layout_width="match_parent",layout_height="wrap_content",
{Button,id="no",text="No",layout_width="0dp",layout_weight="1"},
{Button,id="si",text="Sí",layout_width="0dp",layout_weight="1"}}}
alerta.setView(loadlayout(confirmLayout,b))
b.no.setOnClickListener({onClick=function() dlgConfirmacionActiva=nil; alerta.dismiss() end})
b.si.setOnClickListener({onClick=function()
dlgConfirmacionActiva=nil
alerta.dismiss()
local p=mostrarProgreso("Eliminando reseña...")
en_hilo(function()
eliminarResenaTienda(complemento,datos,function(ok)
service.postExecute(0,"x",nil,function()
if p and p.isShowing() then p.dismiss() end
if ok then mostrarInterfazCalificaciones(complemento) else service.asyncSpeak("No se pudo eliminar la reseña") end
end)
end)
end)
end})
alerta.show()
end
table.insert(layout,{Button,text="Eliminar mi reseña",layout_width="match_parent",padding="16dp",onClick=function() confirmarEliminacion() end})
end
function tiempoRelativoResena(fecha)
local marca=tonumber(fecha or 0) or 0
if marca<=0 then return "fecha desconocida" end
local diferencia=math.max(0,os.time()-marca)
if diferencia<60 then return "hace unos segundos" end
if diferencia<3600 then local n=math.floor(diferencia/60); return "hace "..n.." "..(n==1 and "minuto" or "minutos") end
if diferencia<86400 then local n=math.floor(diferencia/3600); return "hace "..n.." "..(n==1 and "hora" or "horas") end
if diferencia<2592000 then local n=math.floor(diferencia/86400); return "hace "..n.." "..(n==1 and "día" or "días") end
if diferencia<31536000 then local n=math.floor(diferencia/2592000); return "hace "..n.." "..(n==1 and "mes" or "meses") end
local n=math.floor(diferencia/31536000); return "hace "..n.." "..(n==1 and "año" or "años")
end
table.insert(layout,{TextView,text="Reseñas",textColor="0xFFFFFFFF",textSize="18sp",padding="8dp"})
table.insert(layout,{ScrollView,layout_width="match_parent",layout_height="0dp",layout_weight="1",{LinearLayout,id="contResenasCalificaciones",orientation="vertical"}})
table.insert(layout,{Button,text="Cerrar",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss() end})
d.setView(loadlayout(layout,v)); for _,r in ipairs(datos.resenas) do local nombre=tostring(r.nombre or "Anónimo"); local estrellas=tonumber(r.estrellas or 0) or 0; local encabezado=nombre..", "..tiempoRelativoResena(r.fecha).." con "..tostring(estrellas)..(estrellas==1 and " estrella" or " estrellas"); local texto=encabezado.."\n"..tostring(r.comentario or ""); v.contResenasCalificaciones.addView(loadlayout({TextView,text=texto,textColor="0xFFFFFFFF",padding="10dp"})) end; d.show()
end) end) end)
end
guardarCalificacionTienda = function(complemento, datos, estrellas, callback, resenaActual)
if complemento and complemento.nombre then invalidarCacheCalificacion(complemento.nombre) end
datos.calificaciones[ANDROID_ID_CALIFICACIONES] = estrellas
if resenaActual then
local reemplazada=false
for i,r in ipairs(datos.resenas or {}) do if r.device_id==ANDROID_ID_CALIFICACIONES then datos.resenas[i]=resenaActual; reemplazada=true end end
if not reemplazada then table.insert(datos.resenas,1,resenaActual) end
end
local total = 0
local suma = 0
for _, valor in pairs(datos.calificaciones) do total = total + 1; suma = suma + tonumber(valor or 0) end
datos.total_calificaciones = total
datos.promedio = total > 0 and (suma / total) or 0
local raiz = JSONObject()
raiz.put("promedio", datos.promedio)
raiz.put("total_calificaciones", datos.total_calificaciones)
local calificaciones = JSONObject()
for id, valor in pairs(datos.calificaciones) do calificaciones.put(tostring(id), tonumber(valor)) end
raiz.put("calificaciones", calificaciones)
local resenas = JSONArray()
for _, r in ipairs(datos.resenas or {}) do
local obj = JSONObject()
obj.put("device_id", r.device_id or "")
obj.put("nombre", r.nombre or "Anónimo")
obj.put("estrellas", r.estrellas or 0)
obj.put("comentario", r.comentario or "")
obj.put("fecha", r.fecha or 0)
resenas.put(obj)
end
raiz.put("resenas", resenas)
local contenido = raiz.toString()
local b64 = Base64.encodeToString(bytesDeTexto(contenido), Base64.NO_WRAP)
local url = CALIFICACIONES_GITHUB_API .. nombreArchivoCalificaciones(complemento.nombre)
local okGet, codeGet, bodyGet = pcall(http_get, url, headersCalificaciones())
local cuerpo = '{"message":"Actualizar calificación","branch":"main","content":"' .. b64 .. '"'
if okGet and codeGet == 200 and bodyGet then
local okObj, obj = pcall(JSONObject, bodyGet)
if okObj and obj then cuerpo = cuerpo .. ',"sha":"' .. jsonEscape(obj.optString("sha", "")) .. '"' end
end
cuerpo = cuerpo .. "}"
local okPut, codePut = pcall(http_send, "PUT", url, cuerpo, headersCalificaciones())
if callback then callback(okPut and (codePut == 200 or codePut == 201)) end
end
eliminarCalificacionTienda = function(complemento,datos,callback)
datos.calificaciones[ANDROID_ID_CALIFICACIONES] = nil
guardarCalificacionTienda(complemento,datos,nil,callback)
end
mostrarMenuCalificar = function(complemento,datos)
if dlgMenuCalificarActual then pcall(function() dlgMenuCalificarActual.dismiss() end) end
local d=registrarVentana(LuaDialog(service)); dlgMenuCalificarActual=d; d.setTitle("¿Qué quieres hacer?"); d.setCancelable(true)
local layout={LinearLayout,orientation="vertical",padding="16dp",backgroundColor="0xFF000000",
{Button,text="Calificar con estrellas",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss(); mostrarMenuCalificarTienda(complemento,datos) end},
{Button,text="Reseñar complemento",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss(); mostrarDialogoResenaTienda(complemento,datos,{estrellas=tonumber(datos.calificaciones[ANDROID_ID_CALIFICACIONES] or 0) or 0,nombre="",comentario=""}) end},
{Button,text="Cancelar",layout_width="match_parent",padding="16dp",onClick=function() d.dismiss() end}}
d.setView(loadlayout(layout)); d.show()
end
mostrarMenuCalificarTienda = function(complemento,datos)
local d=registrarVentana(LuaDialog(service)); d.setTitle("Calificar "..tostring(complemento.nombre or "complemento"))
local seleccion=tonumber(datos.calificaciones[ANDROID_ID_CALIFICACIONES] or 0) or 0
if seleccion > 0 then d.setTitle("Editar calificación "..tostring(complemento.nombre or "complemento")) end
local v={}; local fila={LinearLayout,orientation="horizontal",padding="16dp"}
for n=1,5 do table.insert(fila,{Button,text=tostring(n),layout_weight=1,padding="14dp",onClick=function() local texto=n==1 and "1 estrella seleccionada" or tostring(n).." estrellas seleccionadas"; seleccion=n; v.tvSeleccion.setText(texto); service.asyncSpeak(texto) end}) end
local textoInicial = seleccion>0 and (seleccion==1 and "1 estrella seleccionada" or seleccion.." estrellas seleccionadas") or "Selecciona una calificación"
local layout={LinearLayout,orientation="vertical",padding="16dp",backgroundColor="0xFF000000",{TextView,id="tvSeleccion",text=textoInicial,textColor="0xFFFFFFFF",padding="8dp"},fila,{LinearLayout,orientation="horizontal",{Button,text="Cancelar",layout_weight=1,onClick=function() d.dismiss() end},{Button,id="btnEnviarCalificacion",text="Enviar",layout_weight=1}}}
d.setView(loadlayout(layout,v))
d.setOnCancelListener({onCancel=function() d.dismiss() end})
d.show()
v.btnEnviarCalificacion.setOnClickListener({onClick=function()
if seleccion<1 or seleccion>5 then service.asyncSpeak("Selecciona una calificación") return end
d.dismiss(); local progreso=mostrarProgreso("Guardando calificación...")
en_hilo(function()
guardarCalificacionTienda(complemento,datos,seleccion,function(ok)
service.postExecute(0,"x",nil,function()
if progreso and progreso.isShowing() then progreso.dismiss() end
if ok then service.asyncSpeak("Calificación guardada"); mostrarInterfazCalificaciones(complemento) else service.asyncSpeak("No se pudo guardar la calificación") end
end)
end)
end)
end})
end
function mostrarSelectorVisualEstrellas(callback,seleccionInicial)
local d=registrarVentana(LuaDialog(service)); d.setTitle("Selecciona tus estrellas"); d.setCancelable(true)
local fila={LinearLayout,orientation="horizontal",layout_width="match_parent",padding="16dp"}
for n=1,5 do table.insert(fila,{Button,text="★",contentDescription=tostring(n)..(n==1 and " estrella" or " estrellas"),layout_weight=1,padding="16dp",textSize="22sp",onClick=function() d.dismiss(); callback(n) end}) end
d.setView(loadlayout({LinearLayout,orientation="vertical",padding="12dp",backgroundColor="0xFF000000",{TextView,text="Elige de 1 a 5 estrellas",textColor="0xFFFFFFFF",padding="8dp"},fila,{Button,text="Cancelar",layout_width="match_parent",onClick=function() d.dismiss() end}})); d.show()
end
mostrarDialogoResenaTienda = function(complemento,datos,anterior)
if dlgResenaActual then pcall(function() dlgResenaActual.dismiss() end) end
local esEdicion=anterior and ((anterior.comentario or "")~="" or (anterior.nombre or "")~="")
local d=registrarVentana(LuaDialog(service)); dlgResenaActual=d; d.setTitle(esEdicion and "Editar reseña" or "Reseñar complemento")
local v={}; local estrellasSeleccionadas=tonumber(anterior and anterior.estrellas or 0) or 0
local textoNombre=anterior and anterior.nombre or ""; local textoComentario=anterior and anterior.comentario or ""
function salirFormularioResena()
local textoActual=tostring(v.etComentario and v.etComentario.getText().toString() or "")
if textoActual=="" then d.dismiss(); return end
local alerta=registrarVentana(LuaDialog(service)); alerta.setTitle("Atención")
alerta.setCancelable(false)
alerta.setOnKeyListener({onKey=function(_,keyCode,event) if keyCode==KeyEvent.KEYCODE_BACK and event.getAction()==1 then dlgConfirmacionActiva=nil; pcall(function() alerta.dismiss() end); return true end return false end})
local b={}; local confirmLayout={LinearLayout,orientation="vertical",padding="16dp",{TextView,text="¿Seguro que quieres descartar lo que has escrito?",textColor="0xFFFFFFFF",padding="8dp"},{LinearLayout,orientation="horizontal",{Button,id="no",text="No",layout_weight=1},{Button,id="si",text="Sí",layout_weight=1}}}
alerta.setView(loadlayout(confirmLayout,b)); b.no.setOnClickListener({onClick=function() dlgConfirmacionActiva=nil; alerta.dismiss() end}); b.si.setOnClickListener({onClick=function() dlgConfirmacionActiva=nil; alerta.dismiss(); d.dismiss() end}); alerta.show()
end
local layout={LinearLayout,orientation="vertical",padding="16dp",backgroundColor="0xFF000000",
{ScrollView,layout_width="match_parent",layout_height="0dp",layout_weight="1",fillViewport=true,
{LinearLayout,orientation="vertical",layout_width="match_parent",layout_height="wrap_content",
{TextView,id="tvEstrellas",text=estrellasSeleccionadas>0 and (estrellasSeleccionadas==1 and "1 estrella seleccionada" or estrellasSeleccionadas.." estrellas seleccionadas") or "Ninguna estrella seleccionada",textColor="0xFFFFD700",padding="8dp"},
{Button,id="btnSeleccionarEstrellas",text="Seleccionar estrellas",layout_width="match_parent",padding="14dp"},
{EditText,id="etNombre",hint="Nombre",text=textoNombre,singleLine=true,layout_width="match_parent",textColor="0xFFFFFFFF"},
{TextView,id="tvContadorNombre",text=tostring(#textoNombre).."/25",textColor="0xFFAAAAAA"},
{EditText,id="etComentario",hint="Escribe una reseña",text=textoComentario,inputType="textMultiLine",layout_width="match_parent",textColor="0xFFFFFFFF",minLines=3},
{TextView,id="tvContadorComentario",text=tostring(#textoComentario).."/1500",textColor="0xFFAAAAAA"}
}},
{LinearLayout,orientation="horizontal",layout_width="match_parent",{Button,text="Cancelar",layout_weight=1,onClick=function() salirFormularioResena() end},{Button,id="btnGuardarResena",text=esEdicion and "Guardar" or "Enviar",layout_weight=1}}
}
d.setView(loadlayout(layout,v)); d.setCancelable(false); d.show()
d.setOnKeyListener({onKey=function(_,keyCode,event) if keyCode==4 and event.getAction()==1 then salirFormularioResena(); return true end return false end})
limitarCaracteres(v.etNombre,25); limitarCaracteres(v.etComentario,1500)
v.etNombre.addTextChangedListener({onTextChanged=function(s) v.tvContadorNombre.setText(tostring(s.length()).."/25") end})
v.etComentario.addTextChangedListener({onTextChanged=function(s) v.tvContadorComentario.setText(tostring(s.length()).."/1500") end})
v.btnSeleccionarEstrellas.setOnClickListener({onClick=function() mostrarSelectorVisualEstrellas(function(n) estrellasSeleccionadas=n; v.tvEstrellas.setText(n==1 and "1 estrella seleccionada" or n.." estrellas seleccionadas"); service.asyncSpeak(n==1 and "1 estrella seleccionada" or n.." estrellas seleccionadas") end,estrellasSeleccionadas) end})
v.btnGuardarResena.setOnClickListener({onClick=function()
local nombre=tostring(v.etNombre.getText().toString() or ""); local comentario=tostring(v.etComentario.getText().toString() or "")
if estrellasSeleccionadas<1 or estrellasSeleccionadas>5 then service.asyncSpeak("Selecciona una calificación") return end
if comentario=="" then service.asyncSpeak("Escribe una reseña") return end
if nombre=="" then nombre="Anónimo" end
d.dismiss(); local p=mostrarProgreso(esEdicion and "Guardando reseña..." or "Enviando reseña..."); local r={device_id=ANDROID_ID_CALIFICACIONES,nombre=nombre,estrellas=estrellasSeleccionadas,comentario=comentario,fecha=os.time()}
en_hilo(function() guardarCalificacionTienda(complemento,datos,estrellasSeleccionadas,function(ok) service.postExecute(0,"x",nil,function() if p and p.isShowing() then p.dismiss() end; if ok then service.asyncSpeak(esEdicion and "Reseña actualizada" or "Reseña enviada"); mostrarInterfazCalificaciones(complemento) else service.asyncSpeak("No se pudo guardar la reseña") end end) end,r) end)
end})
end
MESES_ES = {"enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"}
function formatearFechaLarga(timestamp)
if not timestamp or timestamp == 0 then return nil end
local dia = tonumber(os.date("%d", timestamp))
local mes = tonumber(os.date("%m", timestamp))
local anio = os.date("%Y", timestamp)
if not dia or not mes then return nil end
return dia .. " de " .. MESES_ES[mes] .. " de " .. anio
end
cacheResumenCalificaciones = cacheResumenCalificaciones or {}
cacheCargandoCalificaciones = cacheCargandoCalificaciones or {}
callbacksResumenCalificaciones = callbacksResumenCalificaciones or {}
function textoResumenCalificacion(datos)
if not datos then return "Calificación no disponible" end
if datos.error then return "Calificación no disponible" end
local total = tonumber(datos.total_calificaciones or 0) or 0
if total == 0 then return "Sin calificaciones" end
local prom = tonumber(datos.promedio or 0) or 0
return string.format("%.1f estrellas, basado en %d calificaciones", prom, total)
end
function invalidarCacheCalificacion(nombre)
if not nombre then return end
cacheResumenCalificaciones[nombre] = nil
cacheCargandoCalificaciones[nombre] = nil
callbacksResumenCalificaciones[nombre] = nil
end
function solicitarResumenCalificacion(complemento, alTerminar)
local nombre = complemento and complemento.nombre
if not nombre or nombre == "" then
if alTerminar then alTerminar("Sin calificaciones") end
return
end
if cacheResumenCalificaciones[nombre] then
if alTerminar then alTerminar(cacheResumenCalificaciones[nombre]) end
return
end
if not callbacksResumenCalificaciones[nombre] then callbacksResumenCalificaciones[nombre] = {} end
if alTerminar then table.insert(callbacksResumenCalificaciones[nombre], alTerminar) end
if cacheCargandoCalificaciones[nombre] then return end
cacheCargandoCalificaciones[nombre] = true
en_hilo(function()
cargarCalificaciones(complemento, function(datos)
local txt = textoResumenCalificacion(datos)
cacheResumenCalificaciones[nombre] = txt
cacheCargandoCalificaciones[nombre] = nil
local cbs = callbacksResumenCalificaciones[nombre] or {}
callbacksResumenCalificaciones[nombre] = nil
service.postExecute(0, "x", nil, function()
for _, cb in ipairs(cbs) do pcall(cb, txt) end
end)
end)
end)
end
function construirTarjetaComplemento(complemento)
local tarjeta = { LinearLayout, orientation="vertical", backgroundColor="0xFF202125", padding="12dp", clickable=true }
local enTop = esVistaTop()
local puestoTop = nil
if enTop then
for i, t in ipairs(obtenerTop10()) do
if t == complemento or (t.nombre == complemento.nombre and t.autor == complemento.autor) then puestoTop = i break end
end
end
local descargasText = "Descargas: " .. (complemento.descargas or 0)
table.insert(tarjeta, {TextView, text=(puestoTop and (puestoTop .. ". ") or "") .. (complemento.nombre or ""), textSize="18sp", textColor="0xFFFFFFFF"})
if enTop then
table.insert(tarjeta, {TextView, text="Autor: " .. (complemento.autor or ""), textSize="14sp", textColor="0xFFFFD700", paddingBottom="2dp"})
end
table.insert(tarjeta, {TextView, text=descargasText, textSize="14sp", textColor="0xFF4CAF50", paddingBottom="4dp"})
local fechaTexto = formatearFechaLarga(complemento.fecha_actualizacion)
if fechaTexto then
table.insert(tarjeta, {TextView, text="Última actualización: " .. fechaTexto, textSize="14sp", textColor="0xFFAAAAAA", paddingBottom="4dp"})
end
tarjeta.onClick = function()
doVibrate(50)
mostrarMenuComplemento(complemento)
end
return tarjeta
end
actualizarListaUI = function()
if contenedorComplementos == nil then return end
contenedorComplementos.removeAllViews()
if usandoCacheLocal then
local esDuenoDelCatalogo = autorizado and usuarioSeleccionado == userName
local textoAvisoRespaldo = esDuenoDelCatalogo and "Conectado al servidor de respaldo, el principal vuelve pronto. Puedes instalar complementos con normalidad, pero no podrás editar, subir ni eliminar hasta que el servidor principal esté disponible." or "Conectado al servidor de respaldo, el principal vuelve pronto."
contenedorComplementos.addView(loadlayout({TextView, text=textoAvisoRespaldo, textColor="0xFFFFEB3B", backgroundColor="0xFF333333", padding="8dp"}))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
if anunciosUsuario[pub] and not esVistaTop() then
contenedorComplementos.addView(loadlayout({TextView, text=anunciosUsuario[pub], textColor="0xFFFFD700", padding="8dp", backgroundColor="0xFF333333", gravity="center"}))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
if autorizado and usuarioSeleccionado == userName and not usandoCacheLocal then
contenedorComplementos.addView(loadlayout({Button, text="Editar anuncio", backgroundColor="0xFFFF9800", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) editarAnuncio() end}))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
if #filtrados == 0 then
contenedorComplementos.addView(loadlayout({TextView, text="No hay complementos disponibles", textSize="16sp", padding="16dp", gravity="center", textColor="0xFFFFFFFF"}))
else
for _, c in ipairs(filtrados) do
contenedorComplementos.addView(loadlayout(construirTarjetaComplemento(c)))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
end
if tvTitulo then
if esVistaTop() then
tvTitulo.setText(NOMBRE_TOP .. "\n(" .. #obtenerTop10() .. " complementos)")
else
local nombreVisible = obtenerNombreVisible(usuarioSeleccionado) or ""
tvTitulo.setText(nombreVisible .. "\n(" .. contarComplementosPorUsuario(usuarioSeleccionado) .. " complementos)")
end
end
if btnSort then btnSort.setVisibility(esVistaTop() and View.GONE or View.VISIBLE) end
if btnSubirComplemento then btnSubirComplemento.setVisibility((autorizado and usuarioSeleccionado == userName and not usandoCacheLocal and misComplementosDisponibles) and View.VISIBLE or View.GONE) end
end
function seleccionarComplementoLocalDialog(callback, nombreBuscado)
local progDlg = mostrarProgreso("Cargando complementos locales...")
en_hilo(function()
local nombres, rutas = listarComplementosLocales()
local combined = {}
for i = 1, #nombres do table.insert(combined, {nombre = nombres[i], ruta = rutas[i]}) end
table.sort(combined, function(a, b) return a.nombre:lower() < b.nombre:lower() end)
nombres = {}
rutas = {}
for i, item in ipairs(combined) do
table.insert(nombres, item.nombre)
table.insert(rutas, item.ruta)
end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if #nombres == 0 then service.asyncSpeak("No se encontraron complementos locales") return end
if nombreBuscado and not mostrarTodosLocalesAlModificar then
local indiceExacto, indiceAprox = nil, nil
local buscado = tostring(nombreBuscado)
for i, n in ipairs(nombres) do
if n == buscado then indiceExacto = i break end
if not indiceAprox and n:lower() == buscado:lower() then indiceAprox = i end
end
local indiceAuto = indiceExacto or indiceAprox
if indiceAuto then
callback(nombres[indiceAuto], rutas[indiceAuto])
return
end
service.asyncSpeak("No hay un complemento local llamado " .. buscado .. ". Elige uno de la lista.")
end
local selDlg = registrarVentana(LuaDialog(service))
selDlg.setTitle("Selecciona un complemento")
local views = {}
selDlg.setView(loadlayout({LinearLayout, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", orientation="vertical",
{EditText, id="etSearchLocal", hint="Buscar...", layout_width="match_parent", layout_height="wrap_content", textColor="0xFFFFFFFF", padding="12dp"},
{ListView, id="lvLoc", layout_width="match_parent", layout_height="0dp", layout_weight="1"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) selDlg.dismiss() end}
}, views))
selDlg.setOnCancelListener({onCancel = function() doVibrate(50) selDlg.dismiss() end})
selDlg.show()
local currentNombres = nombres
local currentRutas = rutas
function setupAdapter(listNombres)
views.lvLoc.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, String(listNombres)))
end
setupAdapter(currentNombres)
views.etSearchLocal.addTextChangedListener({
onTextChanged = function(s, start, before, count)
local query = tostring(s):lower()
if query == "" then
currentNombres = nombres
currentRutas = rutas
else
currentNombres = {}
currentRutas = {}
for i, n in ipairs(nombres) do
if n:lower():find(query, 1, true) then
table.insert(currentNombres, n)
table.insert(currentRutas, rutas[i])
end
end
end
setupAdapter(currentNombres)
end
})
views.lvLoc.setOnItemClickListener(AdapterView.OnItemClickListener{
onItemClick = function(p, v, pos, id)
doVibrate(50)
selDlg.dismiss()
callback(currentNombres[pos+1], currentRutas[pos+1])
end
})
end)
end)
end
function mostrarDialogoTutorialSubida(callback)
local d = registrarVentana(LuaDialog(service))
d.setTitle("Tutorial Disponible")
d.setMessage("¿Hay un tutorial disponible para este complemento?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
callback(nil)
end},
{Button, text="Sí", layout_weight=1, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
local urlDlg = registrarVentana(LuaDialog(service))
urlDlg.setTitle("Enlace del Tutorial")
local urlViews = {}
urlDlg.setView(loadlayout({
LinearLayout, orientation="vertical", padding="16dp",
{EditText, id="etUrl", hint="https://youtube.com/...", layout_width="match_parent", layout_height="wrap_content", padding="12dp", textColor="0xFFFFFFFF", inputType="textUri"},
{Button, text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
local url = urlViews.etUrl.getText().toString()
urlDlg.dismiss()
callback(url)
end}
}, urlViews))
urlDlg.show()
end}
}
d.setView(loadlayout(layout))
d.show()
end
function abrirSubirComplemento()
if usandoCacheLocal then service.asyncSpeak("Esta acción requiere conexión con el servidor") return end
if not misComplementosDisponibles then service.asyncSpeak("No se puede subir complementos por ahora. Inténtalo más tarde.") return end
local ruta, nombre = nil, nil
local subirDlg = registrarVentana(LuaDialog(service)) subirDlg.setTitle("Subir Complemento")
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{EditText, id="etDescSubir", hint="Descripción del complemento", layout_width="match_parent", layout_height="match_parent", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"}
},
{Button, id="btnElegir", text="Elegir complemento", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{TextView, id="tvNomSel", text="", visibility="gone", padding="8dp", textColor="0xFFFFFFFF"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) subirDlg.dismiss() end},
{Button, id="btnAceptar", text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
subirDlg.setView(loadlayout(layout, views))
subirDlg.setOnCancelListener({onCancel = function() doVibrate(50) subirDlg.dismiss() end})
subirDlg.show()
views.btnElegir.setOnClickListener({onClick = function()
doVibrate(50) seleccionarComplementoLocalDialog(function(n, r)
ruta = r
nombre = n
views.tvNomSel.setText("Seleccionado: " .. n)
views.tvNomSel.setTextColor(0xFF4CAF50)
views.tvNomSel.setVisibility(View.VISIBLE)
service.asyncSpeak("Complemento seleccionado: " .. n)
end)
end})
views.btnAceptar.setOnClickListener({onClick = function()
doVibrate(50) if not ruta then service.asyncSpeak("Selecciona un complemento") return end
if not autorizado then service.asyncSpeak("No autorizado") return end
local pub = obtenerNombrePublicoParaGuardar(userName) if not pub then service.asyncSpeak("Sin nombre público") return end
local desc = views.etDescSubir.getText().toString() subirDlg.dismiss()
function iniciarSubida(urlTutorial, carpetaOrigen, carpetaTemporalABorrar)
carpetaOrigen = carpetaOrigen or ruta
local prog = mostrarProgreso("Subiendo...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. nombre .. ".zip" compressFolder(carpetaOrigen, zipPath)
local res = subirAGitHubRelease(zipPath, nombre)
if res then
local complementoExistente = nil
for _, c in ipairs(complementos) do
if c.autor == pub and c.nombre == nombre then
complementoExistente = c
break
end
end
if complementoExistente then
complementoExistente.descripcion = desc
complementoExistente.url_github = res.url
complementoExistente.release_id = res.release_id
complementoExistente.fecha_actualizacion = os.time()
complementoExistente.url_tutorial = urlTutorial or ""
else
table.insert(complementos, {
id = pub .. "::" .. nombre,
nombre = nombre, descripcion = desc, autor = pub, url_github = res.url,
release_id = res.release_id, fecha_actualizacion = os.time(),
descargas = 0, url_tutorial = urlTutorial or ""
})
end
local okArchivoComplemento = guardarArchivoUsuarioSync(pub)
local okArchivoCalificaciones = crearArchivoCalificacionesDirecto({nombre=nombre})
local ok = okArchivoComplemento and okArchivoCalificaciones
service.postExecute(0, "x", nil, function()
prog.dismiss()
if ok then
service.asyncSpeak(complementoExistente and "Complemento actualizado correctamente" or "Subido correctamente")
guardarTodoElRespaldo()
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al guardar")
end
end)
else
service.postExecute(0, "x", nil, function() prog.dismiss() service.asyncSpeak("No se puede subir complementos por ahora. Inténtalo más tarde.") end)
end
service.postExecute(2000, "x", nil, function()
pcall(function() File(zipPath).delete() end)
if carpetaTemporalABorrar then pcall(function() borrarCarpetaRecursivo(carpetaTemporalABorrar) end) end
end)
end)
end
function iniciarSubidaConTutorial(urlTutorial)
local progVerifNueva = mostrarProgreso("Verificando complemento...")
en_hilo(function()
local okVerifNueva, encriptadoNueva = pcall(estaComplementoEncriptado, ruta .. "/main.lua")
if not okVerifNueva then encriptadoNueva = false end
service.postExecute(0, "x", nil, function()
pcall(function() progVerifNueva.dismiss() end)
if not encriptadoNueva then
mostrarAdvertenciaSinEncriptar(ruta, function() iniciarSubida(urlTutorial) end, function(tempDir) iniciarSubida(urlTutorial, tempDir, tempDir) end)
else
iniciarSubida(urlTutorial)
end
end)
end)
end
mostrarDialogoTutorialSubida(iniciarSubidaConTutorial)
end})
end
function mostrarInstrucciones()
doVibrate(50)
local instruccionesParagraphs = {}
for paragraph in instruccionesText:gmatch("[^\n]+") do
if paragraph:match("%S") then
table.insert(instruccionesParagraphs, paragraph)
end
end
local instruccionesLayout = {
LinearLayout,
orientation = "vertical",
layout_width = "fill",
layout_height = "fill",
padding = "20dp",
backgroundColor = 0xFF000000,
{
TextView,
text = "LEE CON MUCHA ATENCIÓN LAS INSTRUCCIONES",
layout_width = "wrap_content",
layout_height = "wrap_content",
textSize = "20sp",
textColor = 0xFF00FF00,
gravity = "center",
layout_marginBottom = "20dp",
layout_gravity = "center_horizontal"
},
{
ScrollView,
layout_width = "match_parent",
layout_height = "300dp",
layout_marginBottom = "20dp",
{
LinearLayout,
id = "instruccionesContainer",
orientation = "vertical",
layout_width = "match_parent",
layout_height = "wrap_content",
padding = "8dp"
}
},
{
Button,
id = "instruccionesOkButton",
text = "Entendido",
layout_width = "200dp",
layout_height = "wrap_content",
backgroundColor = 0xFF4CAF50,
textColor = 0xFFFFFFFF,
layout_gravity = "center_horizontal"
}
}
dlgIns = registrarVentana(LuaDialog(service))
dlgIns.setTitle("Instrucciones de uso")
local views = {}
local dialogView = loadlayout(instruccionesLayout, views)
for i, paragraph in ipairs(instruccionesParagraphs) do
local paragraphView = TextView(service)
paragraphView.setText(paragraph)
paragraphView.setTextColor(0xFFFFFFFF)
paragraphView.setTextSize(14)
paragraphView.setPadding(12, 8, 12, 8)
paragraphView.setBackgroundColor(0xFF333333)
local layoutParams = LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
)
layoutParams.setMargins(0, 0, 0, 2)
paragraphView.setLayoutParams(layoutParams)
views.instruccionesContainer.addView(paragraphView)
end
dlgIns.setView(dialogView)
dlgIns.setCancelable(true)
dlgIns.setOnCancelListener({onCancel = function() doVibrate(50) dlgIns.dismiss() end})
views.instruccionesOkButton.onClick = function()
doVibrate(50)
service.asyncSpeak("Cerrado")
dlgIns.dismiss()
end
dlgIns.show()
service.asyncSpeak("Mostrando instrucciones de uso")
end
function mostrarConfiguraciones()
doVibrate(50)
dlgConfig = registrarVentana(LuaDialog(service)) dlgConfig.setTitle("Configuraciones")
local views = {}
local layout = {
ScrollView, layout_width="match_parent", layout_height="wrap_content", backgroundColor="0xFF000000",
{LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", backgroundColor="0xFF000000", padding="16dp",
{Button, id="btnNombreUsuario", text="Usuario: " .. (obtenerNombrePublicoParaGuardar(userName) or userName), backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnVib", text=vibrationEnabled and "Vibración: Activada" or "Vibración: Desactivada", backgroundColor=vibrationEnabled and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{LinearLayout, id="layVib", orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", visibility = vibrationEnabled and View.VISIBLE or View.GONE, padding="8dp",
{TextView, id="txtVib", text="Intensidad: " .. vibrationIntensity .. "%", textColor="0xFFFFFFFF", layout_width="0dp", layout_weight="1", gravity="center_vertical"},
{SeekBar, id="seekVib", layout_width="0dp", layout_weight="2", max="100", progress=tostring(vibrationIntensity)}
},
{Button, id="btnFijar", text=textoBotonFijar(), backgroundColor=fijarPerfilesActivo and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{Button, id="btnOcultar", text=textoBotonOcultar(), backgroundColor=ocultarUsuariosActivo and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="0dp", layout_weight=1, padding="16dp"},
{Button, id="btnVerOcultos", text="Ver usuarios ocultos", visibility = ocultarUsuariosActivo and View.VISIBLE or View.GONE, backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="0dp", layout_weight=1, padding="16dp"}
},
{Button, id="btnConf", text=pedirConfirmacion and "Pedir confirmación antes de instalar: Activado" or "Pedir confirmación antes de instalar: Desactivado", backgroundColor=pedirConfirmacion and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnInterfaz", text=textoBotonInterfazTienda(), backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnModLocales", text=textoBotonModificarLocales(), backgroundColor=mostrarTodosLocalesAlModificar and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnIns", text="Instrucciones de uso", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCreditos", text="Créditos", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnTerminos", text="Términos y Condiciones", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCerrarSesion", text="Cerrar sesión", backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, text="Cerrar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) dlgConfig.dismiss() end}
}
}
dlgConfig.setView(loadlayout(layout, views))
dlgConfig.setOnCancelListener({onCancel = function() doVibrate(50) dlgConfig.dismiss() end})
function actualizarUIConfig()
views.btnNombreUsuario.setText("Usuario: " .. (obtenerNombrePublicoParaGuardar(userName) or userName))
views.btnVib.setText(vibrationEnabled and "Vibración: Activada" or "Vibración: Desactivada")
views.btnVib.setBackgroundColor(vibrationEnabled and 0xFF4CAF50 or 0xFF333333)
views.layVib.setVisibility(vibrationEnabled and View.VISIBLE or View.GONE)
views.txtVib.setText("Intensidad: " .. vibrationIntensity .. "%")
views.seekVib.setProgress(vibrationIntensity)
views.btnFijar.setText(textoBotonFijar())
views.btnFijar.setBackgroundColor(fijarPerfilesActivo and 0xFF4CAF50 or 0xFF333333)
views.btnOcultar.setText(textoBotonOcultar())
views.btnOcultar.setBackgroundColor(ocultarUsuariosActivo and 0xFF4CAF50 or 0xFF333333)
views.btnVerOcultos.setVisibility(ocultarUsuariosActivo and View.VISIBLE or View.GONE)
views.btnConf.setText(pedirConfirmacion and "Pedir confirmación antes de instalar: Activado" or "Pedir confirmación antes de instalar: Desactivado")
views.btnConf.setBackgroundColor(pedirConfirmacion and 0xFF4CAF50 or 0xFF333333)
views.btnInterfaz.setText(textoBotonInterfazTienda())
views.btnModLocales.setText(textoBotonModificarLocales())
views.btnModLocales.setBackgroundColor(mostrarTodosLocalesAlModificar and 0xFF4CAF50 or 0xFF333333)
end
dlgConfig.show()
views.btnNombreUsuario.setOnClickListener({onClick = function()
doVibrate(50)
mostrarEditarNombre()
end})
views.btnCerrarSesion.setOnClickListener({onClick = function()
doVibrate(50)
if not autorizado then
service.asyncSpeak("No tienes un perfil en la tienda")
return
end
pcall(function() dlgConfig.dismiss() end)
confirmarEliminarPerfil()
end})
views.btnVib.setOnClickListener({onClick = function()
doVibrate(50) vibrationEnabled = not vibrationEnabled prefs.edit().putBoolean("vibrationEnabled", vibrationEnabled).apply()
actualizarUIConfig()
end})
views.seekVib.setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener{
onProgressChanged = function(s, p, f) if f then vibrationIntensity = p prefs.edit().putInt("vibrationIntensity", p).apply() actualizarUIConfig() doVibrate(30) end end
})
views.btnFijar.setOnClickListener({onClick = function()
doVibrate(50)
fijarPerfilesActivo = not fijarPerfilesActivo
prefs.edit().putBoolean(CLAVE_FIJAR_ACTIVO, fijarPerfilesActivo).apply()
actualizarUIConfig()
service.asyncSpeak(fijarPerfilesActivo and "Fijar perfiles activado. Mantén pulsado un perfil para fijarlo." or "Fijar perfiles desactivado")
refrescarListaUsuariosVisible()
end})
views.btnOcultar.setOnClickListener({onClick = function()
doVibrate(50)
ocultarUsuariosActivo = not ocultarUsuariosActivo
prefs.edit().putBoolean(CLAVE_OCULTAR_ACTIVO, ocultarUsuariosActivo).apply()
actualizarUIConfig()
service.asyncSpeak(ocultarUsuariosActivo and "Ocultar usuarios activado. Mantén pulsado un perfil para ocultarlo." or "Ocultar usuarios desactivado. Se muestran todos los perfiles.")
refrescarListaUsuariosVisible()
end})
views.btnVerOcultos.setOnClickListener({onClick = function()
doVibrate(50)
mostrarUsuariosOcultos()
end})
views.btnConf.setOnClickListener({onClick = function()
doVibrate(50) pedirConfirmacion = not pedirConfirmacion prefs.edit().putBoolean("pedirConfirmacion", pedirConfirmacion).apply()
actualizarUIConfig()
end})
views.btnModLocales.setOnClickListener({onClick = function()
doVibrate(50)
mostrarTodosLocalesAlModificar = not mostrarTodosLocalesAlModificar
prefs.edit().putBoolean(CLAVE_MOSTRAR_TODOS_LOCALES, mostrarTodosLocalesAlModificar).apply()
actualizarUIConfig()
service.asyncSpeak(mostrarTodosLocalesAlModificar and "Al modificar una publicación se mostrarán todos tus complementos locales" or "Al modificar una publicación se seleccionará automáticamente el complemento con el mismo nombre")
end})
views.btnInterfaz.setOnClickListener({onClick = function()
doVibrate(50)
interfazTienda = (interfazTienda == "botones") and "paginas" or "botones"
prefs.edit().putString(CLAVE_INTERFAZ_TIENDA, interfazTienda).apply()
actualizarUIConfig()
pcall(function() dlgConfig.dismiss() end)
mostrarDialogoUsuarios()
service.asyncSpeak(interfazTienda == "botones" and "Ahora usas botones para el Top 5 y el Top 10" or "Ahora usas páginas para el Top 5 y el Top 10")
end})
views.btnIns.setOnClickListener({onClick = function() doVibrate(50) mostrarInstrucciones() end})
views.btnCreditos.setOnClickListener({onClick = function() doVibrate(50) mostrarCreditos() end})
views.btnTerminos.setOnClickListener({onClick = function() doVibrate(50) mostrarTerminosYCondiciones() end})
end
construirInterfazPrincipal = function()
if dlgPrincipal then
local visible=false
pcall(function() visible=dlgPrincipal.isShowing() end)
if visible then actualizarListaUI() return end
pcall(function() dlgPrincipal.dismiss() end)
end
dlgPrincipal = registrarVentana(LuaDialog(service))
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000",
{TextView, id="tvTitulo", textSize="20sp", gravity="center", padding="16dp", textColor="0xFFFFFFFF"},
{Button, id="btnSubir", text="Subir Complemento", visibility="gone", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="4dp",
{EditText, id="etSearch", hint="Buscar...", layout_width="0dp", layout_weight="1", singleLine="true", maxLines="1", inputType="text", imeOptions="actionDone", textColor="0xFFFFFFFF"},
{Button, id="btnClear", text="Borrar", visibility="gone", layout_width="wrap_content", layout_height="wrap_content", padding="12dp"},
{Button, id="btnSort", text="Ordenar", layout_width="wrap_content", layout_height="wrap_content", padding="12dp"}
},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contComp", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}},
{Button, id="btnVolver", text="Volver", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) volverAPantallaUsuarios() end}
}
dlgPrincipal.setView(loadlayout(layout, views))
dlgPrincipal.setOnCancelListener({onCancel = function() doVibrate(50) volverAPantallaUsuarios() end})
dlgPrincipal.show()
tvTitulo = views.tvTitulo
btnSubirComplemento = views.btnSubir
searchEditText = views.etSearch
btnClear = views.btnClear
btnSort = views.btnSort
contenedorComplementos = views.contComp
btnSubirComplemento.setOnClickListener({onClick = function() doVibrate(50) abrirSubirComplemento() end})
btnSort.setOnClickListener({onClick = function() doVibrate(50) mostrarMenuOrdenar() end})
btnClear.setOnClickListener({onClick = function() doVibrate(30) searchEditText.setText("") end})
searchEditText.addTextChangedListener({onTextChanged = function(s)
local text = s.toString()
if text:len() > 0 then btnClear.setVisibility(View.VISIBLE) else btnClear.setVisibility(View.GONE) end
buscar(text)
end})
pcall(function()
searchEditText.setSingleLine(true)
searchEditText.setMaxLines(1)
searchEditText.setInputType(0x00000001)
searchEditText.setImeOptions(EditorInfo.IME_ACTION_DONE)
searchEditText.setOnEditorActionListener({
onEditorAction = function(v, actionId, event)
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then imm.hideSoftInputFromWindow(v.getWindowToken(), 0) end
v.clearFocus()
return true
end
})
searchEditText.setOnKeyListener({
onKey = function(v, keyCode, event)
if keyCode == KeyEvent.KEYCODE_ENTER then
if event.getAction() == KeyEvent.ACTION_DOWN then
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then imm.hideSoftInputFromWindow(v.getWindowToken(), 0) end
v.clearFocus()
end
return true
end
return false
end
})
end)
end
function mostrarAccesoDenegado()
local d = registrarVentana(LuaDialog(service))
d.setTitle("Atención")
d.setCancelable(true)
local v = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="Se le ha denegado el acceso a crear un perfil", textColor="0xFFFFFFFF", textSize="15sp", padding="8dp"},
{Button, id="btnAceptar", text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
service.asyncSpeak("Se le ha denegado el acceso a crear un perfil")
v.btnAceptar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
end
creandoPerfilEnCurso = false
function crearPerfilPropio(nombre)
if creandoPerfilEnCurso then
service.asyncSpeak("Tu perfil ya se está creando. Espera un momento, no lo vuelvas a crear.")
return
end
creandoPerfilEnCurso = true
local progDlg = mostrarProgreso("Creando perfil. Puede tardar unos segundos; no cierres ni vuelvas a crearlo.")
en_hilo(function()
local ok, motivo = registrarUsuarioSync(nombre, false)
local selloActual = 0
if ok or motivo == "ya_existe" then selloActual = obtenerSelloTerminosCriticosSync() end
service.postExecute(0, "x", nil, function()
creandoPerfilEnCurso = false
pcall(function() progDlg.dismiss() end)
if ok then
prefs.edit().putLong(CLAVE_TERMINOS_SELLO, selloActual).apply()
service.asyncSpeak("Perfil creado. Ya puedes publicar complementos y notificaciones. Si tarda en verse en otros dispositivos, espera unos segundos.")
recargarDatos(function() mostrarDialogoUsuarios() end)
elseif motivo == "ya_existe" then
service.asyncSpeak("Ya tienes un perfil creado. No hace falta crearlo otra vez.")
recargarDatos(function() mostrarDialogoUsuarios() end)
elseif motivo == "nombre_en_uso" then
service.asyncSpeak("Ese nombre público ya lo usa otra persona. Elige otro.")
elseif motivo == "ocupado" then
service.asyncSpeak("Hay muchas personas creando perfiles en este momento. Espera un minuto e inténtalo de nuevo.")
else
service.asyncSpeak("No se pudo crear el perfil. Revisa tu conexión e inténtalo de nuevo.")
end
end)
end)
end
TEXTO_TERMINOS = [[
Bienvenido a nuestra plataforma. Estas reglas están diseñadas para mantener un espacio ordenado y útil para todos los usuarios que publican y descargan complementos. Por favor, lea atentamente cada punto antes de comenzar a compartir su trabajo.
Evite romper este reglamento para no ser expulsado definitivamente de la tienda de complementos.
1. Exclusividad de publicación
Al publicar sus complementos aquí, usted acepta no distribuirlos en otras tiendas de la competencia ni en el servidor oficial de Jieshuo. Esta norma busca evitar la saturación y la repetición de contenido, y es una condición indispensable para pertenecer a la tienda. Sin embargo, sí está permitido guardar copias de respaldo en canales personales de Telegram o grupos privados de WhatsApp, siempre que no se publiquen activamente en otras plataformas públicas de descarga.
2. Respeto a la propiedad intelectual y catálogos
Cada creador gestiona su propio catálogo con etiquetas específicas. Está estrictamente prohibido descargar un complemento de un catálogo ajeno y volverlo a subir en otro. Por ejemplo, si un complemento pertenece al catálogo Tutoriales para Ciegos o Mi Android Accesible, no puede ser republicado por terceros sin permiso. Esto protege el trabajo original de cada desarrollador y mantiene la integridad de los catálogos.
3. Uso correcto de las notificaciones
El apartado de notificaciones en la interfaz principal es exclusivo para informar sobre actualizaciones de complementos y novedades técnicas. Queda prohibido usar este espacio para chistes, conversaciones informales, spam, invitaciones a grupos o canales sociales. Mantenga este apartado limpio para que todos los usuarios puedan seguir fácilmente las mejoras de las herramientas. Solo puede mantener una notificación publicada y puede publicar una nueva cada 6 horas.
4. Prioridad en funcionalidad y utilidad
Buscamos complementos que mejoren realmente la interacción con el lector de pantalla. La prioridad son las herramientas funcionales con interfaces gráficas personalizadas, sistemas de automatización de tareas y autoclicks. Los complementos basados únicamente en sonidos o efectos auditivos simples, como cambiar el tono de una nota de voz, se consideran secundarios. Le invitamos a crear herramientas que resuelvan problemas reales y hagan el uso del dispositivo más eficiente.
5. Compromiso con la comunidad
Se espera que los desarrolladores actúen con lealtad hacia la comunidad. Esto implica promover el uso positivo de la tienda y contribuir a su crecimiento con contenido original y de valor. Al publicar aquí, usted forma parte fundamental de un ecosistema accesible y superior para todos los usuarios.
6. Solamente pueden entrar desarrolladores independientes.
Si cuentas con una tienda de tu propia autoría, te invitamos a continuar con tu proyecto. Este espacio es para apoyar a los creadores independientes, proporcionándoles un distribuidor masivo más accesible.
7. Catálogo propio y repertorio considerable
Esta tienda está dirigida a personas que realmente desarrollan complementos. Por ello, antes de crear su perfil, debe contar ya con un repertorio considerable de complementos funcionales, de su autoría y listos para publicar.
No está permitido tener un perfil con solo uno o dos complementos. Con frecuencia, este tipo de perfiles se crean para figurar como creador: publican un complemento de autopromoción, ya sea solo o acompañado de un complemento funcional con la intención de disimularlo. Aquí no hay lugar para el engaño: los complementos cuyo único fin sea promocionar las redes sociales, canales, grupos, tiendas o servicios del autor no se aceptan.
Los perfiles que no cumplan estas condiciones serán retirados de la tienda por los administradores, sin previo aviso.
8. Esfuerzo real y trabajo constante
Ser creador en esta tienda exige esfuerzo comprobable y constancia: publicar complementos útiles, funcionales y que realmente ayuden a la comunidad, y mantener y mejorar su catálogo con el tiempo. Crear un perfil solo para aparentar que se es desarrollador, o para subir un par de complementos y desaparecer, no es una colaboración válida.
No se admiten perfiles de relleno, que solo ocupan espacio y consumen recursos de la tienda sin aportar nada útil a los demás. Los administradores revisan los perfiles y retirarán a quienes se registren como creadores sin tener un trabajo real, constante y en crecimiento detrás.
9. Cambios en estos términos
Cuando estos términos cambian de forma importante, la tienda mostrará un aviso a los usuarios que crearon un perfil de creador y deberán aceptarlo para continuar. Seguir usando el perfil después del aviso implica aceptar la versión vigente.
Sé honesto al crear tu cuenta.
Al aceptar estos términos y condiciones y crear tu cuenta, es porque exclusivamente cumples con todos los requisitos para pertenecer a esta comunidad. De lo contrario, si decides evadir este reglamento, serás expulsado definitivamente por los administradores.
Al publicar en esta tienda, usted confirma haber leído, entendido y aceptado estas condiciones.
]]
function mostrarTerminosYCondiciones()
local d = registrarVentana(LuaDialog(service))
d.setTitle("Términos y condiciones")
d.setCancelable(true)
local v = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1",
{LinearLayout, id="contTerminos", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{Button, id="btnCerrarTerminos", text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
local dialogView = loadlayout(layout, v)
for parrafo in TEXTO_TERMINOS:gmatch("[^\n]+") do
if parrafo:match("%S") then
local tv = TextView(service)
tv.setText(parrafo)
tv.setTextColor(0xFFFFFFFF)
tv.setTextSize(14)
tv.setPadding(12, 8, 12, 8)
tv.setBackgroundColor(0xFF222222)
local lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
lp.setMargins(0, 0, 0, 2)
tv.setLayoutParams(lp)
v.contTerminos.addView(tv)
end
end
d.setView(dialogView)
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnCerrarTerminos.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
end
function confirmarNombrePerfil(nombre)
local terminos = TEXTO_TERMINOS
local d = registrarVentana(LuaDialog(service))
d.setTitle("Términos y condiciones")
d.setCancelable(true)
local v = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1",
{LinearLayout, id="contTerminos", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{TextView, text="Al aceptar, tu perfil se crea en el servidor de GitHub. Puede tardar unos segundos, y más si mucha gente se registra al mismo tiempo. Ten paciencia: no lo crees dos veces ni cierres la tienda mientras aparezca «Creando perfil». Si todavía no se ve en otros dispositivos, espera un poco y vuelve a abrir la tienda.", textColor="0xFFFFD700", textSize="14sp", padding="8dp"},
{TextView, text="¿Aceptas estos términos y usarás \"" .. nombre .. "\" como tu nombre público?", textColor="0xFFFFFFFF", textSize="15sp", padding="8dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{Button, id="btnNo", text="No acepto", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp"},
{Button, id="btnSi", text="Acepto", layout_weight=1, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", padding="16dp"}
}
}
local dialogView = loadlayout(layout, v)
for parrafo in terminos:gmatch("[^\n]+") do
if parrafo:match("%S") then
local tv = TextView(service)
tv.setText(parrafo)
tv.setTextColor(0xFFFFFFFF)
tv.setTextSize(14)
tv.setPadding(12, 8, 12, 8)
tv.setBackgroundColor(0xFF222222)
local lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
lp.setMargins(0, 0, 0, 2)
tv.setLayoutParams(lp)
v.contTerminos.addView(tv)
end
end
d.setView(dialogView)
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnNo.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnSi.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) crearPerfilPropio(nombre) end})
end
function mostrarCrearPerfil()
local d = registrarVentana(LuaDialog(service))
d.setTitle("Crear tu perfil")
d.setCancelable(true)
local v = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="Elige el nombre público con el que aparecerán tus complementos y notificaciones.", textColor="0xFFFFFFFF", textSize="14sp", padding="8dp"},
{EditText, id="etNombre", hint="Nombre público", layout_width="match_parent", padding="8dp", textColor="0xFFFFFFFF"},
{Button, id="btnUsarUsuario", text="Usar tu nombre de usuario del lector: " .. userName, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="12dp"},
{Button, id="btnCrear", text="Crear perfil", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCancelar", text="Cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnUsarUsuario.setOnClickListener({onClick = function()
doVibrate(50)
if nombrePublicoEnUso(userName) then
service.asyncSpeak("Ese nombre ya está en uso, elige otro")
return
end
pcall(function() d.dismiss() end)
confirmarNombrePerfil(userName)
end})
v.btnCancelar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnCrear.setOnClickListener({onClick = function()
doVibrate(50)
local nombre = tostring(v.etNombre.getText())
nombre = nombre:match("^%s*(.-)%s*$") or ""
if nombre == "" then
service.asyncSpeak("Escribe un nombre público")
return
end
if nombrePublicoEnUso(nombre) then
service.asyncSpeak("Ese nombre ya está en uso, elige otro")
return
end
pcall(function() d.dismiss() end)
confirmarNombrePerfil(nombre)
end})
end
function iniciarCreacionDePerfil()
local progDlg = mostrarProgreso("Verificando...", true)
en_hilo(function()
local bloqueado = verificarExpulsadoSync(userName, ANDROID_ID_CALIFICACIONES)
service.postExecute(0, "x", nil, function()
pcall(function() progDlg.dismiss() end)
if bloqueado then
mostrarAccesoDenegado()
else
mostrarCrearPerfil()
end
end)
end)
end
function obtenerShaArchivoGitHubSync(filename)
local okG, codeG, bodyG = pcall(http_get, GITHUB_API .. "/contents/" .. filename .. "?t=" .. os.time(), githubHeaders())
if okG and codeG == 200 then
local okPG, rjG = pcall(JSONObject, bodyG)
if okPG and rjG.has("sha") then return rjG.getString("sha") end
end
return nil
end
function eliminarArchivoUsuarioGitHubSync(pub)
if not pub or pub == "" then return true end
local filename = nombreArchivoSeguro(pub) .. ".json"
local existente = archivosUsuarios[pub]
local sha = (existente and existente.sha) or obtenerShaArchivoGitHubSync(filename)
if not sha then
archivosUsuarios[pub] = nil
return true
end
local bodyBorrar = "{\"message\":\"Eliminar perfil " .. jsonEscape(pub) .. "\",\"sha\":\"" .. sha .. "\"}"
local ok, code = pcall(http_send, "DELETE", GITHUB_API .. "/contents/" .. filename, bodyBorrar, githubHeaders())
if ok and (code == 200 or code == 204) then
archivosUsuarios[pub] = nil
anunciosUsuario[pub] = nil
return true
end
sha = obtenerShaArchivoGitHubSync(filename)
if not sha then archivosUsuarios[pub] = nil return true end
bodyBorrar = "{\"message\":\"Eliminar perfil " .. jsonEscape(pub) .. "\",\"sha\":\"" .. sha .. "\"}"
ok, code = pcall(http_send, "DELETE", GITHUB_API .. "/contents/" .. filename, bodyBorrar, githubHeaders())
if ok and (code == 200 or code == 204) then
archivosUsuarios[pub] = nil
anunciosUsuario[pub] = nil
return true
end
return false
end
function renombrarArchivoUsuarioPropioSync(viejo, nuevoNombre)
local existente = archivosUsuarios[viejo]
local raiz = JSONObject()
raiz.put("usuario_publico", nuevoNombre)
raiz.put("anuncio", anunciosUsuario[viejo] or "")
local arr = JSONArray()
for _, c in ipairs(listaDelAutorEnMemoria(viejo)) do
local obj = JSONObject()
obj.put("nombre", c.nombre or "")
obj.put("descripcion", c.descripcion or "")
obj.put("url_github", c.url_github or "")
obj.put("release_id", c.release_id or "")
obj.put("fecha_actualizacion", c.fecha_actualizacion or 0)
obj.put("descargas", c.descargas or 0)
obj.put("url_tutorial", c.url_tutorial or "")
arr.put(obj)
end
raiz.put("complementos", arr)
local contenido = raiz.toString()
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(contenido) writer.flush() writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local filenameViejo = (existente and existente.filename) or (nombreArchivoSeguro(viejo) .. ".json")
local filenameNuevo = nombreArchivoSeguro(nuevoNombre) .. ".json"
if filenameNuevo == filenameViejo then
local shaUsar = (existente and existente.sha) or obtenerShaArchivoGitHubSync(filenameViejo)
local body = "{\"message\":\"Cambiar nombre público a " .. jsonEscape(nuevoNombre) .. "\",\"content\":\"" .. b64 .. "\""
if shaUsar and shaUsar ~= "" then body = body .. ",\"sha\":\"" .. shaUsar .. "\"" end
body = body .. "}"
local ok, code, respBody = pcall(http_send, "PUT", GITHUB_API .. "/contents/" .. filenameViejo, body, githubHeaders())
if ok and (code == 200 or code == 201) then
local okP, rj = pcall(JSONObject, respBody)
local nuevoSha = nil
if okP and rj.has("content") then
local okC, cObj = pcall(function() return rj.getJSONObject("content") end)
if okC and cObj.has("sha") then nuevoSha = cObj.getString("sha") end
end
archivosUsuarios[viejo] = nil
archivosUsuarios[nuevoNombre] = {sha = nuevoSha, filename = filenameViejo}
anunciosUsuario[nuevoNombre] = anunciosUsuario[viejo]
anunciosUsuario[viejo] = nil
for _, c in ipairs(complementos) do if c.autor == viejo then c.autor = nuevoNombre end end
return true
end
return false
end
local shaNuevoExistente = obtenerShaArchivoGitHubSync(filenameNuevo)
local bodyCrear = "{\"message\":\"Renombrar perfil a " .. jsonEscape(nuevoNombre) .. "\",\"content\":\"" .. b64 .. "\""
if shaNuevoExistente and shaNuevoExistente ~= "" then
bodyCrear = bodyCrear .. ",\"sha\":\"" .. shaNuevoExistente .. "\""
end
bodyCrear = bodyCrear .. "}"
local ok, code, respBody = pcall(http_send, "PUT", GITHUB_API .. "/contents/" .. filenameNuevo, bodyCrear, githubHeaders())
if not (ok and (code == 200 or code == 201)) then return false end
local okP, rj = pcall(JSONObject, respBody)
local nuevoSha = nil
if okP and rj.has("content") then
local okC, cObj = pcall(function() return rj.getJSONObject("content") end)
if okC and cObj.has("sha") then nuevoSha = cObj.getString("sha") end
end
local shaViejo = (existente and existente.sha) or obtenerShaArchivoGitHubSync(filenameViejo)
local borradoOk = false
if shaViejo then
local bodyBorrar = "{\"message\":\"Eliminar archivo antiguo de " .. jsonEscape(viejo) .. " tras renombrar\",\"sha\":\"" .. shaViejo .. "\"}"
local okDel, codeDel = pcall(http_send, "DELETE", GITHUB_API .. "/contents/" .. filenameViejo, bodyBorrar, githubHeaders())
borradoOk = okDel and (codeDel == 200 or codeDel == 204)
if not borradoOk then
shaViejo = obtenerShaArchivoGitHubSync(filenameViejo)
if shaViejo then
bodyBorrar = "{\"message\":\"Eliminar archivo antiguo de " .. jsonEscape(viejo) .. " tras renombrar\",\"sha\":\"" .. shaViejo .. "\"}"
okDel, codeDel = pcall(http_send, "DELETE", GITHUB_API .. "/contents/" .. filenameViejo, bodyBorrar, githubHeaders())
borradoOk = okDel and (codeDel == 200 or codeDel == 204)
end
end
else
borradoOk = true
end
if not borradoOk then
archivosUsuarios[nuevoNombre] = {sha = nuevoSha, filename = filenameNuevo}
for _, c in ipairs(complementos) do if c.autor == viejo then c.autor = nuevoNombre end end
return false
end
archivosUsuarios[viejo] = nil
archivosUsuarios[nuevoNombre] = {sha = nuevoSha, filename = filenameNuevo}
anunciosUsuario[nuevoNombre] = anunciosUsuario[viejo]
anunciosUsuario[viejo] = nil
for _, c in ipairs(complementos) do if c.autor == viejo then c.autor = nuevoNombre end end
return true
end
function cambiarNombrePerfilSync(nuevoNombre)
local viejo = obtenerNombrePublicoParaGuardar(userName) or userName
if viejo == nuevoNombre then return true end
local okUsuarios = registrarUsuarioSync(nuevoNombre, true)
if not okUsuarios then return false end
local okArchivo = renombrarArchivoUsuarioPropioSync(viejo, nuevoNombre)
return okArchivo
end
function actualizarDescripcionPerfilSync(nuevaDesc)
nuevaDesc = tostring(nuevaDesc or ""):match("^%s*(.-)%s*$") or ""
local maxIntentos = 6
for intento = 1, maxIntentos do
local lista, sha = leerUsuariosDesdeAPISync()
if not lista then
local okR, codeR, bodyR = pcall(http_get, USUARIOS_URL .. "?t=" .. os.time())
if okR and codeR == 200 then
lista = parsearUsuariosJSON(bodyR)
else
lista = {}
end
sha = obtenerSHAUsuariosSync()
end
local encontrado = false
for _, u in ipairs(lista) do
if u.username == userName then
u.descripcion_perfil = nuevaDesc
encontrado = true
break
end
end
if not encontrado then return false end
local ok, code = intentarGuardarUsuariosJSON(lista, sha, "Actualizar descripción de perfil de " .. userName)
if ok then
usuariosData = lista
return true
end
if code ~= 409 and code ~= 422 then return false end
pcall(function() Thread.sleep(150 * intento) end)
end
return false
end
function eliminarTodosMisComplementosSync()
local pub = obtenerNombrePublicoParaGuardar(userName) or userName
local restantes = {}
for _, c in ipairs(complementos) do
if c.autor == pub then
if c.release_id and c.release_id ~= "" then
eliminarReleaseGitHub(c.release_id, "complemento-" .. c.nombre:gsub("[^a-zA-Z0-9_-]", ""))
end
else
table.insert(restantes, c)
end
end
complementos = restantes
end
function eliminarPerfilPropioSync()
local pub = obtenerNombrePublicoParaGuardar(userName) or userName
eliminarTodosMisComplementosSync()
eliminarArchivoUsuarioGitHubSync(pub)
local ok = quitarUsuarioTxtSync()
if ok then
archivosUsuarios[pub] = nil
anunciosUsuario[pub] = nil
pcall(guardarTodoElRespaldo)
end
return ok
end
function mostrarEditarNombre()
if not autorizado then
service.asyncSpeak("No tienes un perfil en la tienda")
return
end
local actual = obtenerNombrePublicoParaGuardar(userName) or userName
local descActual = obtenerDescripcionPerfil(userName) or ""
local ahora = os.time()
local ultimaNombre = prefs.getLong("ultima_edicion_nombre_ts", 0)
local ultimaDesc = prefs.getLong("ultima_edicion_desc_perfil_ts", 0)
local puedeCambiarNombre = not (ultimaNombre > 0 and (ahora - ultimaNombre) < 43200)
local puedeCambiarDesc = not (ultimaDesc > 0 and (ahora - ultimaDesc) < 43200)
local function textoEspera(ultima)
local falta = 43200 - (ahora - ultima)
local horas = math.floor(falta / 3600)
local mins = math.floor((falta % 3600) / 60)
if horas > 0 then
return "Faltan " .. horas .. " h y " .. mins .. " min."
end
return "Faltan " .. mins .. " minutos."
end
local d = registrarVentana(LuaDialog(service))
d.setTitle("Editar perfil")
d.setCancelable(true)
local v = {}
local avisoNombre = puedeCambiarNombre and "Puedes cambiar el nombre (máx. una vez cada 12 horas)." or ("Nombre bloqueado 12 h. " .. textoEspera(ultimaNombre))
local avisoDesc = puedeCambiarDesc and "Puedes cambiar la descripción (máx. una vez cada 12 horas)." or ("Descripción bloqueada 12 h. " .. textoEspera(ultimaDesc))
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="Nombre público:", textColor="0xFFFFFFFF", textSize="14sp", padding="4dp"},
{EditText, id="etNombre", text=actual, layout_width="match_parent", padding="8dp", textColor="0xFFFFFFFF"},
{TextView, text=avisoNombre, textColor="0xFFAAAAAA", textSize="12sp", padding="4dp"},
{TextView, text="Descripción del perfil (máx. 200 caracteres):", textColor="0xFFFFFFFF", textSize="14sp", padding="8dp"},
{EditText, id="etDescPerfil", text=descActual, hint="Una frase sobre ti o tus complementos...", layout_width="match_parent", padding="8dp", textColor="0xFFFFFFFF", minLines="2", maxLines="4", gravity="top"},
{TextView, text=avisoDesc, textColor="0xFFAAAAAA", textSize="12sp", padding="4dp"},
{Button, id="btnGuardar", text="Guardar", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCancelar", text="Cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
pcall(function()
v.etNombre.setEnabled(puedeCambiarNombre)
v.etDescPerfil.setEnabled(puedeCambiarDesc)
if descActual ~= "" then
v.etDescPerfil.setText(descActual)
end
limitarCaracteres(v.etDescPerfil, 200)
end)
v.btnCancelar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnGuardar.setOnClickListener({onClick = function()
doVibrate(50)
local nuevo = tostring(v.etNombre.getText() or "")
nuevo = nuevo:match("^%s*(.-)%s*$") or ""
local nuevaDesc = tostring(v.etDescPerfil.getText() or "")
nuevaDesc = nuevaDesc:gsub("[\r\n]+", " ")
nuevaDesc = nuevaDesc:match("^%s*(.-)%s*$") or ""
local largoDesc = #nuevaDesc
pcall(function() largoDesc = String(nuevaDesc).length() end)
if largoDesc > 200 then
service.asyncSpeak("La descripción admite máximo 200 caracteres")
return
end
if nuevo == "" then
service.asyncSpeak("Escribe un nombre público")
return
end
local cambioNombre = (nuevo ~= actual)
local cambioDesc = (nuevaDesc ~= descActual)
if not cambioNombre and not cambioDesc then
pcall(function() d.dismiss() end)
service.asyncSpeak("Sin cambios")
return
end
if cambioNombre and not puedeCambiarNombre then
service.asyncSpeak("Debes esperar 12 horas entre cambios de nombre. " .. textoEspera(ultimaNombre))
return
end
if cambioDesc and not puedeCambiarDesc then
service.asyncSpeak("Debes esperar 12 horas entre cambios de descripción. " .. textoEspera(ultimaDesc))
return
end
if cambioNombre and nombrePublicoEnUso(nuevo) then
service.asyncSpeak("Ese nombre ya está en uso, elige otro")
return
end
pcall(function() d.dismiss() end)
local progDlg = mostrarProgreso("Guardando...")
en_hilo(function()
local ok = true
if cambioNombre then
ok = cambiarNombrePerfilSync(nuevo)
if ok then
prefs.edit().putLong("ultima_edicion_nombre_ts", os.time()).apply()
end
end
if ok and cambioDesc then
ok = actualizarDescripcionPerfilSync(nuevaDesc)
if ok then
prefs.edit().putLong("ultima_edicion_desc_perfil_ts", os.time()).apply()
end
end
service.postExecute(0, "x", nil, function()
pcall(function() progDlg.dismiss() end)
if ok then
service.asyncSpeak("Perfil actualizado")
recargarDatos(function()
pcall(function() if dlgConfig then dlgConfig.dismiss() end end)
mostrarDialogoUsuarios()
end)
else
service.asyncSpeak("No se pudo actualizar el perfil")
end
end)
end)
end})
end
function confirmarEliminarPerfil()
local d = registrarVentana(LuaDialog(service))
d.setTitle("Atención")
d.setCancelable(true)
local v = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="¿Cerrar sesión y eliminar su perfil? También se eliminarán todos sus complementos publicados en la tienda.", textColor="0xFFFFFFFF", textSize="15sp", padding="8dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{Button, id="btnNo", text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp"},
{Button, id="btnSi", text="Sí", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="16dp"}
}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnNo.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnSi.setOnClickListener({onClick = function()
doVibrate(50)
pcall(function() d.dismiss() end)
local progDlg = mostrarProgreso("Eliminando perfil...")
en_hilo(function()
local ok = eliminarPerfilPropioSync()
service.postExecute(0, "x", nil, function()
pcall(function() progDlg.dismiss() end)
if ok then
service.asyncSpeak("Perfil eliminado")
recargarDatos(function() mostrarDialogoUsuarios() end)
else
service.asyncSpeak("No se pudo eliminar el perfil")
end
end)
end)
end})
end
function mostrarMenuPerfilPropio()
local d = registrarVentana(LuaDialog(service))
d.setTitle("Tu perfil")
d.setCancelable(true)
local v = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{Button, id="btnEditar", text="Editar nombre", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnEliminar", text="Eliminar", backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCancelar", text="Cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnCancelar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnEditar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) mostrarEditarNombre() end})
v.btnEliminar.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) confirmarEliminarPerfil() end})
end
pestanaActual = "perfiles"
contUsuariosRef = nil
contTop10Ref = nil
contTop5Ref = nil
etBuscarUsuariosRef = nil
tvSeleccionarUsuariosRef = nil
function refrescarListaUsuariosVisible()
pcall(function()
if dlgUsuarios and dlgUsuarios.isShowing() then
if renderizarListaUsuarios then renderizarListaUsuarios(textoBusquedaUsuarios(), true) end
if renderizarDestacados then renderizarDestacados() end
end
end)
end
function confirmarOcultarUsuario(u, nombre)
local d = registrarVentana(LuaDialog(service))
d.setTitle("Atención")
d.setCancelable(true)
local v = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="¿Quieres ocultar a " .. nombre .. "? Dejarás de ver su perfil y sus complementos. Podrás volver a mostrarlo desde Configuraciones, en Ver usuarios ocultos.", textColor="0xFFFFFFFF", textSize="15sp", padding="8dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{Button, id="btnNo", text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp"},
{Button, id="btnSi", text="Sí, ocultar", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="16dp"}
}
}, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnNo.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
v.btnSi.setOnClickListener({onClick = function()
doVibrate(50)
pcall(function() d.dismiss() end)
ocultarPerfil(u)
service.asyncSpeak(nombre .. " ocultado")
refrescarListaUsuariosVisible()
end})
end
function mostrarMenuPerfilAjeno(u)
local nombre = obtenerNombreVisible(u)
local d = registrarVentana(LuaDialog(service))
d.setTitle(nombre)
d.setCancelable(true)
local v = {}
local layout = {LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp", backgroundColor="0xFF000000"}
if fijarPerfilesActivo then
table.insert(layout, {Button, id="btnFijarPerfil", text=estaFijado(u) and "Quitar de fijados" or "Fijar perfil", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"})
end
if ocultarUsuariosActivo then
table.insert(layout, {Button, id="btnOcultarPerfil", text="Ocultar usuario", backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"})
end
table.insert(layout, {Button, id="btnCancelarMenu", text="Cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"})
d.setView(loadlayout(layout, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
v.btnCancelarMenu.setOnClickListener({onClick = function() doVibrate(50) pcall(function() d.dismiss() end) end})
if v.btnFijarPerfil then
v.btnFijarPerfil.setOnClickListener({onClick = function()
doVibrate(50)
pcall(function() d.dismiss() end)
if estaFijado(u) then
quitarFijado(u)
service.asyncSpeak(nombre .. " ya no está fijado")
else
local ok = fijarPerfil(u)
if ok then
service.asyncSpeak(nombre .. " fijado en la posición " .. tostring(posicionEnLista(perfilesFijados, u)))
else
service.asyncSpeak("Ya tienes " .. MAX_PERFILES_FIJADOS .. " perfiles fijados. Quita uno para fijar otro.")
end
end
refrescarListaUsuariosVisible()
end})
end
if v.btnOcultarPerfil then
v.btnOcultarPerfil.setOnClickListener({onClick = function()
doVibrate(50)
pcall(function() d.dismiss() end)
confirmarOcultarUsuario(u, nombre)
end})
end
end
function mostrarUsuariosOcultos()
if dlgOcultos then pcall(function() dlgOcultos.dismiss() end) end
dlgOcultos = registrarVentana(LuaDialog(service))
dlgOcultos.setTitle("Usuarios ocultos")
dlgOcultos.setCancelable(true)
local v = {}
dlgOcultos.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight=1,
{LinearLayout, id="contOcultos", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}},
{Button, id="btnCerrarOcultos", text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, v))
dlgOcultos.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() dlgOcultos.dismiss() end) end})
dlgOcultos.show()
v.btnCerrarOcultos.setOnClickListener({onClick = function() doVibrate(50) pcall(function() dlgOcultos.dismiss() end) end})
local function pintar()
v.contOcultos.removeAllViews()
if #usuariosOcultos == 0 then
v.contOcultos.addView(loadlayout({TextView, text="No tienes usuarios ocultos", textColor="0xFFFFFFFF", textSize="16sp", padding="12dp"}))
return
end
for _, u in ipairs(usuariosOcultos) do
local nombre = obtenerNombreVisible(u)
v.contOcultos.addView(loadlayout({Button, text="Mostrar de nuevo a " .. nombre, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
mostrarPerfilOculto(u)
service.asyncSpeak(nombre .. " vuelve a mostrarse")
pintar()
refrescarListaUsuariosVisible()
end}))
v.contOcultos.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
end
pintar()
end
function obtenerSelloTerminosCriticosSync()
local ok, texto = leerArchivoRepoTextoSync("terminos_critica.txt")
if not ok then return 0 end
return tonumber((texto or ""):match("%d+")) or 0
end
function usuarioExentoTerminosSync()
local ok, texto = leerArchivoRepoTextoSync("terminos_exentos.txt")
if not ok then return nil end
local claves = {}
claves[tostring(userName):lower()] = true
local pubPropio = obtenerNombrePublicoParaGuardar(userName)
if pubPropio and pubPropio ~= "" then claves[tostring(pubPropio):lower()] = true end
for linea in (texto or ""):gmatch("[^\r\n]+") do
local limpio = linea:match("^%s*(.-)%s*$") or ""
if limpio ~= "" and limpio:sub(1, 1) ~= "#" then
if claves[limpio:lower()] then return true end
end
end
return false
end
function aceptarTerminosCriticos()
prefs.edit().putLong(CLAVE_TERMINOS_SELLO, selloTerminosPendiente or 0).apply()
local d = dlgTerminosCritica
dlgTerminosCritica = nil
terminosCriticosMarcados = false
if d then pcall(function() d.dismiss() end) end
service.asyncSpeak("Términos aceptados")
end
function manejarAtrasTerminosCriticos()
if terminosCriticosMarcados then
aceptarTerminosCriticos()
else
service.asyncSpeak("Para continuar, marca la casilla de que leíste los términos y presiona Entendido.")
end
end
function mostrarTerminosCriticos(sello)
if dlgTerminosCritica then return end
selloTerminosPendiente = sello
terminosCriticosMarcados = false
local d = registrarVentana(LuaDialog(service))
dlgTerminosCritica = d
d.setTitle("Aviso importante: términos y condiciones")
d.setCancelable(false)
local v = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{TextView, text="Los administradores actualizaron los términos y condiciones. Debes leerlos para continuar.", textColor="0xFFFFD700", textSize="15sp", padding="8dp"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1",
{LinearLayout, id="contTerminos", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{CheckBox, id="chkAcepto", text="He leído y acepto los términos y condiciones", textColor="0xFFFFFFFF", padding="12dp"},
{Button, id="btnEntendido", text="Entendido", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
local dialogView = loadlayout(layout, v)
for parrafo in TEXTO_TERMINOS:gmatch("[^\n]+") do
if parrafo:match("%S") then
local tv = TextView(service)
tv.setText(parrafo)
tv.setTextColor(0xFFFFFFFF)
tv.setTextSize(14)
tv.setPadding(12, 8, 12, 8)
tv.setBackgroundColor(0xFF222222)
local lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
lp.setMargins(0, 0, 0, 2)
tv.setLayoutParams(lp)
v.contTerminos.addView(tv)
end
end
v.btnEntendido.setEnabled(false)
d.setView(dialogView)
d.setOnKeyListener({onKey=function(_, keyCode, event)
if keyCode == KeyEvent.KEYCODE_BACK then
if event.getAction() == 1 then manejarAtrasTerminosCriticos() end
return true
end
return false
end})
d.show()
v.chkAcepto.setOnClickListener({onClick = function()
if v.chkAcepto.isChecked() then
terminosCriticosMarcados = true
v.btnEntendido.setEnabled(true)
service.asyncSpeak("Casilla marcada. Ya puedes presionar Entendido.")
else
v.chkAcepto.setChecked(true)
end
end})
v.btnEntendido.setOnClickListener({onClick = function()
doVibrate(50)
if not terminosCriticosMarcados then
service.asyncSpeak("Marca primero la casilla de que leíste los términos.")
return
end
aceptarTerminosCriticos()
end})
service.asyncSpeak("Aviso importante. Los términos y condiciones cambiaron. Léelos, marca la casilla y presiona Entendido.")
end
function verificarTerminosCriticos()
if terminosCriticosVerificados or dlgTerminosCritica then return end
if usandoCacheLocal or userName == "" or not autorizado or necesitaCrearPerfil() then return end
terminosCriticosVerificados = true
en_hilo(function()
local okSello, textoSello = leerArchivoRepoTextoSync("terminos_critica.txt")
local sello = okSello and (tonumber((textoSello or ""):match("%d+")) or 0) or nil
local exento = nil
if sello and sello > prefs.getLong(CLAVE_TERMINOS_SELLO, 0) then
exento = usuarioExentoTerminosSync()
end
service.postExecute(0, "x", nil, function()
if sello == nil or (sello > prefs.getLong(CLAVE_TERMINOS_SELLO, 0) and exento == nil) then
terminosCriticosVerificados = false
return
end
if sello > prefs.getLong(CLAVE_TERMINOS_SELLO, 0) then
if exento then
prefs.edit().putLong(CLAVE_TERMINOS_SELLO, sello).apply()
else
mostrarTerminosCriticos(sello)
end
end
end)
end)
end
function obtenerUsernameDesdePublico(pub)
for _, u in ipairs(usuariosData) do
if u.public_name == pub then return u.username end
end
return pub
end
function obtenerTop5Creadores()
local totales = {}
local orden = {}
for _, c in ipairs(complementos) do
local autor = c.autor or ""
if autor ~= "" and not autorOculto(autor) then
if not totales[autor] then
totales[autor] = {autor = autor, descargas = 0, cantidad = 0}
table.insert(orden, totales[autor])
end
totales[autor].descargas = totales[autor].descargas + (c.descargas or 0)
totales[autor].cantidad = totales[autor].cantidad + 1
end
end
table.sort(orden, function(a, b)
if a.descargas ~= b.descargas then return a.descargas > b.descargas end
if a.cantidad ~= b.cantidad then return a.cantidad > b.cantidad end
return a.autor:lower() < b.autor:lower()
end)
local top = {}
for i = 1, math.min(5, #orden) do top[i] = orden[i] end
return top
end
function mostrarTop5Creadores()
local top5 = obtenerTop5Creadores()
local d = registrarVentana(LuaDialog(service))
d.setCancelable(true)
local v = {}
local layout = {LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000"}
table.insert(layout, {TextView, text="TOP 5 DE DESARROLLADORES CON MÁS DESCARGAS\n(" .. #top5 .. " desarrolladores)", textSize="20sp", gravity="center", padding="16dp", textColor="0xFFFFFFFF"})
local scroll = {ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1"}
local cont = {LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
if #top5 == 0 then
table.insert(cont, {TextView, text="Todavía no hay suficientes datos.", textSize="16sp", padding="16dp", gravity="center", textColor="0xFFFFFFFF"})
else
for i, t in ipairs(top5) do
table.insert(cont, {LinearLayout, orientation="vertical", backgroundColor="0xFF202125", padding="12dp", clickable=true, onClick=function()
doVibrate(50)
pcall(function() d.dismiss() end)
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
local u = obtenerUsernameDesdePublico(t.autor)
usuarioSeleccionado = u
vinoDesdeTop5Desarrolladores = true
filtrados = {}
for _, c in ipairs(complementos) do if c.autor == t.autor then table.insert(filtrados, c) end end
ordenarComplementos(filtrados, ordenActual)
construirInterfazPrincipal()
actualizarListaUI()
service.asyncSpeak("Yendo a " .. t.autor)
end,
{TextView, text=i .. ". " .. t.autor, textSize="18sp", textColor="0xFFFFFFFF"},
{TextView, text="Descargas: " .. t.descargas, textSize="14sp", textColor="0xFF4CAF50", paddingBottom="4dp"},
{TextView, text="Complementos: " .. t.cantidad, textSize="14sp", textColor="0xFFFFD700", paddingBottom="2dp"}
})
table.insert(cont, {View, layout_width="match_parent", layout_height="8dp"})
end
end
table.insert(scroll, cont)
table.insert(layout, scroll)
table.insert(layout, {Button, text="Volver", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.setView(loadlayout(layout, v))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
end
function irAPerfilUsuario(u, desdeTop5)
doVibrate(50)
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
usuarioSeleccionado = u
vinoDesdeTop5Desarrolladores = false
filtrados = {}
local pub = obtenerNombrePublicoParaGuardar(u) or u
for _, c in ipairs(complementos) do if c.autor == pub then table.insert(filtrados, c) end end
ordenarComplementos(filtrados, ordenActual)
construirInterfazPrincipal()
actualizarListaUI()
if usandoCacheLocal then
local esDuenoDelCatalogo = autorizado and u == userName
service.asyncSpeak(esDuenoDelCatalogo and "Conectado al servidor de respaldo, el principal vuelve pronto. Puedes instalar complementos con normalidad, pero no podrás editar, subir ni eliminar hasta que el servidor principal esté disponible." or "Conectado al servidor de respaldo, el principal vuelve pronto.")
end
end
function priorizarYAbrirComplemento(c)
doVibrate(50)
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
local autorC = c.autor or ""
usuarioSeleccionado = obtenerUsernameDesdePublico(autorC)
vinoDesdeTop5Desarrolladores = false
local idC = c.id or (autorC .. "::" .. (c.nombre or ""))
local elegido = nil
local resto = {}
for _, cc in ipairs(complementos) do
if cc.autor == autorC then
local idCc = cc.id or ((cc.autor or "") .. "::" .. (cc.nombre or ""))
if (c.id and cc.id == c.id) or (idCc == idC) or (cc.nombre == c.nombre and cc.autor == autorC) then
if not elegido then elegido = cc else table.insert(resto, cc) end
else
table.insert(resto, cc)
end
end
end
ordenarComplementos(resto, ordenActual)
filtrados = {}
if elegido then table.insert(filtrados, elegido) end
for _, cc in ipairs(resto) do table.insert(filtrados, cc) end
construirInterfazPrincipal()
actualizarListaUI()
service.asyncSpeak((elegido and elegido.nombre) or (c.nombre or autorC or ""))
end
function irATop10()
doVibrate(50)
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
usuarioSeleccionado = TOP_USUARIO
vinoDesdeTop5Desarrolladores = false
filtrados = obtenerTop10()
construirInterfazPrincipal()
actualizarListaUI()
end
function irAComplementoDesdeBusqueda(c)
priorizarYAbrirComplemento(c)
end
function mostrarInterfazBusqueda()
doVibrate(50)
local d = registrarVentana(LuaDialog(service))
d.setTitle("Buscar")
d.setCancelable(true)
local views = {}
d.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", padding="8dp",
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{EditText, id="etBuscar", hint="Buscar perfil o complemento...", layout_width="0dp", layout_weight="1", singleLine="true", maxLines="1", inputType="text", imeOptions="actionSearch", textColor="0xFFFFFFFF", padding="12dp"},
{Button, id="btnBuscar", text="Buscar", layout_width="wrap_content", layout_height="wrap_content", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="12dp"}
},
{TextView, id="tvResultados", text="Escribe y pulsa Buscar", textSize="14sp", textColor="0xFFAAAAAA", padding="8dp"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1",
{LinearLayout, id="contResultados", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{Button, id="btnVolverBuscar", text="Volver", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}, views))
d.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() d.dismiss() end) end})
d.show()
local function ejecutarBusqueda()
local query = tostring(views.etBuscar.getText() or ""):match("^%s*(.-)%s*$") or ""
query = query:lower()
views.contResultados.removeAllViews()
if query == "" then
views.tvResultados.setText("Escribe y pulsa Buscar")
service.asyncSpeak("Escribe algo para buscar")
return
end
local coincidencias = 0
for _, u in ipairs(usuariosActivos or {}) do
if usuarioVisible(u) then
local nombreVisible = obtenerNombreVisible(u)
local count = contarComplementosPorUsuario(u)
local descPerfil = obtenerDescripcionPerfil(u)
local txt = (u == userName) and ("Mis complementos (" .. count .. ")") or (nombreVisible .. " (" .. count .. ")")
if descPerfil ~= "" then txt = txt .. " — " .. descPerfil end
if txt:lower():find(query, 1, true) or (nombreVisible or ""):lower():find(query, 1, true) or (descPerfil or ""):lower():find(query, 1, true) then
coincidencias = coincidencias + 1
views.contResultados.addView(loadlayout({Button, text="Perfil: " .. txt, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
pcall(function() d.dismiss() end)
irAPerfilUsuario(u, false)
end}))
views.contResultados.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
end
end
for _, c in ipairs(complementos or {}) do
local nombreC = (c.nombre or ""):lower()
if nombreC:find(query, 1, true) and not autorOculto(c.autor) then
coincidencias = coincidencias + 1
local autorC = c.autor or ""
views.contResultados.addView(loadlayout({Button, text="Complemento: " .. (c.nombre or "") .. " (" .. autorC .. ")", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
pcall(function() d.dismiss() end)
irAComplementoDesdeBusqueda(c)
end}))
views.contResultados.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
end
if coincidencias == 0 then
views.tvResultados.setText("Sin coincidencias")
views.contResultados.addView(loadlayout({TextView, text="Sin coincidencias", textColor="0xFFFFFFFF", padding="12dp"}))
service.asyncSpeak("No se encontraron coincidencias")
else
views.tvResultados.setText(coincidencias .. " coincidencia" .. (coincidencias == 1 and "" or "s"))
service.asyncSpeak(coincidencias .. " coincidencias encontradas")
end
end
views.btnBuscar.setOnClickListener({onClick = function()
doVibrate(50)
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then pcall(function() imm.hideSoftInputFromWindow(views.etBuscar.getWindowToken(), 0) end) end
ejecutarBusqueda()
end})
views.btnVolverBuscar.setOnClickListener({onClick = function()
doVibrate(50)
pcall(function() d.dismiss() end)
end})
pcall(function()
views.etBuscar.setSingleLine(true)
views.etBuscar.setMaxLines(1)
views.etBuscar.setInputType(0x00000001)
views.etBuscar.setImeOptions(EditorInfo.IME_ACTION_SEARCH)
views.etBuscar.requestFocus()
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then pcall(function() imm.showSoftInput(views.etBuscar, 0) end) end
views.etBuscar.setOnEditorActionListener({
onEditorAction = function(v, actionId, event)
if actionId == EditorInfo.IME_ACTION_SEARCH or actionId == EditorInfo.IME_ACTION_DONE then
local imm2 = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm2 then imm2.hideSoftInputFromWindow(v.getWindowToken(), 0) end
ejecutarBusqueda()
return true
end
return false
end
})
views.etBuscar.setOnKeyListener({
onKey = function(v, keyCode, event)
if keyCode == KeyEvent.KEYCODE_ENTER and event.getAction() == KeyEvent.ACTION_DOWN then
local imm2 = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm2 then imm2.hideSoftInputFromWindow(v.getWindowToken(), 0) end
ejecutarBusqueda()
return true
end
return false
end
})
end)
service.asyncSpeak("Buscar perfil o complemento")
end
function renderizarTop10()
if not contTop10Ref then return end
contTop10Ref.removeAllViews()
if usandoCacheLocal then
contTop10Ref.addView(loadlayout({TextView, text="Conectado al servidor de respaldo, el principal vuelve pronto.", textColor="0xFFFFEB3B", backgroundColor="0xFF333333", padding="8dp"}))
contTop10Ref.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
local top10 = obtenerTop10()
if #top10 == 0 then
contTop10Ref.addView(loadlayout({TextView, text="Todavía no hay suficientes datos.", textSize="14sp", padding="12dp", gravity="center", textColor="0xFFFFFFFF"}))
else
for i, c in ipairs(top10) do
local nombre = c.nombre or ""
local autor = c.autor or ""
local descargas = c.descargas or 0
local compRef = c
contTop10Ref.addView(loadlayout({
LinearLayout, orientation="vertical", backgroundColor="0xFF202125", padding="12dp", clickable=true, onClick=function()
doVibrate(50)
mostrarMenuComplemento(compRef)
end,
{TextView, text=i .. ". " .. nombre, textSize="17sp", textColor="0xFFFFFFFF"},
{TextView, text="Autor: " .. autor, textSize="14sp", textColor="0xFFFFD700", paddingBottom="2dp"},
{TextView, text="Descargas: " .. descargas, textSize="14sp", textColor="0xFF4CAF50"}
}))
contTop10Ref.addView(loadlayout({View, layout_width="match_parent", layout_height="6dp"}))
end
end
end
function renderizarTop5Desarrolladores()
if not contTop5Ref then return end
contTop5Ref.removeAllViews()
if usandoCacheLocal then
contTop5Ref.addView(loadlayout({TextView, text="Conectado al servidor de respaldo, el principal vuelve pronto.", textColor="0xFFFFEB3B", backgroundColor="0xFF333333", padding="8dp"}))
contTop5Ref.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
local top5 = obtenerTop5Creadores()
if #top5 == 0 then
contTop5Ref.addView(loadlayout({TextView, text="Todavía no hay suficientes datos.", textSize="14sp", padding="12dp", gravity="center", textColor="0xFFFFFFFF"}))
else
for i, t in ipairs(top5) do
local autor = t.autor
local vTop = {}
contTop5Ref.addView(loadlayout({
LinearLayout, orientation="vertical", backgroundColor="0xFF202125", padding="12dp", clickable=true, onClick=function()
local u = obtenerUsernameDesdePublico(autor)
irAPerfilUsuario(u, true)
service.asyncSpeak("Yendo a " .. autor)
end,
{TextView, text=i .. ". " .. autor, textSize="18sp", textColor="0xFFFFFFFF"},
{TextView, text="Descargas: " .. (t.descargas or 0), textSize="14sp", textColor="0xFF4CAF50", paddingBottom="2dp"},
{TextView, text="Complementos: " .. (t.cantidad or 0), textSize="14sp", textColor="0xFFFFD700"}
}, vTop))
contTop5Ref.addView(loadlayout({View, layout_width="match_parent", layout_height="6dp"}))
end
end
end
function renderizarDestacados()
renderizarTop10()
renderizarTop5Desarrolladores()
end
function textoBusquedaUsuarios()
local t = ""
pcall(function() if etBuscarUsuariosRef then t = tostring(etBuscarUsuariosRef.getText() or "") end end)
return (t:match("^%s*(.-)%s*$") or "")
end
function renderizarListaUsuarios(filtro, silencioso)
if not contUsuariosRef then return end
filtro = (filtro or ""):lower()
contUsuariosRef.removeAllViews()
local coincidencias = 0
local function actualizarContadorUsuarios(n)
pcall(function()
if tvSeleccionarUsuariosRef then tvSeleccionarUsuariosRef.setText("Seleccionar usuarios: " .. n) end
end)
end
if filtro == "" and necesitaCrearPerfil() then
contUsuariosRef.addView(loadlayout({Button, text="Crear tu perfil", backgroundColor="0xFFFF9800", textColor="0xFF000000", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
iniciarCreacionDePerfil()
end}))
contUsuariosRef.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
if usandoCacheLocal then
contUsuariosRef.addView(loadlayout({TextView, text="Conectado al servidor de respaldo, el principal vuelve pronto.", textColor="0xFFFFEB3B", backgroundColor="0xFF333333", padding="8dp"}))
end
if (not usandoCacheLocal) and autorizado and not misComplementosDisponibles then
contUsuariosRef.addView(loadlayout({TextView, text="No se puede subir ni editar complementos en este momento. Las notificaciones globales también están desactivadas temporalmente. Inténtalo más tarde.", textColor="0xFFFFEB3B", backgroundColor="0xFF333333", padding="8dp"}))
end
if not usuariosActivos or #usuariosActivos == 0 then
actualizarContadorUsuarios(0)
contUsuariosRef.addView(loadlayout({TextView, text="Cargando...", textColor="0xFFFFFFFF"}))
return
end
local function agregarBotonUsuario(u, fijado)
local count = contarComplementosPorUsuario(u)
local nombreVisible = obtenerNombreVisible(u)
local txt = (u == userName) and ("Mis complementos (" .. count .. ")") or (nombreVisible .. " (" .. count .. ")")
local descPerfil = obtenerDescripcionPerfil(u)
if descPerfil ~= "" then
txt = txt .. " — " .. descPerfil
end
if filtro ~= "" then
local hay = txt:lower():find(filtro, 1, true) or (nombreVisible or ""):lower():find(filtro, 1, true) or (descPerfil or ""):lower():find(filtro, 1, true)
if not hay then return false end
end
coincidencias = coincidencias + 1
local vUsr = {}
contUsuariosRef.addView(loadlayout({Button, id="btnUsr", text=fijado and ("Fijado: " .. txt) or txt, backgroundColor=fijado and "0xFF455A64" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
irAPerfilUsuario(u, false)
end}, vUsr))
if u ~= userName and (fijarPerfilesActivo or ocultarUsuariosActivo) then
vUsr.btnUsr.setOnLongClickListener({onLongClick = function()
doVibrate(50)
mostrarMenuPerfilAjeno(u)
return true
end})
end
contUsuariosRef.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
return true
end
local coincTop = 0
local topMostrado, top5Mostrado = false, false
local function agregarBotonTop5()
if interfazTienda ~= "botones" or top5Mostrado then return end
if filtro ~= "" and not ("top 5 de desarrolladores con más descargas"):find(filtro, 1, true) then return end
top5Mostrado = true
coincTop = coincTop + 1
contUsuariosRef.addView(loadlayout({Button, text="TOP 5 DE DESARROLLADORES CON MÁS DESCARGAS", backgroundColor="0xFF7F7F7F", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
mostrarTop5Creadores()
end}))
contUsuariosRef.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
local function agregarBotonTop()
if interfazTienda ~= "botones" or topMostrado then return end
if filtro ~= "" and not NOMBRE_TOP:lower():find(filtro, 1, true) then return end
topMostrado = true
coincTop = coincTop + 1
contUsuariosRef.addView(loadlayout({Button, text=NOMBRE_TOP, backgroundColor="0xFFB8860B", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
irATop10()
end}))
contUsuariosRef.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
local fijadosMostrados = {}
if fijarPerfilesActivo then
for _, pu in ipairs(perfilesFijados) do
if pu ~= userName and not fijadosMostrados[pu] and posicionEnLista(usuariosActivos, pu) and usuarioVisible(pu) then
fijadosMostrados[pu] = true
agregarBotonUsuario(pu, true)
end
end
end
if usuariosActivos[1] ~= userName then agregarBotonTop5() agregarBotonTop() end
for _, u in ipairs(usuariosActivos) do
if not fijadosMostrados[u] and usuarioVisible(u) then
if agregarBotonUsuario(u, false) and u == userName then agregarBotonTop5() agregarBotonTop() end
end
end
agregarBotonTop5()
agregarBotonTop()
actualizarContadorUsuarios(coincidencias)
local totalCoincidencias = coincidencias + coincTop
if filtro ~= "" then
for _, c in ipairs(complementos or {}) do
if ((c.nombre or ""):lower():find(filtro, 1, true)) and not autorOculto(c.autor) then
totalCoincidencias = totalCoincidencias + 1
local cRef = c
contUsuariosRef.addView(loadlayout({Button, text="Complemento: " .. (c.nombre or "") .. " (" .. (c.autor or "") .. ")", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
irAComplementoDesdeBusqueda(cRef)
end}))
contUsuariosRef.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
end
if totalCoincidencias == 0 then
contUsuariosRef.addView(loadlayout({TextView, text="Sin coincidencias", textColor="0xFFFFFFFF", padding="12dp"}))
if not silencioso then service.asyncSpeak("No se encontraron coincidencias") end
else
if not silencioso then service.asyncSpeak(totalCoincidencias .. " coincidencias encontradas") end
end
end
end
function mostrarDialogoUsuariosPaginas()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
dlgUsuarios = registrarVentana(LuaDialog(service))
local views = {}
dlgUsuarios.setView(loadlayout({
LinearLayout, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", orientation="vertical", padding="8dp",
{TextView, id="tvTituloTienda", text="Tienda de complementos", textSize="20sp", gravity="center", padding="12dp", textColor="0xFFFFFFFF"},
{TextView, id="tvSeleccionarUsuarios", text="Seleccionar usuarios: 0", textSize="14sp", gravity="center", padding="6dp", textColor="0xFFAAAAAA"},
{EditText, id="etBuscarUsuarios", hint="Buscar perfil o complemento...", textSize="18sp", layout_width="match_parent", layout_height="wrap_content", singleLine="true", maxLines="1", inputType="text", imeOptions="actionSearch", textColor="0xFFFFFFFF", backgroundColor="0xFF222222", padding="12dp", focusable=true, focusableInTouchMode=true},
{PageView, id="pageViewTienda", layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
pages={
{ScrollView, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000",
{LinearLayout, id="contUsuarios", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{ScrollView, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000",
{LinearLayout, id="contTop10", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
},
{ScrollView, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000",
{LinearLayout, id="contTop5", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
}
}
},
{Button, id="btnNotif", text="Notificaciones", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnConfig", text="Configuraciones", backgroundColor="0xFF9C27B0", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) mostrarConfiguraciones() end},
{Button, text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) dlgUsuarios.dismiss() end}
}, views))
dlgUsuarios.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil end})
dlgUsuarios.show()
local function vista(id) return views[id] or _G[id] end
local pageView = vista("pageViewTienda")
local etBuscar = vista("etBuscarUsuarios")
local tvTitulo = vista("tvTituloTienda")
contUsuariosRef = vista("contUsuarios")
contTop10Ref = vista("contTop10")
contTop5Ref = vista("contTop5")
tvSeleccionarUsuariosRef = vista("tvSeleccionarUsuarios")
etBuscarUsuariosRef = etBuscar
btnNotifPrincipalRef = views.btnNotif
actualizarBotonNotifPrincipal()
views.btnNotif.setOnClickListener({onClick = function() doVibrate(50) mostrarInterfazNotificaciones() end})
local function aplicarPagina(pos)
pestanaActual = (pos == 0) and "perfiles" or ((pos == 1) and "top10" or "top5")
local vis = (pos == 0) and View.VISIBLE or View.GONE
etBuscar.setVisibility(vis)
tvSeleccionarUsuariosRef.setVisibility(vis)
tvTitulo.setText(pos == 0 and "Tienda de complementos" or ((pos == 1) and NOMBRE_TOP or "Top 5 de desarrolladores con más descargas"))
end
renderizarListaUsuarios("", true)
renderizarTop10()
renderizarTop5Desarrolladores()
pageView.setOnPageChangeListener({
onPageSelected = function(position)
doVibrate(30)
aplicarPagina(position)
pcall(function()
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then imm.hideSoftInputFromWindow(etBuscar.getWindowToken(), 0) end
end)
if position == 0 then
renderizarListaUsuarios(textoBusquedaUsuarios(), true)
service.asyncSpeak("Página de usuarios")
elseif position == 1 then
renderizarTop10()
service.asyncSpeak("Página de " .. NOMBRE_TOP)
else
renderizarTop5Desarrolladores()
service.asyncSpeak("Página de top 5 de desarrolladores con más descargas")
end
end
})
local busquedaPendiente = nil
etBuscar.addTextChangedListener({
onTextChanged = function(s, start, before, count)
if busquedaPendiente then handler.removeCallbacks(busquedaPendiente) end
local q = tostring(s.toString() or ""):match("^%s*(.-)%s*$") or ""
busquedaPendiente = Runnable { run = function()
busquedaPendiente = nil
renderizarListaUsuarios(q, q == "")
end }
handler.postDelayed(busquedaPendiente, 300)
end
})
etBuscar.setOnClickListener({onClick = function()
etBuscar.requestFocus()
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then pcall(function() imm.showSoftInput(etBuscar, 0) end) end
end})
pcall(function()
etBuscar.setSingleLine(true)
etBuscar.setMaxLines(1)
etBuscar.setInputType(0x00000001)
etBuscar.setImeOptions(EditorInfo.IME_ACTION_SEARCH)
etBuscar.setOnEditorActionListener({
onEditorAction = function(v, actionId, event)
if actionId == EditorInfo.IME_ACTION_SEARCH or actionId == EditorInfo.IME_ACTION_DONE then
local imm2 = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm2 then imm2.hideSoftInputFromWindow(v.getWindowToken(), 0) end
return true
end
return false
end
})
end)
local idx = 0
if pestanaActual == "top10" or pestanaActual == "destacados" then idx = 1
elseif pestanaActual == "top5" then idx = 2 end
aplicarPagina(idx)
pageView.setCurrentItem(idx)
if mostrarCreditosFlag then
mostrarCreditosFlag = false
handler.postDelayed(Runnable { run = function() mostrarCreditos() end }, 1000)
elseif contarNotificacionesNoLeidas() > 0 then
handler.postDelayed(Runnable { run = function()
service.asyncSpeak(textoNotificaciones(contarNotificacionesNoLeidas()))
end }, 1000)
end
verificarTerminosCriticos()
end
function mostrarDialogoUsuariosBotones()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
dlgUsuarios = registrarVentana(LuaDialog(service)) dlgUsuarios.setTitle("Tienda de complementos")
local views = {}
dlgUsuarios.setView(loadlayout({
LinearLayout, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", orientation="vertical", padding="8dp",
{Button, id="btnNotif", text="Notificaciones", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, text="Configuraciones", backgroundColor="0xFF9C27B0", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) mostrarConfiguraciones() end},
{TextView, id="tvSeleccionarUsuarios", text="Seleccionar usuarios: 0", textSize="16sp", gravity="center", padding="8dp", textColor="0xFFFFFFFF"},
{EditText, id="etBuscarUsuarios", hint="Buscar perfil o complemento...", layout_width="match_parent", padding="8dp", textColor="0xFFFFFFFF"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contUsr", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}},
{Button, text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) dlgUsuarios.dismiss() end}
}, views))
dlgUsuarios.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil end})
dlgUsuarios.show()
pestanaActual = "perfiles"
contUsuariosRef = views.contUsr
contTop10Ref = nil
contTop5Ref = nil
tvSeleccionarUsuariosRef = views.tvSeleccionarUsuarios
etBuscarUsuariosRef = views.etBuscarUsuarios
btnNotifPrincipalRef = views.btnNotif
actualizarBotonNotifPrincipal()
views.btnNotif.setOnClickListener({onClick = function() doVibrate(50) mostrarInterfazNotificaciones() end})
renderizarListaUsuarios("", true)
local busquedaPendiente = nil
views.etBuscarUsuarios.addTextChangedListener({
onTextChanged = function(s, start, before, count)
if busquedaPendiente then handler.removeCallbacks(busquedaPendiente) end
local q = tostring(s.toString() or ""):match("^%s*(.-)%s*$") or ""
busquedaPendiente = Runnable { run = function()
busquedaPendiente = nil
renderizarListaUsuarios(q, q == "")
end }
handler.postDelayed(busquedaPendiente, 300)
end
})
pcall(function()
views.etBuscarUsuarios.setSingleLine(true)
views.etBuscarUsuarios.setMaxLines(1)
views.etBuscarUsuarios.setInputType(0x00000001)
views.etBuscarUsuarios.setImeOptions(EditorInfo.IME_ACTION_DONE)
views.etBuscarUsuarios.setOnEditorActionListener({
onEditorAction = function(v, actionId, event)
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then imm.hideSoftInputFromWindow(v.getWindowToken(), 0) end
v.clearFocus()
return true
end
})
views.etBuscarUsuarios.setOnKeyListener({
onKey = function(v, keyCode, event)
if keyCode == KeyEvent.KEYCODE_ENTER then
if event.getAction() == KeyEvent.ACTION_DOWN then
local imm = service.getSystemService(Context.INPUT_METHOD_SERVICE)
if imm then imm.hideSoftInputFromWindow(v.getWindowToken(), 0) end
v.clearFocus()
end
return true
end
return false
end
})
end)
if mostrarCreditosFlag then
mostrarCreditosFlag = false
handler.postDelayed(Runnable { run = function() mostrarCreditos() end }, 1000)
elseif contarNotificacionesNoLeidas() > 0 then
handler.postDelayed(Runnable { run = function()
service.asyncSpeak(textoNotificaciones(contarNotificacionesNoLeidas()))
end }, 1000)
end
verificarTerminosCriticos()
end
function mostrarDialogoUsuarios()
if interfazTienda == "botones" then
mostrarDialogoUsuariosBotones()
else
mostrarDialogoUsuariosPaginas()
end
end
function subirNotificacionGlobal(mensaje, callback)
en_hilo(function()
local url = MSG_API_URL
local headers = githubHeaders()
local codeGet, bodyGet = http_get(url, headers)
local sha = nil
local contenidoActual = ""
if codeGet == 200 then
local ok, rj = pcall(JSONObject, bodyGet)
if ok and rj.has("sha") then sha = rj.getString("sha") end
if ok and rj.has("content") then
local contentBase64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
contenidoActual = tostring(String(bytes, StandardCharsets.UTF_8))
end
end
local pubName = obtenerNombrePublicoParaGuardar(userName) or userName
local timestamp = tostring(os.time())
mensaje = mensaje:gsub("[\r\n]+", " ")
mensaje = mensaje:match("^%s*(.-)%s*$") or mensaje
local lineasExistentes = {}
local patronAutor = "(" .. pubName .. " | "
for linea in contenidoActual:gmatch("[^\r\n]+") do
if not linea:find(patronAutor, 1, true) then
table.insert(lineasExistentes, linea)
end
end
local nuevoMensajeFormateado = mensaje .. " (" .. pubName .. " | " .. timestamp .. ")"
table.insert(lineasExistentes, 1, nuevoMensajeFormateado)
local nuevoContenido = table.concat(lineasExistentes, "\n")
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(nuevoContenido)
writer.flush()
writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local body = "{\"message\":\"Nueva notificacion global\",\"branch\":\"main\",\"content\":\"" .. b64 .. "\""
if sha then body = body .. ",\"sha\":\"" .. sha .. "\"" end
body = body .. "}"
local codePut, _ = http_send("PUT", url, body, headers)
service.postExecute(0, "x", nil, function()
if codePut == 200 or codePut == 201 then
prefs.edit().putLong("ultima_notif_publicada_ts", os.time()).apply()
callback(true)
else
callback(false)
end
end)
end)
end
function borrarMiHistorialNotificaciones(callback)
en_hilo(function()
local url = MSG_API_URL
local headers = githubHeaders()
local codeGet, bodyGet = http_get(url, headers)
local sha = nil
local contenidoActual = ""
if codeGet == 200 then
local ok, rj = pcall(JSONObject, bodyGet)
if ok and rj.has("sha") then sha = rj.getString("sha") end
if ok and rj.has("content") then
local contentBase64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
contenidoActual = tostring(String(bytes, StandardCharsets.UTF_8))
end
end
local pubName = obtenerNombrePublicoParaGuardar(userName) or userName
local patronBusqueda = "(" .. pubName .. " | "
local lineasFiltradas = {}
for linea in contenidoActual:gmatch("[^\r\n]+") do
if not linea:find(patronBusqueda, 1, true) then
table.insert(lineasFiltradas, linea)
end
end
local nuevoContenido = table.concat(lineasFiltradas, "\n")
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(nuevoContenido)
writer.flush()
writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local body = "{\"message\":\"Borrar mi historial de notificaciones\",\"branch\":\"main\",\"content\":\"" .. b64 .. "\""
if sha then body = body .. ",\"sha\":\"" .. sha .. "\"" end
body = body .. "}"
local codePut, _ = http_send("PUT", url, body, headers)
service.postExecute(0, "x", nil, function()
if codePut == 200 or codePut == 201 then callback(true) else callback(false) end
end)
end)
end
function borrarUnaNotificacion(lineaOriginal, callback)
en_hilo(function()
local url = MSG_API_URL
local headers = githubHeaders()
local codeGet, bodyGet = http_get(url, headers)
local sha = nil
local contenidoActual = ""
if codeGet == 200 then
local ok, rj = pcall(JSONObject, bodyGet)
if ok and rj.has("sha") then sha = rj.getString("sha") end
if ok and rj.has("content") then
local contentBase64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
contenidoActual = tostring(String(bytes, StandardCharsets.UTF_8))
end
end
local lineasFiltradas = {}
local eliminada = false
for linea in contenidoActual:gmatch("[^\r\n]+") do
local lineaLimpia = linea:match("^%s*(.-)%s*$")
if (not eliminada) and lineaLimpia == lineaOriginal then
eliminada = true
else
table.insert(lineasFiltradas, linea)
end
end
if not eliminada then
service.postExecute(0, "x", nil, function() callback(false) end)
return
end
local nuevoContenido = table.concat(lineasFiltradas, "\n")
local baos = ByteArrayOutputStream()
local writer = OutputStreamWriter(baos, StandardCharsets.UTF_8)
writer.write(nuevoContenido)
writer.flush()
writer.close()
local b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
local body = "{\"message\":\"Eliminar notificacion\",\"branch\":\"main\",\"content\":\"" .. b64 .. "\""
if sha then body = body .. ",\"sha\":\"" .. sha .. "\"" end
body = body .. "}"
local codePut, _ = http_send("PUT", url, body, headers)
service.postExecute(0, "x", nil, function()
if codePut == 200 or codePut == 201 then callback(true) else callback(false) end
end)
end)
end
function obtenerMensajeGlobalDeAPISync(callback)
en_hilo(function()
local url = MSG_API_URL .. "?t=" .. os.time()
local headers = githubHeaders()
local okReq, code, body = pcall(http_get, url, headers)
local nuevoMensaje = ""
local exito = false
if okReq and code == 200 then
local ok, rj = pcall(JSONObject, body)
if ok and rj then
exito = true
if rj.has("content") then
local contentBase64 = rj.getString("content"):gsub("\n", "")
local bytes = Base64.decode(contentBase64, Base64.NO_WRAP)
nuevoMensaje = tostring(String(bytes, StandardCharsets.UTF_8))
end
end
elseif okReq and code == 404 then
exito = true
end
service.postExecute(0, "x", nil, function()
callback(nuevoMensaje, exito)
end)
end)
end
function verificarEsperaNotificacion(alPermitir)
local progEsp = mostrarProgreso("Verificando tu última notificación...", true)
obtenerMensajeGlobalDeAPISync(function(textoActual, exito)
pcall(function() progEsp.dismiss() end)
if not exito then
service.asyncSpeak("No se pudo verificar tu última notificación. Inténtalo de nuevo.")
return
end
mensajeGlobal = (textoActual or ""):match("^%s*(.-)%s*$") or ""
local pubCheck = obtenerNombrePublicoParaGuardar(userName) or userName
local patronBusq = "(" .. pubCheck .. " | "
local ultima = 0
for linea in mensajeGlobal:gmatch("[^\r\n]+") do
if linea:find(patronBusq, 1, true) then
local ts = linea:match("| (%d+)%)")
if ts then
local n = tonumber(ts) or 0
if n > ultima then ultima = n end
end
end
end
if ultima == 0 then
prefs.edit().putLong("ultima_notif_publicada_ts", 0).apply()
alPermitir()
return
end
local ahora = os.time()
if (ahora - ultima) < ESPERA_NOTIFICACION_SEGUNDOS then
local falta = ESPERA_NOTIFICACION_SEGUNDOS - (ahora - ultima)
local horas = math.floor(falta / 3600)
local mins = math.floor((falta % 3600) / 60)
local textoEspera = "Debes esperar 6 horas entre notificaciones. "
if horas > 0 then
textoEspera = textoEspera .. "Faltan " .. horas .. " h y " .. mins .. " min."
else
textoEspera = textoEspera .. "Faltan " .. mins .. " minutos."
end
service.asyncSpeak(textoEspera)
local av = registrarVentana(LuaDialog(service))
av.setTitle("Espera 6 horas")
av.setMessage(textoEspera)
av.setView(loadlayout({LinearLayout, orientation="vertical", padding="16dp",
{Button, text="Entendido", layout_width="match_parent", padding="16dp", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", onClick=function() doVibrate(50) av.dismiss() end}
}))
av.show()
return
end
alPermitir()
end)
end
function mostrarInterfazNotificaciones()
local todas = obtenerTodasLasNotificaciones()
local pubNameActual = obtenerNombrePublicoParaGuardar(userName) or userName
for _, n in ipairs(todas) do
if not n.leida then marcarNotificacionComoLeida(n.mensaje) end
end
local d = registrarVentana(LuaDialog(service)) d.setTitle("Historial")
local views = {}
d.setView(loadlayout({LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{EditText, id="etBuscarNotif", hint="Buscar notificaciones...", layout_width="match_parent", padding="8dp", textColor="0xFFFFFFFF"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contNotif", orientation="vertical"}},
{LinearLayout, id="contBotonesNotif", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}
}, views))
d.setOnCancelListener({onCancel = function()
doVibrate(50)
d.dismiss()
actualizarBotonNotifPrincipal()
end})
d.show()
function confirmarEliminarNotificacion(n)
local dConf = registrarVentana(LuaDialog(service))
dConf.setTitle("Atención")
dConf.setCancelable(true)
local vConf = {}
dConf.setView(loadlayout({
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{TextView, text="¿Está seguro de que quiere eliminar esta notificación?", textColor="0xFFFFFFFF", textSize="15sp", padding="8dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content",
{Button, id="btnNo", text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp"},
{Button, id="btnSi", text="Sí", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="16dp"}
}
}, vConf))
dConf.setOnCancelListener({onCancel = function() doVibrate(50) dConf.dismiss() end})
dConf.show()
vConf.btnNo.setOnClickListener({onClick = function() doVibrate(50) dConf.dismiss() end})
vConf.btnSi.setOnClickListener({onClick = function()
doVibrate(50)
dConf.dismiss()
local progDlgElim = mostrarProgreso("Eliminando...")
borrarUnaNotificacion(n.linea, function(ok)
progDlgElim.dismiss()
if ok then
service.asyncSpeak("Notificación eliminada")
cargarNotificaciones()
obtenerMensajeGlobalDeAPISync(function(nuevoMensaje, exito)
if exito then
mensajeGlobal = (nuevoMensaje or ""):match("^%s*(.-)%s*$") or ""
end
d.dismiss()
mostrarInterfazNotificaciones()
end)
else
service.asyncSpeak("Error al eliminar")
end
end)
end})
end
function renderizarNotificaciones(filtro)
views.contNotif.removeAllViews()
filtro = (filtro or ""):lower()
local mostradas = 0
for _, n in ipairs(todas) do
if filtro == "" or n.mensaje:lower():find(filtro, 1, true) then
mostradas = mostradas + 1
local itemLayout = {LinearLayout, orientation="vertical", padding="12dp", backgroundColor="0xFF202125",
{TextView, text=n.mensaje, textColor="0xFFFFFFFF", padding="4dp", textSize="14sp"}
}
local vItem = {}
views.contNotif.addView(loadlayout(itemLayout, vItem))
views.contNotif.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
end
if mostradas == 0 then
views.contNotif.addView(loadlayout({TextView, text=(filtro ~= "" and "Sin resultados" or "Sin notificaciones"), textColor="0xFFFFFFFF"}))
end
if filtro ~= "" then
if mostradas == 0 then service.asyncSpeak("No se encontraron coincidencias") else service.asyncSpeak(mostradas .. " coincidencias encontradas") end
end
end
renderizarNotificaciones("")
views.etBuscarNotif.addTextChangedListener({onTextChanged = function(s) renderizarNotificaciones(s.toString()) end})
actualizarBotonNotifPrincipal()
local contBotones = views.contBotonesNotif
if autorizado and puedeNotificar and not usandoCacheLocal and misComplementosDisponibles then
local vPub = {}
local btnPub = loadlayout({Button, id="btnPub", text="Publicar notificación global", layout_width="match_parent", backgroundColor="0xFFFF9800", textColor="0xFFFFFFFF", padding="16dp"}, vPub)
contBotones.addView(btnPub)
vPub.btnPub.setOnClickListener({onClick = function()
doVibrate(50)
verificarEsperaNotificacion(function()
local dp = registrarVentana(LuaDialog(service))
dp.setTitle("Nueva notificación global")
local vp = {}
dp.setView(loadlayout({
LinearLayout, orientation="vertical", padding="16dp",
{TextView, text="Máximo 200 caracteres. Solo una notificación activa: la nueva reemplaza la anterior. Sin enlaces de grupos o canales. Puedes publicar una nueva cada 6 horas mientras tu notificación siga publicada.", textColor="0xFFAAAAAA", textSize="13sp", padding="4dp"},
{EditText, id="etMsg", hint="Escribe el mensaje (máx. 200)", layout_width="match_parent", padding="12dp", textColor="0xFFFFFFFF", singleLine="true", maxLines="1"},
{Button, id="btnSend", text="Publicar", layout_width="match_parent", padding="12dp", textColor="0xFFFFFFFF", backgroundColor="0xFF4CAF50"},
{Button, id="btnCancelPub", text="Cancelar", layout_width="match_parent", padding="12dp", textColor="0xFFFFFFFF", backgroundColor="0xFF666666"}
}, vp))
dp.show()
pcall(function() limitarCaracteres(vp.etMsg, 200) end)
vp.btnSend.setOnClickListener({onClick = function()
doVibrate(50)
local msg = tostring(vp.etMsg.getText() or "")
msg = msg:match("^%s*(.-)%s*$") or ""
if msg == "" then service.asyncSpeak("Escribe un mensaje") return end
local largoMsg = #msg
pcall(function() largoMsg = String(msg).length() end)
if largoMsg > 200 then service.asyncSpeak("Máximo 200 caracteres") return end
local lower = msg:lower()
if lower:find("http://", 1, true) or lower:find("https://", 1, true) or lower:find("t.me/", 1, true) or lower:find("wa.me/", 1, true) or lower:find("whatsapp", 1, true) or lower:find("telegram", 1, true) or lower:find("chat.whatsapp", 1, true) then
service.asyncSpeak("No se permiten enlaces de grupos o canales")
return
end
dp.dismiss()
subirNotificacionGlobal(msg, function(ok)
if ok then
service.asyncSpeak("Notificación publicada. La anterior quedó reemplazada.")
cargarNotificaciones()
obtenerMensajeGlobalDeAPISync(function(nuevoMensaje, exito)
if exito then
mensajeGlobal = (nuevoMensaje or ""):match("^%s*(.-)%s*$") or ""
end
d.dismiss()
mostrarInterfazNotificaciones()
end)
else
service.asyncSpeak("Error al publicar")
end
end)
end})
vp.btnCancelPub.setOnClickListener({onClick = function()
doVibrate(50)
dp.dismiss()
end})
end)
end})
end
local vVol = {}
local btnVolver = loadlayout({Button, id="btnVol", text="Volver", layout_width="match_parent", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="16dp"}, vVol)
contBotones.addView(btnVolver)
vVol.btnVol.setOnClickListener({onClick = function()
doVibrate(50)
d.dismiss()
actualizarBotonNotifPrincipal()
end})
end
function onKeyDown(code, event)
if code == KeyEvent.KEYCODE_BACK then
doVibrate(50)
if dlgTerminosCritica then
manejarAtrasTerminosCriticos()
return true
end
if dlgConfirmacionActiva then
local aviso = dlgConfirmacionActiva
dlgConfirmacionActiva = nil
pcall(function() aviso.dismiss() end)
return true
end
if dlgErrorConexion and dlgErrorConexion.isShowing() then
dlgErrorConexion.dismiss()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
elseif dlgCreditos and dlgCreditos.isShowing() then dlgCreditos.dismiss()
elseif dlgIns and dlgIns.isShowing() then dlgIns.dismiss()
elseif dlgConfig and dlgConfig.isShowing() then dlgConfig.dismiss()
elseif dlgPrincipal and dlgPrincipal.isShowing() then volverAPantallaUsuarios()
elseif dlgUsuarios and dlgUsuarios.isShowing() then dlgUsuarios.dismiss()
end
return true
end
return false
end
cargarNotificaciones()
progresoSeguridad = mostrarProgreso("Conectando al servidor...")
service.asyncSpeak("Conectando al servidor")
verificarConexionSeguraGoogle(function(seguro)
if progresoSeguridad and progresoSeguridad.isShowing() then progresoSeguridad.dismiss() end
if not seguro then
local bloqueo = registrarVentana(LuaDialog(service))
bloqueo.setTitle("Atención")
bloqueo.setMessage("Ups, ocurrió un error. Inténtalo de nuevo.")
bloqueo.setCancelable(false)
local vBloqueo = {}
bloqueo.setView(loadlayout({LinearLayout, orientation="vertical", padding="16dp",
{Button, id="btnAceptarBloqueo", text="Aceptar", layout_width="match_parent", padding="16dp"}
}, vBloqueo))
vBloqueo.btnAceptarBloqueo.setOnClickListener({onClick=function() doVibrate(50); bloqueo.dismiss() end})
bloqueo.show()
service.asyncSpeak("No se pudo verificar la conexión. Inténtalo de nuevo.")
return
end
verificarActualizaciones(function()
obtenerMensajeGlobalDeAPISync(function(nuevoMensaje, exito)
if exito then
mensajeGlobal = (nuevoMensaje or ""):match("^%s*(.-)%s*$") or ""
end
recargarTodo()
end)
end)
end)
return true