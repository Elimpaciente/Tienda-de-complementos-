require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.Intent"
import "android.net.Uri"
import "android.os.Build"
import "android.content.SharedPreferences"
import "android.content.Context"
import "android.preference.PreferenceManager"
import "com.androlua.LuaDialog"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.io.OutputStreamWriter"
import "java.util.zip.ZipOutputStream"
import "java.util.zip.ZipInputStream"
import "java.util.zip.ZipEntry"
import "android.util.Base64"
import "java.net.URL"
import "java.lang.Thread"
import "java.lang.Runnable"
import "java.lang.reflect.Array"
import "java.lang.StringBuilder"
import "org.json.JSONObject"
import "org.json.JSONArray"
import "java.net.URLEncoder"
import "android.content.SharedPreferences"
local PREFERENCIAS = "tiendadecomplementos"
local CLAVE_PRIMERA_EJECUCION = "primera_ejecucion"
local prefsInicio = service.getSharedPreferences(PREFERENCIAS, 0)
local primeraEjecucion = prefsInicio.getBoolean(CLAVE_PRIMERA_EJECUCION, true)
if primeraEjecucion then
print("La Tienda de complementos, es un nuevo servidor en donde podrás encontrar los plugins oficiales de los desarrolladores más reconocidos de la comunidad.")
print("Esta iniciativa nace con el objetivo de hacer la comunidad más segura y organizada, brindando un espacio donde siempre puedas descargar los complementos originales con total confianza.")
print("Todas las nuevas creaciones y actualizaciones, se publicarán aquí.")
print("Creado por:")
print("• Rudy, el impaciente")
print("• Chuy Bautista")
local editor = prefsInicio.edit()
editor.putBoolean(CLAVE_PRIMERA_EJECUCION, false)
editor.apply()
return true
end
local service = service
local node = service.getEditText()
local vibrator = service.getSystemService(Context.VIBRATOR_SERVICE)
local prefs = PreferenceManager.getDefaultSharedPreferences(service)
local GITHUB_TOKEN = "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"
local GITHUB_OWNER = "Elimpaciente"
local GITHUB_REPO = "Tienda-de-complementos-"
local GITHUB_API = "https://api.github.com/repos/" .. GITHUB_OWNER .. "/" .. GITHUB_REPO
local PROJECT_ID = "tienda-de-complementos"
local FIRESTORE_URL = "https://firestore.googleapis.com/v1/projects/" .. PROJECT_ID .. "/databases/(default)/documents/complementos"
local USUARIOS_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/usuarios.json"
local UPDATES_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/Updates.Txt"
local FECHA_CODIGO = "6/29/2025"
local PLUGIN_NAME = "Tienda de complementos"
local function obtenerIdiomaDispositivo()
local locale = Locale.getDefault()
return { codigo_idioma = locale.getLanguage(), codigo_pais = locale.getCountry() }
end
local infoIdioma = obtenerIdiomaDispositivo()
local function esEspanolEspana()
return infoIdioma.codigo_idioma == "es" and infoIdioma.codigo_pais == "ES"
end
local function obtenerCarpetaComplementos()
if esEspanolEspana() then
return "/storage/emulated/0/解说/Complementos"
else
return "/storage/emulated/0/解说/Plugins"
end
end
local userName = prefs.getString("user_name", "")
local autorizado = false
local complementos = {}
local filtrados = {}
local tokenActual = nil
local usuariosData = {}
local usuariosActivos = {}
local usuarioSeleccionado = nil
local function vibrar(ms)
vibrator.vibrate(ms or 30)
end
local function jsonEscape(s)
s = s or ""
s = s:gsub("\\", "\\\\")
s = s:gsub("\"", "\\\"")
s = s:gsub("\n", "\\n")
s = s:gsub("\r", "")
return s
end
local function ordenarPorReciente(lista)
table.sort(lista, function(a, b)
return a.fecha_actualizacion > b.fecha_actualizacion
end)
end
local function obtenerNombreVisible(username)
for _, u in ipairs(usuariosData) do
if u.username == username then
if u.public_name and u.public_name ~= "" then return u.public_name end
return username
end
end
return username
end
local function contarComplementosPorUsuario(usuario)
local count = 0
for _, c in ipairs(complementos) do
if c.autor == usuario then count = count + 1 end
end
return count
end
local function mostrarErrorGenerico()
local dlg = LuaDialog(service)
dlg.setTitle("Atención")
dlg.setCancelable(false)
dlg.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "16dp",
{TextView, text = "Ups, ocurrió un error. Inténtalo de nuevo.", textSize = "16sp", padding = "8dp"},
{Button, text = "Aceptar", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() dlg.dismiss() end}
}))
dlg.show()
end
local function en_hilo(funcion)
Thread(Runnable {run = funcion}).start()
end
local function http_get(url, headers)
local conn = URL(url).openConnection()
conn.setRequestMethod("GET")
conn.setConnectTimeout(10000)
conn.setReadTimeout(15000)
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream))
local sb = StringBuilder()
local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close()
return code, sb.toString()
end
local function http_send(method, url, body, headers)
local conn = URL(url).openConnection()
conn.setRequestMethod(method)
conn.setDoOutput(true)
conn.setRequestProperty("Content-Type", "application/json")
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
conn.setConnectTimeout(10000)
conn.setReadTimeout(30000)
local writer = OutputStreamWriter(conn.getOutputStream())
writer.write(body) writer.flush() writer.close()
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream))
local sb = StringBuilder()
local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close()
return code, sb.toString()
end
local function http_upload(method, url, filePath, headers)
local file = File(filePath)
local conn = URL(url).openConnection()
conn.setRequestMethod(method)
conn.setDoOutput(true)
conn.setRequestProperty("Content-Type", "application/octet-stream")
conn.setRequestProperty("Content-Length", tostring(file.length()))
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
conn.setConnectTimeout(10000)
conn.setReadTimeout(60000)
local fis = FileInputStream(filePath)
local os = conn.getOutputStream()
local buffer = byte[8192]
local count = fis.read(buffer)
while count ~= -1 do os.write(buffer, 0, count) count = fis.read(buffer) end
fis.close() os.close()
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream))
local sb = StringBuilder()
local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close()
return code, sb.toString()
end
local function obtenerTokenSync()
local ok, code, body = pcall(http_get, "https://prueba-psi-five.vercel.app/token")
if ok and code == 200 then tokenActual = body return tokenActual end
return nil
end
local function authHeaderSync()
if not tokenActual then obtenerTokenSync() end
return {Authorization = "Bearer " .. (tokenActual or "")}
end
local function obtenerRutaDesdePackagePath()
if package.path then
for path in package.path:gmatch("[^;]+") do
local dirPath = path:match("(.*)/[^/]*$")
if dirPath and dirPath ~= "" then
return dirPath
end
end
end
return "/storage/emulated/0"
end
local function fechaATimestamp(fechaStr)
local mes, dia, ano = fechaStr:match("(%d+)/(%d+)/(%d+)")
if mes and dia and ano then
return os.time{year = tonumber(ano), month = tonumber(mes), day = tonumber(dia)}
end
return 0
end
local function esFechaNueva(fechaServer, fechaLocal)
return fechaATimestamp(fechaServer) > fechaATimestamp(fechaLocal)
end
local function parsearActualizacion(contenido)
local lineas = {}
for linea in contenido:gmatch("[^\r\n]+") do
table.insert(lineas, linea)
end
if #lineas < 2 then return nil end
local fecha = lineas[1]:match("^%s*(.-)%s*$")
local cambios = {}
local enlaceZip = nil
for i = 2, #lineas do
local linea = lineas[i]:match("^%s*(.-)%s*$")
if linea:match("https?://") then
enlaceZip = linea
elseif linea ~= "" then
local cambio = linea:gsub("^%-+%s*", ""):gsub("^•%s*", ""):gsub("^%*%s*", ""):gsub("^%d+%.%s*", "")
if cambio ~= "" and #cambio > 3 then
table.insert(cambios, cambio)
end
end
end
return { fecha = fecha, cambios = cambios, enlaceZip = enlaceZip }
end
local function descargarYAplicarActualizacion(enlaceZip, callback)
en_hilo(function()
local rutaComplemento = obtenerRutaDesdePackagePath()
local zipPath = "/storage/emulated/0/Download/" .. os.time() .. ".zip"
local okDescarga = pcall(function()
local conn = URL(enlaceZip).openConnection()
conn.setConnectTimeout(15000)
conn.setReadTimeout(60000)
local stream = conn.getInputStream()
local fos = FileOutputStream(zipPath)
local buffer = byte[4096]
local count = stream.read(buffer)
while count ~= -1 do
fos.write(buffer, 0, count)
count = stream.read(buffer)
end
fos.close()
stream.close()
end)
if not okDescarga then
service.postExecute(0, "x", nil, function()
callback(false, "Error al descargar la actualización")
end)
return
end
local okExtract = pcall(function()
File(rutaComplemento).mkdirs()
local fis = FileInputStream(zipPath)
local zis = ZipInputStream(fis)
local entry = zis.getNextEntry()
while entry ~= nil do
local destFile = File(rutaComplemento .. "/" .. entry.getName())
if entry.isDirectory() then
destFile.mkdirs()
else
destFile.getParentFile().mkdirs()
local fos = FileOutputStream(destFile)
local buffer = byte[4096]
local count = zis.read(buffer)
while count ~= -1 do
fos.write(buffer, 0, count)
count = zis.read(buffer)
end
fos.close()
end
zis.closeEntry()
entry = zis.getNextEntry()
end
zis.close()
fis.close()
end)
pcall(function() File(zipPath).delete() end)
service.postExecute(0, "x", nil, function()
if okExtract then
callback(true, "Actualización aplicada correctamente")
else
callback(false, "Error al descomprimir la actualización")
end
end)
end)
end
local function mostrarDialogoActualizacion(updateInfo, continuar)
local dialog = LuaDialog(service)
dialog.setTitle("Actualización disponible")
dialog.setCancelable(false)
local layout = LinearLayout(service)
layout.setOrientation(LinearLayout.VERTICAL)
layout.setPadding(30, 30, 30, 30)
local tvTitulo = TextView(service)
tvTitulo.setText("Cambios en esta versión:")
tvTitulo.setTextSize(16)
tvTitulo.setPadding(0, 0, 0, 10)
layout.addView(tvTitulo)
local sv = ScrollView(service)
local svParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 300)
sv.setLayoutParams(svParams)
local llCambios = LinearLayout(service)
llCambios.setOrientation(LinearLayout.VERTICAL)
llCambios.setPadding(15, 15, 15, 15)
if updateInfo.cambios and #updateInfo.cambios > 0 then
for _, cambio in ipairs(updateInfo.cambios) do
local tv = TextView(service)
tv.setText("• " .. cambio)
tv.setTextSize(14)
tv.setPadding(0, 5, 0, 5)
llCambios.addView(tv)
end
else
local tv = TextView(service)
tv.setText("Mejoras generales y corrección de errores.")
tv.setTextSize(14)
llCambios.addView(tv)
end
sv.addView(llCambios)
layout.addView(sv)
local btnLayout = LinearLayout(service)
btnLayout.setOrientation(LinearLayout.HORIZONTAL)
btnLayout.setPadding(0, 20, 0, 0)
local btnActualizar = Button(service)
btnActualizar.setText("Actualizar")
btnActualizar.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
btnActualizar.setOnClickListener({onClick = function()
vibrar()
dialog.dismiss()
local progDlg = LuaDialog(service)
progDlg.setTitle("Descargando actualización...")
progDlg.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "24dp", gravity = "center",
{ProgressBar, layout_width = "wrap", layout_height = "wrap"}}))
progDlg.setCancelable(false)
progDlg.show()
descargarYAplicarActualizacion(updateInfo.enlaceZip, function(ok, msg)
progDlg.dismiss()
if ok then
service.asyncSpeak("Actualización completada. Vuelve a abrir el complemento.")
else
service.asyncSpeak(msg)
continuar()
end
end)
end})
local btnMasTarde = Button(service)
btnMasTarde.setText("Más tarde")
btnMasTarde.setLayoutParams(LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1))
btnMasTarde.setOnClickListener({onClick = function()
vibrar()
dialog.dismiss()
continuar()
end})
btnLayout.addView(btnActualizar)
btnLayout.addView(btnMasTarde)
layout.addView(btnLayout)
dialog.setView(layout)
dialog.show()
end
local function verificarActualizaciones(continuar)
Http.get(UPDATES_URL, function(status, data)
if status ~= 200 or not data then
continuar()
return
end
local updateInfo = parsearActualizacion(data)
if updateInfo and esFechaNueva(updateInfo.fecha, FECHA_CODIGO) and updateInfo.enlaceZip then
mostrarDialogoActualizacion(updateInfo, continuar)
else
continuar()
end
end)
end
local function parsearUsuariosJSON(body)
local lista = {}
local okParse, root = pcall(JSONObject, body)
if not okParse then return lista end
if root.has("usuarios") then
local arr = root.getJSONArray("usuarios")
for i = 0, arr.length() - 1 do
local okObj, obj = pcall(function() return arr.getJSONObject(i) end)
if okObj and obj then
local username = obj.has("username") and obj.getString("username") or ""
local public_name = obj.has("public_name") and obj.getString("public_name") or ""
if username ~= "" then table.insert(lista, {username = username, public_name = public_name}) end
else
local okStr, str = pcall(function() return arr.getString(i) end)
if okStr and str ~= "" then table.insert(lista, {username = str, public_name = ""}) end
end
end
end
return lista
end
local function verificarAutorizacionSync()
if userName == "" then return false end
local ok, code, body = pcall(http_get, USUARIOS_URL)
if not ok or code ~= 200 then return false end
for _, u in ipairs(parsearUsuariosJSON(body)) do
if u.username == userName then return true end
end
return false
end
local function extraerZip(zipPath, destDir)
File(destDir).mkdirs()
local fis = FileInputStream(zipPath)
local zis = ZipInputStream(fis)
local entry = zis.getNextEntry()
while entry ~= nil do
local destFile = File(destDir .. "/" .. entry.getName())
if entry.isDirectory() then
destFile.mkdirs()
else
destFile.getParentFile().mkdirs()
local fos = FileOutputStream(destFile)
local buffer = byte[4096]
local count = zis.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = zis.read(buffer) end
fos.close()
end
zis.closeEntry()
entry = zis.getNextEntry()
end
zis.close() fis.close()
end
local function compressFolder(folderPath, zipFilePath)
local fos = FileOutputStream(zipFilePath)
local zos = ZipOutputStream(fos)
local function addToZip(file, basePath)
local filePath = file.getPath()
local relativePath = basePath and filePath:sub(#basePath + 2) or file.getName()
if file.isDirectory() then
local entries = file.listFiles()
if entries then for i = 0, #entries - 1 do addToZip(entries[i], basePath or filePath) end end
else
zos.putNextEntry(ZipEntry(relativePath))
local fis = FileInputStream(file)
local buffer = byte[4096]
local count = fis.read(buffer)
while count ~= -1 do zos.write(buffer, 0, count) count = fis.read(buffer) end
fis.close() zos.closeEntry()
end
end
addToZip(File(folderPath))
zos.close() fos.close()
end
local function docIdDesdeName(name)
return name:match("([^/]+)$")
end
local function campoString(fields, k)
if fields.has(k) then
local c = fields.getJSONObject(k)
if c.has("stringValue") then return c.getString("stringValue") end
end
return ""
end
local function campoEntero(fields, k)
if fields.has(k) then
local c = fields.getJSONObject(k)
if c.has("integerValue") then return tonumber(c.getString("integerValue")) or 0 end
end
return 0
end
local function campoReleaseId(fields)
if fields.has("release_id") then
local c = fields.getJSONObject("release_id")
if c.has("stringValue") then return c.getString("stringValue") end
if c.has("integerValue") then return c.getString("integerValue") end
end
return ""
end
local function firestoreADocumento(doc)
local name = doc.getString("name")
local fields = doc.has("fields") and doc.getJSONObject("fields") or JSONObject()
return {
id = docIdDesdeName(name),
nombre = campoString(fields, "nombre"),
descripcion = campoString(fields, "descripcion"),
autor = campoString(fields, "autor"),
url_github = campoString(fields, "url_github"),
release_id = campoReleaseId(fields),
fecha_actualizacion = campoEntero(fields, "fecha_actualizacion")
}
end
local function cargarComplementosSync()
local headers = authHeaderSync()
local ok, code, body = pcall(http_get, FIRESTORE_URL .. "?pageSize=100", headers)
if not ok or code ~= 200 then return {} end
local okParse, root = pcall(JSONObject, body)
if not okParse then return {} end
local lista = {}
if root.has("documents") then
local arr = root.getJSONArray("documents")
for i = 0, arr.length() - 1 do table.insert(lista, firestoreADocumento(arr.getJSONObject(i))) end
end
return lista
end
local function obtenerUsuariosActivosSync(docsLista)
local ok, code, body = pcall(http_get, USUARIOS_URL)
local repoUsers = {}
if ok and code == 200 then repoUsers = parsearUsuariosJSON(body) usuariosData = repoUsers end
local known = {}
for _, u in ipairs(repoUsers) do known[u.username] = true end
for _, doc in ipairs(docsLista) do
if doc.autor ~= "" and not known[doc.autor] then
table.insert(usuariosData, {username = doc.autor, public_name = ""})
known[doc.autor] = true
end
end
local lista = {}
for _, u in ipairs(usuariosData) do table.insert(lista, u.username) end
table.sort(lista, function(a, b)
if a == userName then return true end
if b == userName then return false end
return obtenerNombreVisible(a):lower() < obtenerNombreVisible(b):lower()
end)
return lista
end
local function mostrarProgreso(mensaje)
local progDlg = LuaDialog(service)
progDlg.setTitle(mensaje)
progDlg.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "24dp", gravity = "center",
{ProgressBar, layout_width = "wrap", layout_height = "wrap"}}))
progDlg.setCancelable(false)
progDlg.show()
return progDlg
end
local function cerrarTodosLosDialogos()
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil end
end
local function volverAPantallaUsuarios()
vibrar()
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
mostrarDialogoUsuarios()
end
local function recargarTodo()
cerrarTodosLosDialogos()
local progDlg = mostrarProgreso("Conectando al servidor...")
en_hilo(function()
local certOk, esLimpio = pcall(function()
local conn = URL("https://firestore.googleapis.com").openConnection()
conn.setConnectTimeout(10000)
conn.connect()
local certs = conn.getServerCertificates()
local len = Array.getLength(certs)
local limpio = false
for i = 0, len - 1 do
if Array.get(certs, i).getIssuerDN().getName():find("Google Trust Services") then
limpio = true break
end
end
conn.disconnect()
return limpio
end)
if not (certOk and esLimpio) then
service.postExecute(0, "x", nil, function() progDlg.dismiss() mostrarErrorGenerico() end)
return
end
autorizado = verificarAutorizacionSync()
local nuevaLista = cargarComplementosSync()
local usuarios = obtenerUsuariosActivosSync(nuevaLista)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
complementos = nuevaLista
usuariosActivos = usuarios
mostrarDialogoUsuarios()
end)
end)
end
local function descargarArchivo(url, destPath)
local conn = URL(url).openConnection()
conn.setConnectTimeout(10000) conn.setReadTimeout(30000)
local stream = conn.getInputStream()
local fos = FileOutputStream(destPath)
local buffer = byte[4096]
local count = stream.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = stream.read(buffer) end
fos.close() stream.close()
end
local function instalarComplemento(complemento)
local progDlg = mostrarProgreso("Descargando complemento...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. complemento.nombre .. ".zip"
local okDownload = pcall(descargarArchivo, complemento.url_github, zipPath)
service.postExecute(0, "x", nil, function()
if okDownload then
progDlg.setTitle("Importando complemento...")
local carpetaDestino = obtenerCarpetaComplementos() .. "/" .. complemento.nombre
if pcall(extraerZip, zipPath, carpetaDestino) then
service.asyncSpeak(complemento.nombre .. " instalado correctamente")
else
service.asyncSpeak("Error al instalar " .. complemento.nombre)
end
pcall(function() File(zipPath).delete() end)
else
service.asyncSpeak("Error al descargar " .. complemento.nombre)
end
progDlg.dismiss()
end)
end)
end
local function confirmarDescarga(complemento)
local d = LuaDialog(service)
d.setTitle("Instalar complemento")
d.setMessage("¿Quieres instalar \"" .. complemento.nombre .. "\"?")
d.setView(loadlayout({LinearLayout, orientation = "horizontal", layout_width = "fill",
{Button, text = "Cancelar", layout_weight = 1, onClick = function() vibrar() d.dismiss() end},
{Button, text = "Instalar", layout_weight = 1, onClick = function() vibrar() d.dismiss() instalarComplemento(complemento) end}
}))
d.show()
end
local function eliminarReleaseGitHub(releaseId, releaseTag)
local headers = {
Authorization = "Bearer " .. GITHUB_TOKEN,
["X-GitHub-Api-Version"] = "2022-11-28"
}
pcall(http_send, "DELETE", GITHUB_API .. "/releases/" .. releaseId, "", headers)
pcall(http_send, "DELETE", GITHUB_API .. "/git/refs/tags/" .. releaseTag, "", headers)
end
local function subirAGitHubRelease(zipPath, nombre)
if not File(zipPath).exists() then return nil end
local releaseTag = "complemento-" .. nombre:gsub("[^a-zA-Z0-9_-]", "")
local headers = {
Authorization = "Bearer " .. GITHUB_TOKEN,
["X-GitHub-Api-Version"] = "2022-11-28"
}
local okGet, codeGet, bodyGet = pcall(http_get, GITHUB_API .. "/releases/tags/" .. releaseTag, headers)
if okGet and codeGet == 200 then
local okP, rj = pcall(JSONObject, bodyGet)
if okP and rj.has("id") then
eliminarReleaseGitHub(tostring(rj.getInt("id")), releaseTag)
end
end
local releaseBody = "{\"tag_name\":\"" .. jsonEscape(releaseTag) .. "\",\"name\":\"" .. jsonEscape(nombre) .. "\",\"body\":\"Complemento: " .. jsonEscape(nombre) .. "\"}"
local ok, code, body = pcall(http_send, "POST", GITHUB_API .. "/releases", releaseBody, headers)
if not ok or code ~= 201 then return nil end
local okP, rj = pcall(JSONObject, body)
if not okP or not rj.has("upload_url") or not rj.has("id") then return nil end
local newReleaseId = tostring(rj.getInt("id"))
local uploadUrl = rj.getString("upload_url"):gsub("{%?name,label}", "") .. "?name=" .. nombre .. ".zip"
local uploadHeaders = {Authorization = "Bearer " .. GITHUB_TOKEN, ["Content-Type"] = "application/zip"}
ok, code, body = pcall(http_upload, "POST", uploadUrl, zipPath, uploadHeaders)
if not ok or code ~= 201 then return nil end
local okA, aj = pcall(JSONObject, body)
if not okA or not aj.has("browser_download_url") then return nil end
return { url = aj.getString("browser_download_url"), release_id = newReleaseId }
end
local function confirmarEliminar(complemento, dlgPadre)
local d = LuaDialog(service)
d.setTitle("Eliminar complemento")
d.setMessage("¿Seguro que quieres eliminar \"" .. complemento.nombre .. "\"? Esto no se puede deshacer.")
d.setView(loadlayout({LinearLayout, orientation = "horizontal", layout_width = "fill",
{Button, text = "Cancelar", layout_weight = 1, onClick = function() vibrar() d.dismiss() end},
{Button, text = "Eliminar", layout_weight = 1, onClick = function()
vibrar() d.dismiss()
if dlgPadre then pcall(function() dlgPadre.dismiss() end) end
local progDlg = mostrarProgreso("Eliminando...")
en_hilo(function()
local headers = authHeaderSync()
local ok, code = pcall(http_send, "DELETE", FIRESTORE_URL .. "/" .. complemento.id, "", headers)
if ok and code == 200 and complemento.release_id and complemento.release_id ~= "" then
local releaseTag = "complemento-" .. complemento.nombre:gsub("[^a-zA-Z0-9_-]", "")
eliminarReleaseGitHub(complemento.release_id, releaseTag)
end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento eliminado")
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
recargarTodo()
else
service.asyncSpeak("Error al eliminar el complemento")
end
end)
end)
end}
}))
d.show()
end
local function obtenerCarpetasComplementosLocales()
local candidatas = {"/storage/emulated/0/解说/Complementos", "/storage/emulated/0/解说/Plugins"}
local validas = {}
for _, c in ipairs(candidatas) do if File(c).exists() then table.insert(validas, c) end end
if #validas == 0 then validas = {candidatas[1]} end
return validas
end
local BASE_DIRS_LOCALES = obtenerCarpetasComplementosLocales()
local function listarComplementosLocales()
local nombres, rutas = {}, {}
for _, baseDir in ipairs(BASE_DIRS_LOCALES) do
local dir = File(baseDir)
if dir.exists() and dir.isDirectory() then
local lista = dir.listFiles()
if lista then
for i = 0, #lista - 1 do
local f = lista[i]
if f.isDirectory() and File(f.getAbsolutePath() .. "/main.lua").exists() then
table.insert(nombres, f.getName())
table.insert(rutas, f.getAbsolutePath())
end
end
end
end
end
return nombres, rutas
end
local function abrirEditor(complemento, dlgPadre)
local rutaEncontrada = nil
local editDlg = LuaDialog(service)
editDlg.setTitle("Editar publicación")
editDlg.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "16dp",
{EditText, id = "etDescEditar", text = complemento.descripcion or "", hint = "Descripción del complemento", layout_width = "fill", layout_height = "wrap"},
{Button, id = "btnBuscarComplemento", text = "Modificar complemento", layout_width = "match_parent", layout_margin = "4dp"},
{Button, text = "Cancelar", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() editDlg.dismiss() end},
{Button, id = "btnAceptarEditor", text = "Aceptar", layout_width = "match_parent", layout_margin = "4dp"}
}))
editDlg.show()
btnBuscarComplemento.setOnClickListener({onClick = function()
vibrar()
local progBuscar = mostrarProgreso("Buscando complemento...")
en_hilo(function()
local nombres, rutas = listarComplementosLocales()
local encontrada = nil
for i, n in ipairs(nombres) do
if n == complemento.nombre then encontrada = rutas[i] break end
end
service.postExecute(0, "x", nil, function()
progBuscar.dismiss()
if encontrada then
rutaEncontrada = encontrada
service.asyncSpeak("Complemento encontrado: " .. complemento.nombre)
else
service.asyncSpeak("Complemento no encontrado localmente")
end
end)
end)
end})
btnAceptarEditor.setOnClickListener({onClick = function()
vibrar()
local nuevaDesc = etDescEditar.getText().toString()
editDlg.dismiss()
if dlgPadre then pcall(function() dlgPadre.dismiss() end) end
if rutaEncontrada then
local progDlg = mostrarProgreso("Subiendo complemento...")
en_hilo(function()
local headers = authHeaderSync()
local zipPath = "/storage/emulated/0/Download/" .. complemento.nombre .. "_upd.zip"
compressFolder(rutaEncontrada, zipPath)
local resultado = subirAGitHubRelease(zipPath, complemento.nombre)
local ok, code
if resultado then
local body = "{\"fields\":{\"descripcion\":{\"stringValue\":\"" .. jsonEscape(nuevaDesc) .. "\"},\"url_github\":{\"stringValue\":\"" .. jsonEscape(resultado.url) .. "\"},\"release_id\":{\"stringValue\":\"" .. resultado.release_id .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"}}}"
local url = FIRESTORE_URL .. "/" .. complemento.id .. "?updateMask.fieldPaths=descripcion&updateMask.fieldPaths=url_github&updateMask.fieldPaths=release_id&updateMask.fieldPaths=fecha_actualizacion"
ok, code = pcall(http_send, "PATCH", url, body, headers)
else
ok = false
end
service.postExecute(2000, "x", nil, function() pcall(function() File(zipPath).delete() end) end)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento actualizado correctamente")
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
recargarTodo()
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
else
local progDlg = mostrarProgreso("Actualizando descripción...")
en_hilo(function()
local headers = authHeaderSync()
local body = "{\"fields\":{\"descripcion\":{\"stringValue\":\"" .. jsonEscape(nuevaDesc) .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"}}}"
local url = FIRESTORE_URL .. "/" .. complemento.id .. "?updateMask.fieldPaths=descripcion&updateMask.fieldPaths=fecha_actualizacion"
local ok, code = pcall(http_send, "PATCH", url, body, headers)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Descripción actualizada correctamente")
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
recargarTodo()
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
end
end})
end
seleccionarComplementoLocalDialog = function(callback)
local nombres, rutas = listarComplementosLocales()
if #nombres == 0 then service.asyncSpeak("No se encontraron complementos locales") return end
local items = {}
for i, n in ipairs(nombres) do table.insert(items, {nombre = n, ruta = rutas[i]}) end
local selDlg = LuaDialog(service)
selDlg.setTitle("Selecciona un complemento")
selDlg.setView(loadlayout({LinearLayout, layout_width = "fill", layout_height = "fill",
backgroundColor = "0xFF000000", orientation = "vertical",
{EditText, id = "searchLocalEditText", hint = "Buscar...", textSize = "16sp", layout_width = "fill", layout_height = "wrap", layout_margin = "8dp"},
{LinearLayout, layout_width = "fill", layout_weight = "1", backgroundColor = "0xFF202125", layout_margin = "8dp",
{ListView, id = "lvComplementosLocales", layout_width = "fill", layout_height = "fill"}},
{Button, text = "Cancelar", layout_width = "fill", layout_margin = "8dp", onClick = function() vibrar() selDlg.dismiss() end}
}))
selDlg.show()
local function refrescarLista(filteredItems)
local textos = {}
for _, item in ipairs(filteredItems) do table.insert(textos, item.nombre) end
lvComplementosLocales.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, textos))
lvComplementosLocales.setOnItemClickListener(AdapterView.OnItemClickListener {
onItemClick = function(parent, view, position, id)
vibrar()
local elegido = filteredItems[position + 1]
selDlg.dismiss()
callback(elegido.nombre, elegido.ruta)
end
})
end
refrescarLista(items)
searchLocalEditText.addTextChangedListener({onTextChanged = function(s, start, before, count)
local query = s.toString():lower()
if query == "" then
refrescarLista(items)
else
local resultado = {}
for _, item in ipairs(items) do
if item.nombre:lower():find(query, 1, true) then table.insert(resultado, item) end
end
refrescarLista(resultado)
if #resultado == 0 then service.asyncSpeak("Sin resultados")
elseif #resultado == 1 then service.asyncSpeak("1 resultado encontrado")
else service.asyncSpeak(#resultado .. " resultados encontrados") end
end
end})
end
local function buscar(query)
query = query:lower()
filtrados = {}
for _, c in ipairs(complementos) do
if c.autor == usuarioSeleccionado then
if query == "" or c.nombre:lower():find(query, 1, true) or (c.descripcion or ""):lower():find(query, 1, true) then
table.insert(filtrados, c)
end
end
end
ordenarPorReciente(filtrados)
actualizarListaUI()
if query ~= "" then
if #filtrados == 0 then service.asyncSpeak("Sin resultados")
elseif #filtrados == 1 then service.asyncSpeak("1 resultado encontrado")
else service.asyncSpeak(#filtrados .. " resultados encontrados") end
end
end
local function construirTarjetaComplemento(complemento)
local tarjeta = {LinearLayout, orientation = "vertical", backgroundColor = "0xFF202125", padding = "12dp",
{TextView, text = complemento.nombre, textSize = "18sp"},
{TextView, text = "Autor: " .. (complemento.autor or ""), textSize = "14sp", padding = "4dp"},
{TextView, text = complemento.descripcion or "", textSize = "14sp", padding = "4dp"}
}
if autorizado and complemento.autor == userName then
table.insert(tarjeta, {Button, text = "Editar publicación", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() abrirEditor(complemento, nil) end})
table.insert(tarjeta, {Button, text = "Eliminar", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() confirmarEliminar(complemento, nil) end})
end
table.insert(tarjeta, {Button, text = "Instalar", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() confirmarDescarga(complemento) end})
return tarjeta
end
actualizarListaUI = function()
contenedorComplementos.removeAllViews()
if #filtrados == 0 then
contenedorComplementos.addView(loadlayout({TextView, text = "No hay complementos disponibles", textSize = "16sp", padding = "16dp", gravity = "center"}))
else
for _, c in ipairs(filtrados) do
contenedorComplementos.addView(loadlayout(construirTarjetaComplemento(c)))
contenedorComplementos.addView(loadlayout({LinearLayout, layout_width = "fill", layout_height = "8dp"}))
end
end
local nombreVisible = usuarioSeleccionado and obtenerNombreVisible(usuarioSeleccionado) or ""
local count = usuarioSeleccionado and contarComplementosPorUsuario(usuarioSeleccionado) or 0
tvTitulo.setText(nombreVisible .. "\n(" .. count .. " complementos)")
if btnSubirComplemento then
btnSubirComplemento.setVisibility((autorizado and usuarioSeleccionado == userName) and View.VISIBLE or View.GONE)
end
end
local function abrirSubirComplemento()
local rutaSeleccionada, nombreSeleccionado = nil, nil
local subirDlg = LuaDialog(service)
subirDlg.setTitle("Subir Complemento")
subirDlg.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "16dp",
{EditText, id = "etDescripcionSubir", hint = "Descripción del complemento", layout_width = "fill", layout_height = "80dp", gravity = "left|top", inputType = "textMultiLine"},
{Button, id = "btnElegirArchivo", text = "Elegir complemento", layout_width = "match_parent", layout_margin = "4dp"},
{TextView, id = "tvNombreElegido", text = "", textSize = "16sp", padding = "8dp", visibility = "gone"},
{Button, id = "btnQuitarSeleccion", text = "Quitar selección", layout_width = "match_parent", layout_margin = "4dp", visibility = "gone"},
{Button, text = "Cancelar", layout_width = "match_parent", layout_margin = "4dp", onClick = function() vibrar() subirDlg.dismiss() end},
{Button, id = "btnAceptarSubir", text = "Aceptar", layout_width = "match_parent", layout_margin = "4dp"}
}))
subirDlg.show()
btnElegirArchivo.setOnClickListener({onClick = function()
vibrar()
seleccionarComplementoLocalDialog(function(nombreElegido, path)
rutaSeleccionada = path nombreSeleccionado = nombreElegido
tvNombreElegido.setText(nombreElegido) tvNombreElegido.setVisibility(View.VISIBLE)
btnQuitarSeleccion.setVisibility(View.VISIBLE) btnElegirArchivo.setVisibility(View.GONE)
service.asyncSpeak("Complemento seleccionado: " .. nombreElegido)
end)
end})
btnQuitarSeleccion.setOnClickListener({onClick = function()
vibrar() rutaSeleccionada = nil nombreSeleccionado = nil
tvNombreElegido.setVisibility(View.GONE) btnQuitarSeleccion.setVisibility(View.GONE)
btnElegirArchivo.setVisibility(View.VISIBLE)
end})
btnAceptarSubir.setOnClickListener({onClick = function()
vibrar()
if not rutaSeleccionada then service.asyncSpeak("Selecciona un complemento primero") return end
local descripcionTexto = etDescripcionSubir.getText().toString()
subirDlg.dismiss()
local progDlg = mostrarProgreso("Subiendo complemento...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. nombreSeleccionado .. ".zip"
compressFolder(rutaSeleccionada, zipPath)
local resultado = subirAGitHubRelease(zipPath, nombreSeleccionado)
if resultado then
local headers = authHeaderSync()
local body = "{\"fields\":{\"nombre\":{\"stringValue\":\"" .. jsonEscape(nombreSeleccionado) .. "\"},\"descripcion\":{\"stringValue\":\"" .. jsonEscape(descripcionTexto) .. "\"},\"autor\":{\"stringValue\":\"" .. jsonEscape(userName) .. "\"},\"url_github\":{\"stringValue\":\"" .. jsonEscape(resultado.url) .. "\"},\"release_id\":{\"stringValue\":\"" .. resultado.release_id .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"}}}"
local ok, code = pcall(http_send, "POST", FIRESTORE_URL, body, headers)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento subido correctamente")
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) dlgPrincipal = nil end
recargarTodo()
else
service.asyncSpeak("Error al guardar en base de datos")
end
end)
else
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
service.asyncSpeak("Error al subir el complemento")
end)
end
service.postExecute(2000, "x", nil, function() pcall(function() File(zipPath).delete() end) end)
end)
end})
end
construirInterfazPrincipal = function()
dlgPrincipal = LuaDialog(service)
dlgPrincipal.View = loadlayout({LinearLayout, layout_width = "fill", layout_height = "fill",
backgroundColor = "0xFF000000", orientation = "vertical",
{TextView, id = "tvTitulo", text = "", textSize = "20sp", gravity = "center", layout_width = "fill", padding = "16dp"},
{Button, text = "Navegar hacia atrás", layout_width = "fill", layout_margin = "8dp", onClick = function() volverAPantallaUsuarios() end},
{Button, id = "btnSubirComplemento", text = "Subir Complemento", layout_width = "fill", layout_margin = "8dp", visibility = "gone"},
{EditText, id = "searchEditText", hint = "Buscar...", textSize = "18sp", layout_width = "fill", layout_height = "wrap"},
{ScrollView, layout_width = "fill", layout_weight = "1",
{LinearLayout, id = "contenedorComplementos", layout_width = "fill", layout_height = "wrap", orientation = "vertical"}},
{Button, text = "Cerrar", layout_width = "fill", layout_margin = "8dp", onClick = function() vibrar() dlgPrincipal.dismiss() end}
})
dlgPrincipal.setCancelable(true)
dlgPrincipal.setOnCancelListener({onCancel = function() volverAPantallaUsuarios() end})
dlgPrincipal.show()
btnSubirComplemento.setOnClickListener({onClick = function() vibrar() abrirSubirComplemento() end})
searchEditText.addTextChangedListener({onTextChanged = function(s, start, before, count) buscar(s.toString()) end})
local nombreVisible = usuarioSeleccionado and obtenerNombreVisible(usuarioSeleccionado) or ""
local count = usuarioSeleccionado and contarComplementosPorUsuario(usuarioSeleccionado) or 0
tvTitulo.setText(nombreVisible .. "\n(" .. count .. " complementos)")
service.asyncSpeak(nombreVisible)
end
mostrarDialogoUsuarios = function()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
dlgUsuarios = LuaDialog(service)
dlgUsuarios.setTitle("Tienda de complementos")
dlgUsuarios.setCancelable(true)
dlgUsuarios.setOnCancelListener({onCancel = function()
vibrar() pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil
end})
dlgUsuarios.setView(loadlayout({LinearLayout, orientation = "vertical", padding = "16dp",
{TextView, text = "Selecciona un usuario:", textSize = "16sp", gravity = "center", padding = "8dp"},
{ScrollView, layout_width = "fill", layout_height = "wrap",
{LinearLayout, id = "contenedorUsuarios", layout_width = "fill", layout_height = "wrap", orientation = "vertical"}},
{Button, text = "Cerrar", layout_width = "fill", layout_margin = "8dp", onClick = function()
vibrar() dlgUsuarios.dismiss() dlgUsuarios = nil
end}
}))
dlgUsuarios.show()
contenedorUsuarios.removeAllViews()
if #usuariosActivos == 0 then
contenedorUsuarios.addView(loadlayout({TextView, text = "No hay usuarios disponibles", textSize = "16sp", padding = "16dp", gravity = "center"}))
else
for _, usuario in ipairs(usuariosActivos) do
local count = contarComplementosPorUsuario(usuario)
local etiqueta = (usuario == userName) and ("Mis complementos (" .. count .. ")") or (obtenerNombreVisible(usuario) .. " (" .. count .. ")")
local btn = Button(service)
btn.setText(etiqueta)
btn.setLayoutParams(LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
btn.setTextSize(18)
btn.setPadding(16, 16, 16, 16)
btn.setOnClickListener({onClick = function()
vibrar()
usuarioSeleccionado = usuario
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil end
filtrados = {}
for _, c in ipairs(complementos) do
if c.autor == usuario then table.insert(filtrados, c) end
end
ordenarPorReciente(filtrados)
construirInterfazPrincipal()
actualizarListaUI()
end})
contenedorUsuarios.addView(btn)
contenedorUsuarios.addView(loadlayout({LinearLayout, layout_width = "fill", layout_height = "4dp"}))
end
end
end
verificarActualizaciones(function()
recargarTodo()
end)
return true