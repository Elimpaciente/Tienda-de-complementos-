if dlg and dlg.isShowing() then
dlg.dismiss()
end
require "import"
import "android.widget.*"
import "android.view.*"
import "android.content.Intent"
import "android.net.Uri"
import "android.os.Build"
import "android.os.Handler"
import "android.os.VibrationEffect"
import "android.content.SharedPreferences"
import "android.content.Context"
import "android.preference.PreferenceManager"
import "com.androlua.LuaDialog"
import "java.io.File"
import "java.io.FileOutputStream"
import "java.io.FileInputStream"
import "java.io.BufferedReader"
import "java.io.InputStreamReader"
import "java.io.OutputStreamWriter"
import "java.util.zip.ZipOutputStream"
import "java.util.zip.ZipInputStream"
import "java.util.zip.ZipEntry"
import "android.util.Base64"
import "java.net.URL"
import "java.lang.Thread"
import "java.lang.Runnable"
import "java.lang.reflect.Array"
import "java.lang.StringBuilder"
import "org.json.JSONObject"
import "org.json.JSONArray"
import "java.net.URLEncoder"
import "android.view.inputmethod.InputMethodManager"
import "android.view.Gravity"
import "android.view.KeyEvent"
import "java.util.Locale"
local PREFERENCIAS = "tiendadecomplementos15"
local CLAVE_PRIMERA_EJECUCION = "primera_ejecucion_v3.3"
local prefsInicio = service.getSharedPreferences(PREFERENCIAS, 0)
local primeraEjecucion = prefsInicio.getBoolean(CLAVE_PRIMERA_EJECUCION, true)
local mostrarCreditosFlag = false
local service = service
local node = service.getEditText()
local vibrator = service.getSystemService(Context.VIBRATOR_SERVICE)
local prefs = PreferenceManager.getDefaultSharedPreferences(service)
local handler = Handler()
local vibrationEnabled = prefs.getBoolean("vibrationEnabled", true)
local vibrationIntensity = prefs.getInt("vibrationIntensity", 50)
local pedirConfirmacion = prefs.getBoolean("pedirConfirmacion", true)
local modoCompacto = prefs.getBoolean("modoCompacto", true)
local function doVibrate(duration)
if vibrationEnabled then
local intensityMultiplier = vibrationIntensity / 100
local finalDuration = math.max(10, duration * (0.5 + intensityMultiplier * 2.5))
if Build.VERSION.SDK_INT >= 26 then
local amplitude = math.max(50, math.floor(255 * intensityMultiplier))
if intensityMultiplier == 0 then amplitude = 50 end
local effect = VibrationEffect.createOneShot(math.floor(finalDuration), amplitude)
vibrator.vibrate(effect)
else
vibrator.vibrate(math.floor(finalDuration))
end
end
end
local dlgPrincipal, dlgUsuarios, dlgConfig, dlgCreditos, dlgIns, dlgErrorConexion
local btnNotifPrincipalRef = nil
local creditosText = [[
La Tienda de complementos es un nuevo servidor en donde podrás encontrar los plugins oficiales de los desarrolladores más reconocidos de la comunidad.
Esta iniciativa nace con el objetivo de hacer la comunidad más segura y organizada, brindando un espacio donde siempre puedas descargar los complementos originales con total confianza.
Todas las nuevas creaciones y actualizaciones se publicarán aquí.
Creado por:
• Rudy, el impaciente
• Chuy Bautista
• Emmanuel Cruz
• Carlos Cázares
]]
local instruccionesText = [[
INTERFAZ PRINCIPAL (PANTALLA DE INICIO)
1. Botón de Notificaciones:
• Aquí llegarán mensajes urgentes o importantes sobre la tienda en general.
2. Botón de Configuraciones:
• Vibración
Si lo activas, el teléfono vibrará cuando toques cualquier botón.
Si lo desactivas, no vibrará nada.
• Barra de intensidad
Mueve la barra de progreso hacia la derecha o izquierda, para que la vibración sea más fuerte o muy suave.
• Modo compacto
Si lo activas: El nombre, la descripción, y el botón de instalar se juntarán todo en un solo texto. Y si tocas ese texto, se realizará la instalación directamente.
Si lo desactiva: El nombre, la descripción, y el botón de instalar aparecerán de forma individual.
• Pedir confirmación
Si lo activas, antes de instalar algo se te preguntará: ¿Quieres instalar?
Si lo desactivas, se instalará directamente.
3. Lista de creadores:
• Después del botón de Configuraciones, verás una lista con los nombres o marcas de los creadores (por ejemplo: Mi Android Accesible, Tutoriales para ciegos, etc). Al dar clic en alguno de ellos, encontrarás todos los complementos disponibles de dicho usuario.
]]
local function mostrarCreditos()
doVibrate(50)
local creditosParagraphs = {}
for paragraph in creditosText:gmatch("[^\n]+") do
if paragraph:match("%S") then
table.insert(creditosParagraphs, paragraph)
end
end
local creditosLayout = {
LinearLayout,
orientation = "vertical",
layout_width = "fill",
layout_height = "fill",
padding = "20dp",
backgroundColor = 0xFF000000,
{
TextView,
text = "BIENVENIDOS A LA TIENDA DE COMPLEMENTOS",
layout_width = "wrap_content",
layout_height = "wrap_content",
textSize = "20sp",
textColor = 0xFF00FF00,
gravity = "center",
layout_marginBottom = "20dp",
layout_gravity = "center_horizontal"
},
{
ScrollView,
layout_width = "match_parent",
layout_height = "300dp",
layout_marginBottom = "20dp",
{
LinearLayout,
id = "creditosContainer",
orientation = "vertical",
layout_width = "match_parent",
layout_height = "wrap_content",
padding = "8dp"
}
},
{
Button,
id = "creditosOkButton",
text = "Entendido",
layout_width = "200dp",
layout_height = "wrap_content",
backgroundColor = 0xFF4CAF50,
textColor = 0xFFFFFFFF,
layout_gravity = "center_horizontal"
}
}
dlgCreditos = LuaDialog(service)
dlgCreditos.setTitle("Créditos")
local views = {}
local dialogView = loadlayout(creditosLayout, views)
for i, paragraph in ipairs(creditosParagraphs) do
local paragraphView = TextView(service)
paragraphView.setText(paragraph)
paragraphView.setTextColor(0xFFFFFFFF)
paragraphView.setTextSize(14)
paragraphView.setPadding(12, 8, 12, 8)
paragraphView.setBackgroundColor(0xFF333333)
local layoutParams = LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
)
layoutParams.setMargins(0, 0, 0, 2)
paragraphView.setLayoutParams(layoutParams)
views.creditosContainer.addView(paragraphView)
end
dlgCreditos.setView(dialogView)
dlgCreditos.setCancelable(true)
dlgCreditos.setOnCancelListener({onCancel = function() doVibrate(50) dlgCreditos.dismiss() end})
views.creditosOkButton.onClick = function()
doVibrate(50)
service.asyncSpeak("Cerrado")
dlgCreditos.dismiss()
end
dlgCreditos.show()
service.asyncSpeak("Mostrando créditos")
end
if primeraEjecucion then
mostrarCreditosFlag = true
local editor = prefsInicio.edit()
editor.putBoolean(CLAVE_PRIMERA_EJECUCION, false)
editor.apply()
end
local OPCION_ORDEN = "opcion_orden"
local ORDEN_ALFABETICO_AZ = "alfabetico_az"
local ORDEN_ALFABETICO_ZA = "alfabetico_za"
local ORDEN_FECHA_NUEVO = "fecha_nuevo"
local ORDEN_FECHA_VIEJO = "fecha_viejo"
local ORDEN_POPULARIDAD = "popularidad"
local ordenActual = prefs.getString(OPCION_ORDEN, ORDEN_FECHA_NUEVO)
local GITHUB_TOKEN = "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"
local GITHUB_OWNER = "Elimpaciente"
local GITHUB_REPO = "Tienda-de-complementos-"
local GITHUB_API = "https://api.github.com/repos/" .. GITHUB_OWNER .. "/" .. GITHUB_REPO
local PROJECT_ID = "tienda-de-complementos"
local FIRESTORE_URL = "https://firestore.googleapis.com/v1/projects/" .. PROJECT_ID .. "/databases/(default)/documents/complementos"
local FIRESTORE_COMMIT_URL = "https://firestore.googleapis.com/v1/projects/" .. PROJECT_ID .. "/databases/(default)/documents:commit"
local USUARIOS_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/usuarios.json"
local UPDATES_URL = "https://raw.githubusercontent.com/Elimpaciente/Rudyy1224/main/Updates.Txt"
local MSG_URL = "https://raw.githubusercontent.com/Elimpaciente/Tienda-de-complementos-/main/msg.txt"
local FECHA_CODIGO = "7/24/2026"
local currentVersion = "0.0"
local VERSION_TIENDA = currentVersion
local mensajeGlobal = ""
local NOTIFICACIONES_PREFS = "notificaciones_prefs"
local notificacionesLeidas = {}
local complementos = {}
local filtrados = {}
local tokenActual = nil
local usuariosData = {}
local usuariosActivos = {}
local usuarioSeleccionado = nil
local anunciosUsuario = {}
local userName = prefs.getString("user_name", "")
local autorizado = false
local function obtenerIdiomaDispositivo()
local locale = Locale.getDefault()
return { codigo_idioma = locale.getLanguage(), codigo_pais = locale.getCountry() }
end
local infoIdioma = obtenerIdiomaDispositivo()
local function esEspanolEspana()
return infoIdioma.codigo_idioma == "es" and infoIdioma.codigo_pais == "ES"
end
local function obtenerCarpetaComplementos()
if esEspanolEspana() then
return "/storage/emulated/0/解说/Complementos"
else
return "/storage/emulated/0/解说/Plugins"
end
end
local function obtenerCarpetasComplementosLocales()
local candidatas = {"/storage/emulated/0/解说/Complementos", "/storage/emulated/0/解说/Plugins"}
local validas = {}
for _, c in ipairs(candidatas) do
if File(c).exists() then table.insert(validas, c) end
end
if #validas == 0 then validas = {candidatas[1]} end
return validas
end
local BASE_DIRS_LOCALES = obtenerCarpetasComplementosLocales()
local function jsonEscape(s)
s = s or ""
s = s:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n"):gsub("\r", "")
return s
end
local function obtenerNombreVisible(username)
if not username then return "" end
for _, u in ipairs(usuariosData) do
if u.username == username then return (u.public_name and u.public_name ~= "") and u.public_name or username end
end return username
end
local function obtenerNombrePublicoParaGuardar(username)
if not username then return nil end
for _, u in ipairs(usuariosData) do
if u.username == username then return (u.public_name and u.public_name ~= "") and u.public_name or nil end
end return nil
end
local function contarComplementosPorUsuario(usuario)
if not usuario then return 0 end
local pub = obtenerNombrePublicoParaGuardar(usuario) or usuario
local count = 0
for _, c in ipairs(complementos) do if c.autor == pub then count = count + 1 end end
return count
end
local function en_hilo(funcion) Thread(Runnable {run = funcion}).start() end
local function http_get(url, headers)
local conn = URL(url).openConnection()
conn.setRequestMethod("GET") conn.setConnectTimeout(10000) conn.setReadTimeout(15000)
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream)) local sb = StringBuilder() local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close() return code, sb.toString()
end
local function http_send(method, url, body, headers)
local conn = URL(url).openConnection() conn.setRequestMethod(method) conn.setDoOutput(true)
conn.setRequestProperty("Content-Type", "application/json")
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local writer = OutputStreamWriter(conn.getOutputStream()) writer.write(body) writer.flush() writer.close()
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream)) local sb = StringBuilder() local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close() return code, sb.toString()
end
local function http_upload(method, url, filePath, headers)
local file = File(filePath) local conn = URL(url).openConnection()
conn.setRequestMethod(method) conn.setDoOutput(true) conn.setRequestProperty("Content-Type", "application/octet-stream")
if headers then for k, v in pairs(headers) do conn.setRequestProperty(k, v) end end
local fis = FileInputStream(filePath) local os = conn.getOutputStream() local buffer = byte[8192] local count = fis.read(buffer)
while count ~= -1 do os.write(buffer, 0, count) count = fis.read(buffer) end
fis.close() os.close()
local code = conn.getResponseCode()
local stream = (code >= 200 and code < 300) and conn.getInputStream() or conn.getErrorStream()
local reader = BufferedReader(InputStreamReader(stream)) local sb = StringBuilder() local line = reader.readLine()
while line ~= nil do sb.append(line) line = reader.readLine() end
reader.close() return code, sb.toString()
end
local function hayConexionInternet()
local cm = service.getSystemService(Context.CONNECTIVITY_SERVICE)
if not cm then return false end
local activeNetwork = cm.getActiveNetworkInfo()
return activeNetwork ~= nil and activeNetwork.isConnected()
end
local function obtenerTokenSync()
if tokenActual then return tokenActual end
local prefsToken = service.getSharedPreferences("token_cache", Context.MODE_PRIVATE)
local savedToken = prefsToken.getString("firestore_token", "")
local savedTime = prefsToken.getLong("token_time", 0)
local currentTime = os.time()
if savedToken ~= "" and (currentTime - savedTime) < 3000 then
tokenActual = savedToken
return tokenActual
end
local ok, code, body = pcall(http_get, "https://prueba-psi-five.vercel.app/token")
if ok and code == 200 then
tokenActual = body
local editor = prefsToken.edit()
editor.putString("firestore_token", tokenActual)
editor.putLong("token_time", currentTime)
editor.apply()
return tokenActual
end
return nil
end
local function authHeaderSync()
if not tokenActual then obtenerTokenSync() end
return {Authorization = "Bearer " .. (tokenActual or "")}
end
local function obtenerRutaDesdePackagePath()
if package.path then for path in package.path:gmatch("[^;]+") do
local dirPath = path:match("(.*)/[^/]*$") if dirPath and dirPath ~= "" then return dirPath end
end end return "/storage/emulated/0"
end
local function fechaATimestamp(fechaStr)
local mes, dia, ano = fechaStr:match("(%d+)/(%d+)/(%d+)")
if mes and dia and ano then return os.time{year=tonumber(ano), month=tonumber(mes), day=tonumber(dia)} end return 0
end
local function esFechaNueva(fechaServer, fechaLocal) return fechaATimestamp(fechaServer) > fechaATimestamp(fechaLocal) end
local function extraerVersionYNotas(contenido)
local version = nil
local notas = {}
local bloque = contenido:match("%-%-%[%[(.-)%]%]")
if bloque then
local primeraLinea = true
for linea in bloque:gmatch("[^\r\n]+") do
local limpio = linea:match("^%s*(.-)%s*$")
if limpio ~= "" then
if primeraLinea then
version = limpio:match("(%d+%.%d+)")
primeraLinea = false
else
table.insert(notas, limpio)
end
end
end
end
if not version then
version = contenido:match("(%d+%.%d+)")
end
return version, notas
end
local function compararVersiones(versionActual, versionRemota)
if not versionRemota or versionRemota == "" then return "igual" end
local function parseVersion(v)
local major, minor = v:match("(%d+)%.(%d+)")
return tonumber(major) or 0, tonumber(minor) or 0
end
local actualMajor, actualMinor = parseVersion(versionActual)
local remotaMajor, remotaMinor = parseVersion(versionRemota)
if remotaMajor > actualMajor or (remotaMajor == actualMajor and remotaMinor > actualMinor) then
return "mayor"
elseif remotaMajor < actualMajor or (remotaMajor == actualMajor and remotaMinor < actualMinor) then
return "menor"
end
return "igual"
end
local function parsearActualizacion(contenido)
local lineas = {} for linea in contenido:gmatch("[^\r\n]+") do table.insert(lineas, linea) end
if #lineas < 2 then return nil end
local fecha = lineas[1]:match("^%s*(.-)%s*$") local cambios = {} local enlaceZip = nil
for i = 2, #lineas do
local linea = lineas[i]:match("^%s*(.-)%s*$")
if linea:match("https?://") then enlaceZip = linea
elseif linea ~= "" then local cambio = linea:gsub("^%-+%s*", ""):gsub("^•%s*", "")
if cambio ~= "" and #cambio > 3 then table.insert(cambios, cambio) end end
end return { fecha=fecha, cambios=cambios, enlaceZip=enlaceZip }
end
local function descargarYAplicarActualizacion(enlaceZip, callback)
en_hilo(function()
local rutaComplemento = obtenerRutaDesdePackagePath()
local zipPath = "/storage/emulated/0/Download/" .. os.time() .. ".zip"
pcall(function()
local conn = URL(enlaceZip).openConnection() conn.setConnectTimeout(15000) conn.setReadTimeout(60000)
local stream = conn.getInputStream() local fos = FileOutputStream(zipPath) local buffer = byte[4096] local count = stream.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = stream.read(buffer) end fos.close() stream.close()
end)
local okExtract = pcall(function()
File(rutaComplemento).mkdirs() local fis = FileInputStream(zipPath) local zis = ZipInputStream(fis) local entry = zis.getNextEntry()
while entry ~= nil do local destFile = File(rutaComplemento .. "/" .. entry.getName())
if entry.isDirectory() then destFile.mkdirs()
else destFile.getParentFile().mkdirs() local fos = FileOutputStream(destFile) local buffer = byte[4096] local count = zis.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = zis.read(buffer) end fos.close() end
zis.closeEntry() entry = zis.getNextEntry()
end zis.close() fis.close()
end)
pcall(function() File(zipPath).delete() end)
service.postExecute(0, "x", nil, function()
if okExtract then callback(true, "Actualización aplicada correctamente") else callback(false, "Error al descomprimir") end
end)
end)
end
local function mostrarDialogoActualizacion(info, continuar)
local dialog = LuaDialog(service)
dialog.setTitle(info.estado == "menor" and "Regresión necesaria" or "Actualización disponible")
dialog.setCancelable(false)
local tituloTexto = "Versión actual: " .. VERSION_TIENDA .. "\nVersión remota: " .. info.version
if info.estado == "menor" then
tituloTexto = tituloTexto .. "\n\nMotivo: La versión actual podría estar dañada. Es necesario regresar a una versión anterior estable."
end
local notasTexto = #info.notas > 0 and "• "..table.concat(info.notas, "\n• ") or "Mejoras generales."
local layout = {
LinearLayout, orientation="vertical", padding="30dp",
{TextView, text=tituloTexto, textSize="16sp", paddingBottom="10dp"},
{ScrollView, layout_width="match", layout_height="300", {LinearLayout, orientation="vertical", padding="15",
{TextView, text=notasTexto, textSize="14sp"}
}},
{LinearLayout, orientation="horizontal", paddingTop="20dp",
{Button, text="Actualizar", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50) dialog.dismiss()
local progDlg = LuaDialog(service) progDlg.setTitle("Descargando...") progDlg.setCancelable(false)
progDlg.setView(loadlayout({LinearLayout, padding="24dp", gravity="center", {ProgressBar}})) progDlg.show()
descargarYAplicarActualizacion(info.enlaceZip, function(ok, msg)
progDlg.dismiss()
if ok then service.asyncSpeak("Actualización completada. Reabre el complemento.") else service.asyncSpeak(msg) continuar() end
end)
end},
{Button, text="Más tarde", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) dialog.dismiss() continuar() end}
}
}
dialog.setView(loadlayout(layout)) dialog.show()
end
local function verificarActualizaciones(continuar)
Http.get(UPDATES_URL, function(status, data)
if status ~= 200 or not data then continuar() return end
local versionRemota, notas = extraerVersionYNotas(data)
if versionRemota and versionRemota ~= "" then
local estado = compararVersiones(VERSION_TIENDA, versionRemota)
if estado ~= "igual" then
local tempInfo = parsearActualizacion(data)
local zipUrl = tempInfo and tempInfo.enlaceZip or nil
if zipUrl then
mostrarDialogoActualizacion({version=versionRemota, notas=notas, enlaceZip=zipUrl, estado=estado}, continuar)
return
end
end
continuar()
return
end
local updateInfo = parsearActualizacion(data)
if updateInfo and esFechaNueva(updateInfo.fecha, FECHA_CODIGO) and updateInfo.enlaceZip then
local notasFecha = #updateInfo.cambios > 0 and updateInfo.cambios or {}
mostrarDialogoActualizacion({version="desconocida", notas=notasFecha, enlaceZip=updateInfo.enlaceZip, estado="mayor"}, continuar)
else continuar() end
end)
end
local function parsearUsuariosJSON(body)
local lista = {} local ok, root = pcall(JSONObject, body) if not ok then return lista end
if root.has("usuarios") then local arr = root.getJSONArray("usuarios")
for i = 0, arr.length() - 1 do
local okObj, obj = pcall(function() return arr.getJSONObject(i) end)
if okObj and obj then local u = obj.has("username") and obj.getString("username") or "" local p = obj.has("public_name") and obj.getString("public_name") or ""
if u ~= "" then table.insert(lista, {username=u, public_name=p}) end
else local okStr, str = pcall(function() return arr.getString(i) end)
if okStr and str ~= "" then table.insert(lista, {username=str, public_name=""}) end end
end end return lista
end
local function extraerZip(zipPath, destDir)
File(destDir).mkdirs() local fis = FileInputStream(zipPath) local zis = ZipInputStream(fis) local entry = zis.getNextEntry()
while entry ~= nil do local destFile = File(destDir .. "/" .. entry.getName())
if entry.isDirectory() then destFile.mkdirs()
else destFile.getParentFile().mkdirs() local fos = FileOutputStream(destFile) local buffer = byte[4096] local count = zis.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = zis.read(buffer) end fos.close() end
zis.closeEntry() entry = zis.getNextEntry()
end zis.close() fis.close()
end
local function compressFolder(folderPath, zipFilePath)
local fos = FileOutputStream(zipFilePath) local zos = ZipOutputStream(fos)
local function addToZip(file, basePath)
local filePath = file.getPath() local relativePath = basePath and filePath:sub(#basePath + 2) or file.getName()
if file.isDirectory() then local entries = file.listFiles() if entries then for i = 0, #entries - 1 do addToZip(entries[i], basePath or filePath) end end
else zos.putNextEntry(ZipEntry(relativePath)) local fis = FileInputStream(file) local buffer = byte[4096] local count = fis.read(buffer)
while count ~= -1 do zos.write(buffer, 0, count) count = fis.read(buffer) end fis.close() zos.closeEntry() end
end addToZip(File(folderPath)) zos.close() fos.close()
end
local function docIdDesdeName(name) return name:match("([^/]+)$") end
local function campoString(fields, k) if fields.has(k) then local c = fields.getJSONObject(k) if c.has("stringValue") then return c.getString("stringValue") end end return "" end
local function campoEntero(fields, k) if fields.has(k) then local c = fields.getJSONObject(k) if c.has("integerValue") then return tonumber(c.getString("integerValue")) or 0 end end return 0 end
local function campoReleaseId(fields) if fields.has("release_id") then local c = fields.getJSONObject("release_id") if c.has("stringValue") then return c.getString("stringValue") end if c.has("integerValue") then return c.getString("integerValue") end end return "" end
local function firestoreADocumento(doc)
local fields = doc.has("fields") and doc.getJSONObject("fields") or JSONObject()
return { id=docIdDesdeName(doc.getString("name")), nombre=campoString(fields, "nombre"), descripcion=campoString(fields, "descripcion"),
autor=campoString(fields, "autor"), url_github=campoString(fields, "url_github"), release_id=campoReleaseId(fields),
fecha_actualizacion=campoEntero(fields, "fecha_actualizacion"), anuncio=campoString(fields, "anuncio"),
descargas=campoEntero(fields, "descargas"), url_tutorial=campoString(fields, "url_tutorial") }
end
local function cargarComplementosSync()
local headers = authHeaderSync() local lista = {} local anunciosTemp = {} local pageToken = nil
repeat local url = FIRESTORE_URL .. "?pageSize=100"
if pageToken then url = url .. "&pageToken=" .. pageToken end
local ok, code, body = pcall(http_get, url, headers) if not ok or code ~= 200 then break end
local okP, root = pcall(JSONObject, body) if not okP then break end
if root.has("documents") then local arr = root.getJSONArray("documents")
for i = 0, arr.length() - 1 do local doc = firestoreADocumento(arr.getJSONObject(i))
if doc.nombre == "_anuncio" then if doc.autor ~= "" and doc.anuncio ~= "" then anunciosTemp[doc.autor] = doc.anuncio end
else table.insert(lista, doc) end end end
pageToken = (root.has("nextPageToken") and root.getString("nextPageToken") ~= "") and root.getString("nextPageToken") or nil
until not pageToken
for k, _ in pairs(anunciosUsuario) do anunciosUsuario[k] = nil end
for k, v in pairs(anunciosTemp) do anunciosUsuario[k] = v end
return lista
end
local function prepararUsuariosYAutorizacionSync(docsLista)
local ok, code, body = pcall(http_get, USUARIOS_URL) local repoUsers = {}
autorizado = false
if ok and code == 200 then
repoUsers = parsearUsuariosJSON(body)
usuariosData = repoUsers
if userName ~= "" then
for _, u in ipairs(repoUsers) do if u.username == userName then autorizado = true break end end
end
end
local known = {} for _, u in ipairs(repoUsers) do if u.public_name and u.public_name ~= "" then known[u.public_name] = true end end
for _, doc in ipairs(docsLista) do if doc.autor ~= "" and not known[doc.autor] then table.insert(usuariosData, {username=doc.autor, public_name=doc.autor}) known[doc.autor] = true end end
local lista = {} for _, u in ipairs(usuariosData) do table.insert(lista, u.username) end
table.sort(lista, function(a, b) if a == userName then return true end if b == userName then return false end return obtenerNombreVisible(a):lower() < obtenerNombreVisible(b):lower() end)
return lista, (ok and code == 200)
end
local function mostrarProgreso(mensaje)
local progDlg = LuaDialog(service) progDlg.setTitle(mensaje) progDlg.setCancelable(false)
progDlg.setView(loadlayout({LinearLayout, padding="24dp", gravity="center", {ProgressBar}})) progDlg.show() return progDlg
end
local function volverAPantallaUsuarios()
doVibrate(50)
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
mostrarDialogoUsuarios()
end
local function cargarNotificaciones()
local prefsNotif = service.getSharedPreferences(NOTIFICACIONES_PREFS, 0)
local ok, leidas = pcall(JSONArray, prefsNotif.getString("leidas", "[]"))
if ok then for i = 0, leidas.length() - 1 do notificacionesLeidas[leidas.getString(i)] = true end end
end
local function marcarNotificacionComoLeida(mensaje)
notificacionesLeidas[mensaje] = true local jsonArray = JSONArray()
for k, _ in pairs(notificacionesLeidas) do jsonArray.put(k) end
service.getSharedPreferences(NOTIFICACIONES_PREFS, 0).edit().putString("leidas", jsonArray.toString()).apply()
end
local function obtenerTodasLasNotificaciones()
local todas = {}
if mensajeGlobal ~= "" then for linea in mensajeGlobal:gmatch("[^\n]+") do linea = linea:match("^%s*(.-)%s*$")
if linea ~= "" then table.insert(todas, {mensaje=linea, leida=notificacionesLeidas[linea] or false}) end end end
return todas
end
local function contarNotificacionesNoLeidas()
local count = 0 if mensajeGlobal ~= "" then for linea in mensajeGlobal:gmatch("[^\n]+") do linea = linea:match("^%s*(.-)%s*$")
if linea ~= "" and not notificacionesLeidas[linea] then count = count + 1 end end end return count
end
local function actualizarBotonNotifPrincipal()
if not btnNotifPrincipalRef then return end
local noLeidas = contarNotificacionesNoLeidas()
btnNotifPrincipalRef.setText(noLeidas > 0 and "Hay una nueva notificación (" .. noLeidas .. ")" or "Notificaciones")
btnNotifPrincipalRef.setBackgroundColor(noLeidas > 0 and 0xFFFF5722 or 0xFF4CAF50)
end
local ordenarComplementos
local recargarTodo
local function mostrarErrorConexion()
doVibrate(50)
if dlgErrorConexion and dlgErrorConexion.isShowing() then dlgErrorConexion.dismiss() end
dlgErrorConexion = LuaDialog(service)
dlgErrorConexion.setTitle("Error de conexión")
dlgErrorConexion.setCancelable(false)
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", backgroundColor="0xFF000000", padding="20dp",
{TextView, text="SIN CONEXIÓN A INTERNET\nIntenta más tarde.", textColor="0xFFFF5722", textSize="16sp", gravity="center", padding="16dp"},
{Button, id="btnReintentar", text="Reintentar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCerrarError", text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
local views = {}
dlgErrorConexion.setView(loadlayout(layout, views))
dlgErrorConexion.show()
views.btnReintentar.setOnClickListener({onClick = function()
doVibrate(50)
dlgErrorConexion.dismiss()
recargarTodo()
end})
views.btnCerrarError.setOnClickListener({onClick = function()
doVibrate(50)
dlgErrorConexion.dismiss()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
end})
end
local function recargarDatos(alTerminar)
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
local function intentarCarga()
local progDlg = mostrarProgreso("Cargando servidor...")
progDlg.setCancelable(true)
local cargaCancelada = false
progDlg.setOnCancelListener({onCancel = function()
doVibrate(50)
cargaCancelada = true
end})
en_hilo(function()
local nuevaLista = cargarComplementosSync()
local usuarios, usuariosOk = prepararUsuariosYAutorizacionSync(nuevaLista)
local fetchFailed = (#nuevaLista == 0 and not usuariosOk and #usuarios == 0)
service.postExecute(0, "x", nil, function()
if progDlg and progDlg.isShowing() then progDlg.dismiss() end
if not cargaCancelada then
if fetchFailed then
mostrarErrorConexion()
else
complementos = nuevaLista
usuariosActivos = usuarios
alTerminar()
end
end
end)
end)
end
if not hayConexionInternet() then
mostrarErrorConexion()
else
intentarCarga()
end
end
recargarTodo = function() recargarDatos(function() mostrarDialogoUsuarios() end) end
local function refrescarVistaLocalDelAutor()
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
filtrados = {} for _, c in ipairs(complementos) do if c.autor == pub then table.insert(filtrados, c) end end
ordenarComplementos(filtrados, ordenActual) construirInterfazPrincipal() actualizarListaUI()
end
local function incrementarContadorDescargas(complementoId)
en_hilo(function()
local headers = authHeaderSync()
local documentoCompleto = "projects/" .. PROJECT_ID .. "/databases/(default)/documents/complementos/" .. complementoId
local body = [[{
"writes": [{
"transform": {
"document": "]] .. documentoCompleto .. [[",
"fieldTransforms": [{"fieldPath": "descargas", "increment": {"integerValue": "1"}}]
}
}]
}]]
local ok, code, respBody = pcall(http_send, "POST", FIRESTORE_COMMIT_URL, body, headers)
if not (ok and code == 200) then return end
local nuevasDescargas = nil
local okP, root = pcall(JSONObject, respBody)
if okP and root.has("writeResults") then
local wr = root.getJSONArray("writeResults")
if wr.length() > 0 then
local primero = wr.getJSONObject(0)
if primero.has("transformResults") then
local tr = primero.getJSONArray("transformResults")
if tr.length() > 0 then
local resultado = tr.getJSONObject(0)
if resultado.has("integerValue") then
nuevasDescargas = tonumber(resultado.getString("integerValue"))
end
end
end
end
end
service.postExecute(0, "x", nil, function()
if nuevasDescargas then
for i, c in ipairs(complementos) do
if c.id == complementoId then
c.descargas = nuevasDescargas
for j, f in ipairs(filtrados) do
if f.id == complementoId then
filtrados[j].descargas = nuevasDescargas
break
end
end
break
end
end
if tvTitulo then
local nombreVisible = obtenerNombreVisible(usuarioSeleccionado) or ""
tvTitulo.setText(nombreVisible .. "\n(" .. contarComplementosPorUsuario(usuarioSeleccionado) .. " complementos)")
end
actualizarListaUI()
end
end)
end)
end
local function abrirTutorial(url)
if url and url ~= "" then
service.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
end
end
local function mostrarDialogoPostInstalacion(nombre, url)
if not url or url == "" then return end
doVibrate(50)
local d = LuaDialog(service) d.setTitle("Instalación Exitosa")
d.setMessage("¿Quieres ver el tutorial de " .. nombre .. "?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Sí", layout_weight=1, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
abrirTutorial(url)
end}
}
d.setView(loadlayout(layout))
d.show()
end
local function instalarComplemento(complemento)
local progDlg = mostrarProgreso("Descargando complemento...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. complemento.nombre .. ".zip"
local okDownload = pcall(function()
local conn = URL(complemento.url_github).openConnection() conn.setConnectTimeout(10000) conn.setReadTimeout(30000)
local stream = conn.getInputStream() local fos = FileOutputStream(zipPath) local buffer = byte[4096] local count = stream.read(buffer)
while count ~= -1 do fos.write(buffer, 0, count) count = stream.read(buffer) end fos.close() stream.close()
end)
service.postExecute(0, "x", nil, function()
if okDownload then
progDlg.setTitle("Importando...")
if pcall(extraerZip, zipPath, obtenerCarpetaComplementos() .. "/" .. complemento.nombre) then
service.asyncSpeak(complemento.nombre .. " instalado correctamente")
local esPropietario = autorizado and obtenerNombrePublicoParaGuardar(userName) == complemento.autor
if not esPropietario then
incrementarContadorDescargas(complemento.id)
end
mostrarDialogoPostInstalacion(complemento.nombre, complemento.url_tutorial)
else
service.asyncSpeak("Error al instalar " .. complemento.nombre)
end
pcall(function() File(zipPath).delete() end)
else
service.asyncSpeak("Error al descargar")
end
progDlg.dismiss()
end)
end)
end
local function confirmarDescarga(complemento)
local d = LuaDialog(service) d.setTitle("Instalar complemento") d.setMessage("¿Quieres instalar \"" .. complemento.nombre .. "\"?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Cancelar", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Instalar", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() instalarComplemento(complemento) end}
}
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
local function eliminarReleaseGitHub(releaseId, releaseTag)
local headers = {Authorization = "Bearer " .. GITHUB_TOKEN, ["X-GitHub-Api-Version"] = "2022-11-28"}
pcall(http_send, "DELETE", GITHUB_API .. "/releases/" .. releaseId, "", headers)
pcall(http_send, "DELETE", GITHUB_API .. "/git/refs/tags/" .. releaseTag, "", headers)
end
local function subirAGitHubRelease(zipPath, nombre)
if not File(zipPath).exists() then return nil end
local releaseTag = "complemento-" .. nombre:gsub("[^a-zA-Z0-9_-]", "")
local headers = {Authorization = "Bearer " .. GITHUB_TOKEN, ["X-GitHub-Api-Version"] = "2022-11-28"}
local okGet, codeGet, bodyGet = pcall(http_get, GITHUB_API .. "/releases/tags/" .. releaseTag, headers)
if okGet and codeGet == 200 then local okP, rj = pcall(JSONObject, bodyGet) if okP and rj.has("id") then eliminarReleaseGitHub(tostring(rj.getInt("id")), releaseTag) end end
local releaseBody = "{\"tag_name\":\"" .. jsonEscape(releaseTag) .. "\",\"name\":\"" .. jsonEscape(nombre) .. "\",\"body\":\"Complemento: " .. jsonEscape(nombre) .. "\"}"
local ok, code, body = pcall(http_send, "POST", GITHUB_API .. "/releases", releaseBody, headers)
if not ok or code ~= 201 then return nil end
local okP, rj = pcall(JSONObject, body) if not okP or not rj.has("upload_url") or not rj.has("id") then return nil end
local newReleaseId = tostring(rj.getInt("id"))
local uploadUrl = rj.getString("upload_url"):gsub("{%?name,label}", "") .. "?name=" .. nombre .. ".zip"
local uploadHeaders = {Authorization = "Bearer " .. GITHUB_TOKEN, ["Content-Type"] = "application/zip"}
ok, code, body = pcall(http_upload, "POST", uploadUrl, zipPath, uploadHeaders)
if not ok or code ~= 201 then return nil end
local okA, aj = pcall(JSONObject, body) if not okA or not aj.has("browser_download_url") then return nil end
return {url = aj.getString("browser_download_url"), release_id = newReleaseId}
end
local function confirmarEliminar(complemento, dlgPadre)
local d = LuaDialog(service) d.setTitle("Eliminar complemento") d.setMessage("¿Seguro que quieres eliminar \"" .. complemento.nombre .. "\"?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Cancelar", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end},
{Button, text="Eliminar", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50) d.dismiss() if dlgPadre then pcall(function() dlgPadre.dismiss() end) end
local progDlg = mostrarProgreso("Eliminando...")
en_hilo(function()
local headers = authHeaderSync()
local ok, code = pcall(http_send, "DELETE", FIRESTORE_URL .. "/" .. complemento.id, "", headers)
if ok and code == 200 and complemento.release_id and complemento.release_id ~= "" then
eliminarReleaseGitHub(complemento.release_id, "complemento-" .. complemento.nombre:gsub("[^a-zA-Z0-9_-]", ""))
end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento eliminado")
for i, c in ipairs(complementos) do
if c.id == complemento.id then table.remove(complementos, i) break end
end
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al eliminar")
end
end)
end)
end}
}
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
local function listarComplementosLocales()
local nombres, rutas = {}, {}
for _, baseDir in ipairs(BASE_DIRS_LOCALES) do
local dir = File(baseDir)
if dir.exists() and dir.isDirectory() then
local lista = dir.listFiles()
if lista then
for i = 0, #lista - 1 do
local f = lista[i]
if f.isDirectory() and File(f.getAbsolutePath() .. "/main.lua").exists() then
table.insert(nombres, f.getName())
table.insert(rutas, f.getAbsolutePath())
end
end
end
end
end
return nombres, rutas
end
local function crearCuadroEdicion(titulo, textoInicial, hint, onAceptar)
local editDlg = LuaDialog(service) editDlg.setTitle(titulo)
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{EditText, id="etTexto", text=textoInicial, hint=hint, layout_width="match_parent", layout_height="match_parent", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"}
},
{Button, text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) local txt = views.etTexto.getText().toString() editDlg.dismiss() onAceptar(txt)
end},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) editDlg.dismiss()
end}
}
editDlg.setView(loadlayout(layout, views))
editDlg.setOnCancelListener({onCancel = function() doVibrate(50) editDlg.dismiss() end})
editDlg.show()
end
local function abrirEditor(complemento)
local rutaEncontrada = nil
local editDlg = LuaDialog(service)
editDlg.setTitle("Editar publicación")
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{LinearLayout, orientation="vertical", layout_width="match", layout_height="wrap",
{TextView, text="Descripción:", textColor="0xFFFFFFFF", padding="8dp"},
{EditText, id="etDescEditar", text=complemento.descripcion or "", hint="Descripción", layout_width="match", layout_height="wrap", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"},
{TextView, text="URL del Tutorial (opcional):", textColor="0xFFFFFFFF", padding="8dp"},
{EditText, id="etUrlTutEditar", text=complemento.url_tutorial or "", hint="https://...", layout_width="match", layout_height="wrap", inputType="textUri", padding="8dp", textColor="0xFFFFFFFF"}
}
},
{Button, id="btnBuscarComplemento", text="Modificar complemento", backgroundColor="0xFFFF9800", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) editDlg.dismiss() end},
{Button, id="btnAceptarEditor", text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
editDlg.setView(loadlayout(layout, views))
editDlg.setOnCancelListener({onCancel = function() doVibrate(50) editDlg.dismiss() end})
editDlg.show()
views.btnBuscarComplemento.setOnClickListener({onClick = function()
doVibrate(50)
local progBuscar = mostrarProgreso("Buscando complemento local...")
en_hilo(function()
local nombres, rutas = listarComplementosLocales()
local encontrada = nil
for i, n in ipairs(nombres) do
if n == complemento.nombre then encontrada = rutas[i] break end
end
service.postExecute(0, "x", nil, function()
progBuscar.dismiss()
if encontrada then
rutaEncontrada = encontrada
service.asyncSpeak("Complemento encontrado: " .. complemento.nombre)
else
service.asyncSpeak("Complemento no encontrado localmente")
end
end)
end)
end})
views.btnAceptarEditor.setOnClickListener({onClick = function()
doVibrate(50)
local nuevaDesc = views.etDescEditar.getText().toString()
local nuevaUrlTut = views.etUrlTutEditar.getText().toString()
editDlg.dismiss()
if rutaEncontrada then
local progDlg = mostrarProgreso("Subiendo complemento...")
en_hilo(function()
local headers = authHeaderSync()
local zipPath = "/storage/emulated/0/Download/" .. complemento.nombre .. "_upd.zip"
compressFolder(rutaEncontrada, zipPath)
local resultado = subirAGitHubRelease(zipPath, complemento.nombre)
local ok, code
if resultado then
local body = "{\"fields\":{\"descripcion\":{\"stringValue\":\"" .. jsonEscape(nuevaDesc) .. "\"},\"url_github\":{\"stringValue\":\"" .. jsonEscape(resultado.url) .. "\"},\"release_id\":{\"stringValue\":\"" .. resultado.release_id .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"},\"url_tutorial\":{\"stringValue\":\"" .. jsonEscape(nuevaUrlTut) .. "\"}}}"
local url = FIRESTORE_URL .. "/" .. complemento.id .. "?updateMask.fieldPaths=descripcion&updateMask.fieldPaths=url_github&updateMask.fieldPaths=release_id&updateMask.fieldPaths=fecha_actualizacion&updateMask.fieldPaths=url_tutorial"
ok, code = pcall(http_send, "PATCH", url, body, headers)
else ok = false end
service.postExecute(2000, "x", nil, function() pcall(function() File(zipPath).delete() end) end)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento actualizado correctamente")
complemento.descripcion = nuevaDesc
complemento.url_github = resultado.url
complemento.release_id = resultado.release_id
complemento.fecha_actualizacion = os.time()
complemento.url_tutorial = nuevaUrlTut
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
else
local progDlg = mostrarProgreso("Actualizando descripción...")
en_hilo(function()
local headers = authHeaderSync()
local body = "{\"fields\":{\"descripcion\":{\"stringValue\":\"" .. jsonEscape(nuevaDesc) .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"},\"url_tutorial\":{\"stringValue\":\"" .. jsonEscape(nuevaUrlTut) .. "\"}}}"
local url = FIRESTORE_URL .. "/" .. complemento.id .. "?updateMask.fieldPaths=descripcion&updateMask.fieldPaths=fecha_actualizacion&updateMask.fieldPaths=url_tutorial"
local ok, code = pcall(http_send, "PATCH", url, body, headers)
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
service.asyncSpeak("Descripción actualizada correctamente")
complemento.descripcion = nuevaDesc
complemento.fecha_actualizacion = os.time()
complemento.url_tutorial = nuevaUrlTut
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al actualizar")
end
end)
end)
end
end})
end
function ordenarComplementos(lista, criterio)
if criterio == ORDEN_ALFABETICO_AZ then
table.sort(lista, function(a, b) return (a.nombre or ""):lower() < (b.nombre or ""):lower() end)
elseif criterio == ORDEN_ALFABETICO_ZA then
table.sort(lista, function(a, b) return (a.nombre or ""):lower() > (b.nombre or ""):lower() end)
elseif criterio == ORDEN_FECHA_VIEJO then
table.sort(lista, function(a, b) return a.fecha_actualizacion < b.fecha_actualizacion end)
elseif criterio == ORDEN_POPULARIDAD then
table.sort(lista, function(a, b)
local descA = a.descargas or 0
local descB = b.descargas or 0
return descA > descB
end)
else
table.sort(lista, function(a, b) return a.fecha_actualizacion > b.fecha_actualizacion end)
end
end
local function mostrarMenuOrdenar()
if #filtrados == 0 then service.asyncSpeak("No hay elementos para ordenar") return end
local menuDlg = LuaDialog(service) menuDlg.setTitle("Ordenar complementos") menuDlg.setCancelable(true)
local opciones = {
{texto="Alfabético (A-Z)", valor=ORDEN_ALFABETICO_AZ},
{texto="Alfabético (Z-A)", valor=ORDEN_ALFABETICO_ZA},
{texto="Más reciente", valor=ORDEN_FECHA_NUEVO},
{texto="Más antiguo", valor=ORDEN_FECHA_VIEJO},
{texto="Más populares (más descargas)", valor=ORDEN_POPULARIDAD}
}
local nombreActual = ""
for _, op in ipairs(opciones) do if op.valor == ordenActual then nombreActual = op.texto break end end
local layout = {LinearLayout, orientation="vertical", padding="16dp", {TextView, text="Orden actual: " .. nombreActual, textSize="14sp", paddingBottom="16dp"}}
for _, op in ipairs(opciones) do
table.insert(layout, {Button, text=op.texto, backgroundColor=op.valor == ordenActual and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) ordenActual = op.valor prefs.edit().putString(OPCION_ORDEN, ordenActual).apply()
menuDlg.dismiss() ordenarComplementos(filtrados, ordenActual) actualizarListaUI() service.asyncSpeak("Ordenado: " .. op.texto)
end})
end
table.insert(layout, {Button, text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) menuDlg.dismiss() end})
menuDlg.setView(loadlayout(layout))
menuDlg.setOnCancelListener({onCancel = function() doVibrate(50) menuDlg.dismiss() end})
menuDlg.show()
end
local function buscar(query)
query = query:lower() local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
filtrados = {} for _, c in ipairs(complementos) do if c.autor == pub then
if query == "" or c.nombre:lower():find(query, 1, true) or (c.descripcion or ""):lower():find(query, 1, true) then table.insert(filtrados, c) end
end end ordenarComplementos(filtrados, ordenActual) actualizarListaUI()
if query ~= "" then if #filtrados == 0 then service.asyncSpeak("Sin resultados") else service.asyncSpeak(#filtrados .. " resultados") end end
end
local function editarAnuncio()
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
if not autorizado or usuarioSeleccionado ~= userName then service.asyncSpeak("Sin permisos") return end
crearCuadroEdicion("Editar anuncio", anunciosUsuario[pub] or "", "Escribe tu anuncio aquí...", function(nuevoAnuncio)
local progDlg = mostrarProgreso("Guardando anuncio...")
en_hilo(function()
local headers = authHeaderSync() local docId = pub:gsub("[^a-zA-Z0-9_]", "_") .. "_anuncio"
local body = "{\"fields\":{\"autor\":{\"stringValue\":\"" .. jsonEscape(pub) .. "\"},\"anuncio\":{\"stringValue\":\"" .. jsonEscape(nuevoAnuncio) .. "\"},\"nombre\":{\"stringValue\":\"_anuncio\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"}}}"
local ok, code = pcall(http_send, "PATCH", FIRESTORE_URL .. "/" .. docId, body, headers)
if not ok or code ~= 200 then ok, code = pcall(http_send, "POST", FIRESTORE_URL, body, headers) end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if ok and code == 200 then
if nuevoAnuncio == "" then
anunciosUsuario[pub] = nil
service.asyncSpeak("Anuncio borrado correctamente")
else
anunciosUsuario[pub] = nuevoAnuncio
service.asyncSpeak("Anuncio guardado")
end
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error al guardar")
end
end)
end)
end)
end
local function mostrarDialogoOpcionesPropietario(complemento)
local d = LuaDialog(service) d.setTitle("Opciones de complemento")
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Instalar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() if pedirConfirmacion then confirmarDescarga(complemento) else instalarComplemento(complemento) end end}
}
if complemento.url_tutorial and complemento.url_tutorial ~= "" then
table.insert(layout, {Button, text="Ver Tutorial", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() abrirTutorial(complemento.url_tutorial) end})
end
table.insert(layout, {Button, text="Editar publicación", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() abrirEditor(complemento) end})
table.insert(layout, {Button, text="Eliminar", backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() confirmarEliminar(complemento, nil) end})
table.insert(layout, {Button, text="Volver", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end})
d.setView(loadlayout(layout))
d.setOnCancelListener({onCancel = function() doVibrate(50) d.dismiss() end})
d.show()
end
local function construirTarjetaComplemento(complemento)
local tarjeta = { LinearLayout, orientation="vertical", backgroundColor="0xFF202125", padding="12dp" }
local esPropietario = autorizado and obtenerNombrePublicoParaGuardar(userName) == complemento.autor
local descargasText = "Descargas: " .. (complemento.descargas or 0)
local tieneTutorial = complemento.url_tutorial and complemento.url_tutorial ~= ""
table.insert(tarjeta, {TextView, text=complemento.nombre, textSize="18sp", textColor="0xFFFFFFFF"})
table.insert(tarjeta, {TextView, text=descargasText, textSize="14sp", textColor="0xFF4CAF50", paddingBottom="4dp"})
if complemento.descripcion and complemento.descripcion ~= "" then
table.insert(tarjeta, {TextView, text="Descripción: " .. complemento.descripcion, textSize="14sp", textColor="0xFFAAAAAA", padding="4dp"})
end
if modoCompacto then
tarjeta.clickable = true
tarjeta.onClick = function()
doVibrate(50)
if esPropietario then
mostrarDialogoOpcionesPropietario(complemento)
else
if tieneTutorial then
local d = LuaDialog(service) d.setTitle(complemento.nombre)
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="Instalar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() if pedirConfirmacion then confirmarDescarga(complemento) else instalarComplemento(complemento) end end},
{Button, text="Ver Tutorial", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() abrirTutorial(complemento.url_tutorial) end},
{Button, text="Cancelar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) d.dismiss() end}
}
d.setView(loadlayout(layout))
d.show()
else
if pedirConfirmacion then confirmarDescarga(complemento) else instalarComplemento(complemento) end
end
end
end
else
local btnsLayout = {LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content"}
table.insert(btnsLayout, {Button, text="Instalar", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="12dp", onClick=function()
doVibrate(50)
if pedirConfirmacion then confirmarDescarga(complemento) else instalarComplemento(complemento) end
end})
if tieneTutorial then
table.insert(btnsLayout, {Button, text="Ver Tutorial", layout_weight=1, backgroundColor="0xFF009688", textColor="0xFFFFFFFF", padding="12dp", onClick=function()
doVibrate(50)
abrirTutorial(complemento.url_tutorial)
end})
end
table.insert(tarjeta, btnsLayout)
end
if esPropietario and not modoCompacto then
table.insert(tarjeta, {LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="4dp",
{Button, text="Editar publicación", layout_weight=1, backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", padding="12dp", onClick=function() doVibrate(50) abrirEditor(complemento) end},
{Button, text="Eliminar", layout_weight=1, backgroundColor="0xFFFF5722", textColor="0xFFFFFFFF", padding="12dp", onClick=function() doVibrate(50) confirmarEliminar(complemento, nil) end}
})
end
return tarjeta
end
actualizarListaUI = function()
if contenedorComplementos == nil then return end
contenedorComplementos.removeAllViews()
local pub = obtenerNombrePublicoParaGuardar(usuarioSeleccionado) or usuarioSeleccionado
if anunciosUsuario[pub] then
contenedorComplementos.addView(loadlayout({TextView, text=anunciosUsuario[pub], textColor="0xFFFFD700", padding="8dp", backgroundColor="0xFF333333", gravity="center"}))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
if autorizado and usuarioSeleccionado == userName then
contenedorComplementos.addView(loadlayout({Button, text="Editar anuncio", backgroundColor="0xFFFF9800", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) editarAnuncio() end}))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
if #filtrados == 0 then
contenedorComplementos.addView(loadlayout({TextView, text="No hay complementos disponibles", textSize="16sp", padding="16dp", gravity="center", textColor="0xFFFFFFFF"}))
else
for _, c in ipairs(filtrados) do
contenedorComplementos.addView(loadlayout(construirTarjetaComplemento(c)))
contenedorComplementos.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
end
if tvTitulo then
local nombreVisible = obtenerNombreVisible(usuarioSeleccionado) or ""
tvTitulo.setText(nombreVisible .. "\n(" .. contarComplementosPorUsuario(usuarioSeleccionado) .. " complementos)")
end
if btnSubirComplemento then btnSubirComplemento.setVisibility((autorizado and usuarioSeleccionado == userName) and View.VISIBLE or View.GONE) end
end
local function seleccionarComplementoLocalDialog(callback)
local progDlg = mostrarProgreso("Cargando complementos locales...")
en_hilo(function()
local nombres, rutas = listarComplementosLocales()
local combined = {}
for i = 1, #nombres do table.insert(combined, {nombre = nombres[i], ruta = rutas[i]}) end
if ordenActual == ORDEN_ALFABETICO_AZ then
table.sort(combined, function(a, b) return a.nombre:lower() < b.nombre:lower() end)
elseif ordenActual == ORDEN_ALFABETICO_ZA then
table.sort(combined, function(a, b) return a.nombre:lower() > b.nombre:lower() end)
end
nombres = {}
rutas = {}
for i, item in ipairs(combined) do
table.insert(nombres, item.nombre)
table.insert(rutas, item.ruta)
end
service.postExecute(0, "x", nil, function()
progDlg.dismiss()
if #nombres == 0 then service.asyncSpeak("No se encontraron complementos locales") return end
local selDlg = LuaDialog(service)
selDlg.setTitle("Selecciona un complemento")
local views = {}
selDlg.setView(loadlayout({LinearLayout, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", orientation="vertical",
{EditText, id="etSearchLocal", hint="Buscar...", layout_width="match_parent", layout_height="wrap_content", textColor="0xFFFFFFFF", padding="12dp"},
{ListView, id="lvLoc", layout_width="match_parent", layout_height="0dp", layout_weight="1"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) selDlg.dismiss() end}
}, views))
selDlg.setOnCancelListener({onCancel = function() doVibrate(50) selDlg.dismiss() end})
selDlg.show()
local currentNombres = nombres
local currentRutas = rutas
local function setupAdapter(listNombres)
views.lvLoc.setAdapter(ArrayAdapter(service, android.R.layout.simple_list_item_1, String(listNombres)))
end
setupAdapter(currentNombres)
views.etSearchLocal.addTextChangedListener({
onTextChanged = function(s, start, before, count)
local query = tostring(s):lower()
if query == "" then
currentNombres = nombres
currentRutas = rutas
else
currentNombres = {}
currentRutas = {}
for i, n in ipairs(nombres) do
if n:lower():find(query, 1, true) then
table.insert(currentNombres, n)
table.insert(currentRutas, rutas[i])
end
end
end
setupAdapter(currentNombres)
end
})
views.lvLoc.setOnItemClickListener(AdapterView.OnItemClickListener{
onItemClick = function(p, v, pos, id)
doVibrate(50)
selDlg.dismiss()
callback(currentNombres[pos+1], currentRutas[pos+1])
end
})
end)
end)
end
local function mostrarDialogoTutorialSubida(callback)
local d = LuaDialog(service)
d.setTitle("Tutorial Disponible")
d.setMessage("¿Hay un tutorial disponible para este complemento?")
local layout = {
LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="16dp",
{Button, text="No", layout_weight=1, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
callback(nil)
end},
{Button, text="Sí", layout_weight=1, backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
local urlDlg = LuaDialog(service)
urlDlg.setTitle("Enlace del Tutorial")
local urlViews = {}
urlDlg.setView(loadlayout({
LinearLayout, orientation="vertical", padding="16dp",
{EditText, id="etUrl", hint="https://youtube.com/...", layout_width="match_parent", layout_height="wrap_content", padding="12dp", textColor="0xFFFFFFFF", inputType="textUri"},
{Button, text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
local url = urlViews.etUrl.getText().toString()
urlDlg.dismiss()
callback(url)
end}
}, urlViews))
urlDlg.show()
end}
}
d.setView(loadlayout(layout))
d.show()
end
local function abrirSubirComplemento()
local ruta, nombre = nil, nil
local subirDlg = LuaDialog(service) subirDlg.setTitle("Subir Complemento")
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", backgroundColor="0xFF000000",
{EditText, id="etDescSubir", hint="Descripción del complemento", layout_width="match_parent", layout_height="match_parent", gravity="left|top", inputType="textMultiLine", padding="8dp", textColor="0xFFFFFFFF"}
},
{Button, id="btnElegir", text="Elegir complemento", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{TextView, id="tvNomSel", text="", visibility="gone", padding="8dp", textColor="0xFFFFFFFF"},
{Button, text="Cancelar", backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) subirDlg.dismiss() end},
{Button, id="btnAceptar", text="Aceptar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"}
}
subirDlg.setView(loadlayout(layout, views))
subirDlg.setOnCancelListener({onCancel = function() doVibrate(50) subirDlg.dismiss() end})
subirDlg.show()
views.btnElegir.setOnClickListener({onClick = function()
doVibrate(50) seleccionarComplementoLocalDialog(function(n, r) ruta = r nombre = n views.tvNomSel.setText(n) views.tvNomSel.setVisibility(View.VISIBLE) end)
end})
views.btnAceptar.setOnClickListener({onClick = function()
doVibrate(50) if not ruta then service.asyncSpeak("Selecciona un complemento") return end
if not autorizado then service.asyncSpeak("No autorizado") return end
local pub = obtenerNombrePublicoParaGuardar(userName) if not pub then service.asyncSpeak("Sin nombre público") return end
local desc = views.etDescSubir.getText().toString() subirDlg.dismiss()
mostrarDialogoTutorialSubida(function(urlTutorial)
local prog = mostrarProgreso("Subiendo...")
en_hilo(function()
local zipPath = "/storage/emulated/0/Download/" .. nombre .. ".zip" compressFolder(ruta, zipPath)
local res = subirAGitHubRelease(zipPath, nombre)
if res then
local headers = authHeaderSync()
local anun = anunciosUsuario[pub] or ""
local descargasExistentes = 0
local complementoExistente = nil
for _, c in ipairs(complementos) do
if c.autor == pub and c.nombre == nombre then
complementoExistente = c
descargasExistentes = c.descargas or 0
break
end
end
local body
if complementoExistente then
body = "{\"fields\":{\"nombre\":{\"stringValue\":\"" .. jsonEscape(nombre) .. "\"},\"descripcion\":{\"stringValue\":\"" .. jsonEscape(desc) .. "\"},\"autor\":{\"stringValue\":\"" .. jsonEscape(pub) .. "\"},\"url_github\":{\"stringValue\":\"" .. jsonEscape(res.url) .. "\"},\"release_id\":{\"stringValue\":\"" .. res.release_id .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"},\"anuncio\":{\"stringValue\":\"" .. jsonEscape(anun) .. "\"},\"descargas\":{\"integerValue\":\"" .. tostring(descargasExistentes) .. "\"},\"url_tutorial\":{\"stringValue\":\"" .. jsonEscape(urlTutorial or "") .. "\"}}}"
local url = FIRESTORE_URL .. "/" .. complementoExistente.id .. "?updateMask.fieldPaths=nombre&updateMask.fieldPaths=descripcion&updateMask.fieldPaths=autor&updateMask.fieldPaths=url_github&updateMask.fieldPaths=release_id&updateMask.fieldPaths=fecha_actualizacion&updateMask.fieldPaths=anuncio&updateMask.fieldPaths=descargas&updateMask.fieldPaths=url_tutorial"
local ok, code = pcall(http_send, "PATCH", url, body, headers)
service.postExecute(0, "x", nil, function()
prog.dismiss()
if ok and code == 200 then
service.asyncSpeak("Complemento actualizado correctamente")
complementoExistente.descripcion = desc
complementoExistente.url_github = res.url
complementoExistente.release_id = res.release_id
complementoExistente.fecha_actualizacion = os.time()
complementoExistente.url_tutorial = urlTutorial or ""
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error en BD")
end
end)
else
body = "{\"fields\":{\"nombre\":{\"stringValue\":\"" .. jsonEscape(nombre) .. "\"},\"descripcion\":{\"stringValue\":\"" .. jsonEscape(desc) .. "\"},\"autor\":{\"stringValue\":\"" .. jsonEscape(pub) .. "\"},\"url_github\":{\"stringValue\":\"" .. jsonEscape(res.url) .. "\"},\"release_id\":{\"stringValue\":\"" .. res.release_id .. "\"},\"fecha_actualizacion\":{\"integerValue\":\"" .. tostring(os.time()) .. "\"},\"anuncio\":{\"stringValue\":\"" .. jsonEscape(anun) .. "\"},\"descargas\":{\"integerValue\":\"0\"},\"url_tutorial\":{\"stringValue\":\"" .. jsonEscape(urlTutorial or "") .. "\"}}}"
local ok, code, respBody = pcall(http_send, "POST", FIRESTORE_URL, body, headers)
local nuevoId = nil
if ok and code == 200 then
local okP, rj = pcall(JSONObject, respBody)
if okP and rj.has("name") then nuevoId = docIdDesdeName(rj.getString("name")) end
end
service.postExecute(0, "x", nil, function()
prog.dismiss()
if ok and code == 200 then
service.asyncSpeak("Subido correctamente")
table.insert(complementos, {
id = nuevoId or (nombre .. "_" .. tostring(os.time())),
nombre = nombre, descripcion = desc, autor = pub, url_github = res.url,
release_id = res.release_id, fecha_actualizacion = os.time(), anuncio = anun,
descargas = 0, url_tutorial = urlTutorial or ""
})
refrescarVistaLocalDelAutor()
else
service.asyncSpeak("Error en BD")
end
end)
end
else
service.postExecute(0, "x", nil, function() prog.dismiss() service.asyncSpeak("Error al subir") end)
end
service.postExecute(2000, "x", nil, function() pcall(function() File(zipPath).delete() end) end)
end)
end)
end})
end
local function mostrarInstrucciones()
doVibrate(50)
local instruccionesParagraphs = {}
for paragraph in instruccionesText:gmatch("[^\n]+") do
if paragraph:match("%S") then
table.insert(instruccionesParagraphs, paragraph)
end
end
local instruccionesLayout = {
LinearLayout,
orientation = "vertical",
layout_width = "fill",
layout_height = "fill",
padding = "20dp",
backgroundColor = 0xFF000000,
{
TextView,
text = "LEE CON MUCHA ATENCIÓN LAS INSTRUCCIONES",
layout_width = "wrap_content",
layout_height = "wrap_content",
textSize = "20sp",
textColor = 0xFF00FF00,
gravity = "center",
layout_marginBottom = "20dp",
layout_gravity = "center_horizontal"
},
{
ScrollView,
layout_width = "match_parent",
layout_height = "300dp",
layout_marginBottom = "20dp",
{
LinearLayout,
id = "instruccionesContainer",
orientation = "vertical",
layout_width = "match_parent",
layout_height = "wrap_content",
padding = "8dp"
}
},
{
Button,
id = "instruccionesOkButton",
text = "Entendido",
layout_width = "200dp",
layout_height = "wrap_content",
backgroundColor = 0xFF4CAF50,
textColor = 0xFFFFFFFF,
layout_gravity = "center_horizontal"
}
}
dlgIns = LuaDialog(service)
dlgIns.setTitle("Instrucciones de uso")
local views = {}
local dialogView = loadlayout(instruccionesLayout, views)
for i, paragraph in ipairs(instruccionesParagraphs) do
local paragraphView = TextView(service)
paragraphView.setText(paragraph)
paragraphView.setTextColor(0xFFFFFFFF)
paragraphView.setTextSize(14)
paragraphView.setPadding(12, 8, 12, 8)
paragraphView.setBackgroundColor(0xFF333333)
local layoutParams = LinearLayout.LayoutParams(
LinearLayout.LayoutParams.MATCH_PARENT,
LinearLayout.LayoutParams.WRAP_CONTENT
)
layoutParams.setMargins(0, 0, 0, 2)
paragraphView.setLayoutParams(layoutParams)
views.instruccionesContainer.addView(paragraphView)
end
dlgIns.setView(dialogView)
dlgIns.setCancelable(true)
dlgIns.setOnCancelListener({onCancel = function() doVibrate(50) dlgIns.dismiss() end})
views.instruccionesOkButton.onClick = function()
doVibrate(50)
service.asyncSpeak("Cerrado")
dlgIns.dismiss()
end
dlgIns.show()
service.asyncSpeak("Mostrando instrucciones de uso")
end
function mostrarConfiguraciones()
doVibrate(50)
dlgConfig = LuaDialog(service) dlgConfig.setTitle("Configuraciones")
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="wrap_content", backgroundColor="0xFF000000", padding="16dp",
{Button, id="btnVib", text=vibrationEnabled and "Vibración: Activada" or "Vibración: Desactivada", backgroundColor=vibrationEnabled and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{LinearLayout, id="layVib", orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", visibility = vibrationEnabled and View.VISIBLE or View.GONE, padding="8dp",
{TextView, id="txtVib", text="Intensidad: " .. vibrationIntensity .. "%", textColor="0xFFFFFFFF", layout_width="0dp", layout_weight="1", gravity="center_vertical"},
{SeekBar, id="seekVib", layout_width="0dp", layout_weight="2", max="100", progress=tostring(vibrationIntensity)}
},
{Button, id="btnConf", text=pedirConfirmacion and "Pedir confirmación antes de instalar: Activado" or "Pedir confirmación antes de instalar: Desactivado", backgroundColor=pedirConfirmacion and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCompacto", text=modoCompacto and "Incrustar descripción en el nombre del elemento y hacer clic para instalar: Activado" or "Incrustar descripción en el nombre del elemento y hacer clic para instalar: Desactivado", backgroundColor=modoCompacto and "0xFF4CAF50" or "0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnIns", text="Instrucciones de uso", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, id="btnCreditos", text="Créditos", backgroundColor="0xFF009688", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, text="Cerrar", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) dlgConfig.dismiss() end}
}
dlgConfig.setView(loadlayout(layout, views))
dlgConfig.setOnCancelListener({onCancel = function() doVibrate(50) dlgConfig.dismiss() end})
local function actualizarUIConfig()
views.btnVib.setText(vibrationEnabled and "Vibración: Activada" or "Vibración: Desactivada")
views.btnVib.setBackgroundColor(vibrationEnabled and 0xFF4CAF50 or 0xFF333333)
views.layVib.setVisibility(vibrationEnabled and View.VISIBLE or View.GONE)
views.txtVib.setText("Intensidad: " .. vibrationIntensity .. "%")
views.seekVib.setProgress(vibrationIntensity)
views.btnConf.setText(pedirConfirmacion and "Pedir confirmación antes de instalar: Activado" or "Pedir confirmación antes de instalar: Desactivado")
views.btnConf.setBackgroundColor(pedirConfirmacion and 0xFF4CAF50 or 0xFF333333)
views.btnCompacto.setText(modoCompacto and "Incrustar descripción en el nombre del elemento y hacer clic para instalar: Activado" or "Incrustar descripción en el nombre del elemento y hacer clic para instalar: Desactivado")
views.btnCompacto.setBackgroundColor(modoCompacto and 0xFF4CAF50 or 0xFF333333)
end
dlgConfig.show()
views.btnVib.setOnClickListener({onClick = function()
doVibrate(50) vibrationEnabled = not vibrationEnabled prefs.edit().putBoolean("vibrationEnabled", vibrationEnabled).apply()
actualizarUIConfig()
end})
views.seekVib.setOnSeekBarChangeListener(SeekBar.OnSeekBarChangeListener{
onProgressChanged = function(s, p, f) if f then vibrationIntensity = p prefs.edit().putInt("vibrationIntensity", p).apply() actualizarUIConfig() doVibrate(30) end end
})
views.btnConf.setOnClickListener({onClick = function()
doVibrate(50) pedirConfirmacion = not pedirConfirmacion prefs.edit().putBoolean("pedirConfirmacion", pedirConfirmacion).apply()
actualizarUIConfig()
end})
views.btnCompacto.setOnClickListener({onClick = function()
doVibrate(50) modoCompacto = not modoCompacto prefs.edit().putBoolean("modoCompacto", modoCompacto).apply()
actualizarUIConfig()
actualizarListaUI()
end})
views.btnIns.setOnClickListener({onClick = function() doVibrate(50) mostrarInstrucciones() end})
views.btnCreditos.setOnClickListener({onClick = function() doVibrate(50) mostrarCreditos() end})
end
construirInterfazPrincipal = function()
dlgPrincipal = LuaDialog(service)
local views = {}
local layout = {
LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000",
{TextView, id="tvTitulo", textSize="20sp", gravity="center", padding="16dp", textColor="0xFFFFFFFF"},
{Button, id="btnSubir", text="Subir Complemento", visibility="gone", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{LinearLayout, orientation="horizontal", layout_width="match_parent", layout_height="wrap_content", padding="4dp",
{EditText, id="etSearch", hint="Buscar...", layout_width="0dp", layout_weight="1"},
{Button, id="btnClear", text="Borrar", visibility="gone", layout_width="wrap_content", layout_height="wrap_content", padding="12dp"},
{Button, id="btnSort", text="Ordenar", layout_width="wrap_content", layout_height="wrap_content", padding="12dp"}
},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contComp", orientation="vertical", layout_width="match_parent", layout_height="wrap_content"}},
{Button, id="btnVolver", text="Volver", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) volverAPantallaUsuarios() end}
}
dlgPrincipal.setView(loadlayout(layout, views))
dlgPrincipal.setOnCancelListener({onCancel = function() doVibrate(50) volverAPantallaUsuarios() end})
dlgPrincipal.show()
tvTitulo = views.tvTitulo
btnSubirComplemento = views.btnSubir
searchEditText = views.etSearch
btnClear = views.btnClear
btnSort = views.btnSort
contenedorComplementos = views.contComp
btnSubirComplemento.setOnClickListener({onClick = function() doVibrate(50) abrirSubirComplemento() end})
btnSort.setOnClickListener({onClick = function() doVibrate(50) mostrarMenuOrdenar() end})
btnClear.setOnClickListener({onClick = function() doVibrate(30) searchEditText.setText("") end})
searchEditText.addTextChangedListener({onTextChanged = function(s)
local text = s.toString()
if text:len() > 0 then btnClear.setVisibility(View.VISIBLE) else btnClear.setVisibility(View.GONE) end
buscar(text)
end})
end
function mostrarDialogoUsuarios()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
dlgUsuarios = LuaDialog(service) dlgUsuarios.setTitle("Tienda de complementos")
local views = {}
dlgUsuarios.setView(loadlayout({
LinearLayout, layout_width="match_parent", layout_height="match_parent", backgroundColor="0xFF000000", orientation="vertical", padding="8dp",
{Button, id="btnNotif", text="Notificaciones", backgroundColor="0xFF4CAF50", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp"},
{Button, text="Configuraciones", backgroundColor="0xFF9C27B0", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) mostrarConfiguraciones() end},
{TextView, text="Selecciona un usuario:", textSize="16sp", gravity="center", padding="8dp", textColor="0xFFFFFFFF"},
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contUsr", orientation="vertical"}},
{Button, text="Cerrar", backgroundColor="0xFF666666", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function() doVibrate(50) dlgUsuarios.dismiss() end}
}, views))
dlgUsuarios.setOnCancelListener({onCancel = function() doVibrate(50) pcall(function() dlgUsuarios.dismiss() end) dlgUsuarios = nil end})
dlgUsuarios.show()
btnNotifPrincipalRef = views.btnNotif
actualizarBotonNotifPrincipal()
views.btnNotif.setOnClickListener({onClick = function() doVibrate(50) mostrarInterfazNotificaciones() end})
views.contUsr.removeAllViews()
if #usuariosActivos == 0 then views.contUsr.addView(loadlayout({TextView, text="Cargando...", textColor="0xFFFFFFFF"}))
else
for _, u in ipairs(usuariosActivos) do
local count = contarComplementosPorUsuario(u)
local txt = (u == userName) and ("Mis complementos (" .. count .. ")") or (obtenerNombreVisible(u) .. " (" .. count .. ")")
views.contUsr.addView(loadlayout({Button, text=txt, backgroundColor="0xFF333333", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50) usuarioSeleccionado = u dlgUsuarios.dismiss()
filtrados = {} local pub = obtenerNombrePublicoParaGuardar(u) or u
for _, c in ipairs(complementos) do if c.autor == pub then table.insert(filtrados, c) end end
ordenarComplementos(filtrados, ordenActual) construirInterfazPrincipal() actualizarListaUI()
end}))
views.contUsr.addView(loadlayout({View, layout_width="match_parent", layout_height="4dp"}))
end
end
if mostrarCreditosFlag then
mostrarCreditosFlag = false
handler.postDelayed(Runnable { run = function() mostrarCreditos() end }, 1000)
end
end
function mostrarInterfazNotificaciones()
local todas = obtenerTodasLasNotificaciones()
local d = LuaDialog(service) d.setTitle("Historial")
local views = {}
d.setView(loadlayout({LinearLayout, orientation="vertical", layout_width="match_parent", layout_height="match_parent", padding="16dp", backgroundColor="0xFF000000",
{ScrollView, layout_width="match_parent", layout_height="0dp", layout_weight="1", {LinearLayout, id="contNotif", orientation="vertical"}},
{Button, text="Volver", backgroundColor="0xFF2196F3", textColor="0xFFFFFFFF", layout_width="match_parent", padding="16dp", onClick=function()
doVibrate(50)
d.dismiss()
actualizarBotonNotifPrincipal()
end}
}, views))
d.setOnCancelListener({onCancel = function()
doVibrate(50)
d.dismiss()
actualizarBotonNotifPrincipal()
end})
d.show()
views.contNotif.removeAllViews()
if #todas == 0 then views.contNotif.addView(loadlayout({TextView, text="Sin notificaciones", textColor="0xFFFFFFFF"}))
else
for _, n in ipairs(todas) do
if not n.leida then marcarNotificacionComoLeida(n.mensaje) end
views.contNotif.addView(loadlayout({LinearLayout, orientation="vertical", padding="12dp", backgroundColor="0xFF202125",
{TextView, text="Notificación de la Tienda", textColor="0xFFFFD700", textSize="12sp"},
{TextView, text=n.mensaje, textColor="0xFFFFFFFF", padding="4dp"}
}))
views.contNotif.addView(loadlayout({View, layout_width="match_parent", layout_height="8dp"}))
end
end
actualizarBotonNotifPrincipal()
end
function onKeyDown(code, event)
if code == KeyEvent.KEYCODE_BACK then
doVibrate(50)
if dlgErrorConexion and dlgErrorConexion.isShowing() then
dlgErrorConexion.dismiss()
if dlgUsuarios then pcall(function() dlgUsuarios.dismiss() end) end
if dlgPrincipal then pcall(function() dlgPrincipal.dismiss() end) end
elseif dlgCreditos and dlgCreditos.isShowing() then dlgCreditos.dismiss()
elseif dlgIns and dlgIns.isShowing() then dlgIns.dismiss()
elseif dlgConfig and dlgConfig.isShowing() then dlgConfig.dismiss()
elseif dlgPrincipal and dlgPrincipal.isShowing() then volverAPantallaUsuarios()
elseif dlgUsuarios and dlgUsuarios.isShowing() then dlgUsuarios.dismiss()
end
return true
end
return false
end
cargarNotificaciones()
Http.get(MSG_URL, function(status, data)
if status == 200 and data and data ~= "" then mensajeGlobal = data:match("^%s*(.-)%s*$") or "" end
verificarActualizaciones(function() recargarTodo() end)
end)
return true